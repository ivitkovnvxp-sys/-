-- TMS Database Schema
-- Transport Management System Database

-- ============================================
-- USERS TABLE
-- ============================================
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL CHECK (role IN ('manager', 'logistic', 'admin')),
    full_name VARCHAR(100),
    phone VARCHAR(20),
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index for user lookups
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);

-- ============================================
-- CLIENTS TABLE
-- ============================================
CREATE TABLE clients (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    company_name VARCHAR(200),
    inn VARCHAR(20),
    phone VARCHAR(20),
    email VARCHAR(100),
    address TEXT,
    contact_person VARCHAR(100),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for client search
CREATE INDEX idx_clients_name ON clients(name);
CREATE INDEX idx_clients_phone ON clients(phone);
CREATE INDEX idx_clients_email ON clients(email);

-- ============================================
-- VEHICLES TABLE
-- ============================================
CREATE TABLE vehicles (
    id SERIAL PRIMARY KEY,
    plate_number VARCHAR(20) UNIQUE NOT NULL,
    type VARCHAR(50) NOT NULL, -- фура, газель, рефрижератор, etc.
    brand VARCHAR(50),
    model VARCHAR(50),
    year INTEGER,
    capacity_kg INTEGER, -- грузоподъемность в кг
    volume_m3 DECIMAL(8,2), -- объем в кубометрах
    driver_name VARCHAR(100),
    driver_phone VARCHAR(20),
    status VARCHAR(20) DEFAULT 'available' CHECK (status IN ('available', 'in_transit', 'maintenance', 'offline')),
    last_maintenance_date DATE,
    next_maintenance_date DATE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for vehicle search
CREATE INDEX idx_vehicles_plate ON vehicles(plate_number);
CREATE INDEX idx_vehicles_status ON vehicles(status);
CREATE INDEX idx_vehicles_type ON vehicles(type);

-- ============================================
-- ORDERS TABLE
-- ============================================
CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    client_id INTEGER REFERENCES clients(id) ON DELETE SET NULL,
    client_name VARCHAR(200) NOT NULL, -- дублируем для истории
    
    -- Тип перевозки
    order_type VARCHAR(20) NOT NULL DEFAULT 'full' CHECK (order_type IN ('full', 'part', 'express')),
    
    -- Груз
    cargo_type VARCHAR(50),
    weight_kg INTEGER,
    volume_m3 DECIMAL(8,2),
    notes TEXT,
    
    -- Точки загрузки
    pickup_address TEXT NOT NULL,
    pickup_lat DECIMAL(10, 8),
    pickup_lon DECIMAL(11, 8),
    pickup_contact VARCHAR(100),
    pickup_phone VARCHAR(20),
    pickup_instructions TEXT,
    
    -- Точки доставки
    delivery_address TEXT NOT NULL,
    delivery_lat DECIMAL(10, 8),
    delivery_lon DECIMAL(11, 8),
    delivery_contact VARCHAR(100),
    delivery_phone VARCHAR(20),
    delivery_instructions TEXT,
    
    -- Даты и время
    pickup_datetime TIMESTAMP,
    delivery_deadline TIMESTAMP,
    
    -- Статусы
    status VARCHAR(20) DEFAULT 'new' CHECK (status IN ('new', 'planned', 'in_transit', 'delivered', 'cancelled')),
    priority VARCHAR(20) DEFAULT 'normal' CHECK (priority IN ('normal', 'high', 'urgent')),
    
    -- Назначение транспорта
    vehicle_id INTEGER REFERENCES vehicles(id) ON DELETE SET NULL,
    driver_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    
    -- Трекинг
    actual_pickup_time TIMESTAMP,
    actual_delivery_time TIMESTAMP,
    
    -- Стоимость
    price DECIMAL(12, 2),
    currency VARCHAR(3) DEFAULT 'RUB',
    
    -- Документы
    loading_documents_url TEXT[],
    delivery_documents_url TEXT[],
    
    -- Создание и обновление
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    -- Дополнительные поля
    external_id VARCHAR(100), -- для интеграций
    metadata JSONB
);

-- Create comprehensive indexes for orders
CREATE INDEX idx_orders_client ON orders(client_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_priority ON orders(priority);
CREATE INDEX idx_orders_vehicle ON orders(vehicle_id);
CREATE INDEX idx_orders_created_at ON orders(created_at);
CREATE INDEX idx_orders_pickup_datetime ON orders(pickup_datetime);
CREATE INDEX idx_orders_delivery_deadline ON orders(delivery_deadline);
CREATE INDEX idx_orders_order_number ON orders(order_number);

-- Составной индекс для частых запросов
CREATE INDEX idx_orders_status_date ON orders(status, pickup_datetime);

-- ============================================
-- ORDER_HISTORY TABLE (Audit Log)
-- ============================================
CREATE TABLE order_history (
    id SERIAL PRIMARY KEY,
    order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(50) NOT NULL, -- created, updated, status_changed, assigned, etc.
    field_name VARCHAR(100),
    old_value TEXT,
    new_value TEXT,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index for order history lookups
CREATE INDEX idx_order_history_order ON order_history(order_id);
CREATE INDEX idx_order_history_created ON order_history(created_at);

-- ============================================
-- TRACKING_POINTS TABLE (GPS tracking)
-- ============================================
CREATE TABLE tracking_points (
    id SERIAL PRIMARY KEY,
    order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    vehicle_id INTEGER REFERENCES vehicles(id) ON DELETE SET NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    speed DECIMAL(5,2), -- км/ч
    heading INTEGER, -- направление 0-360
    accuracy INTEGER, -- точность GPS в метрах
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB
);

-- Create spatial index for tracking
CREATE INDEX idx_tracking_order ON tracking_points(order_id);
CREATE INDEX idx_tracking_timestamp ON tracking_points(timestamp);

-- ============================================
-- PAYMENTS TABLE
-- ============================================
CREATE TABLE payments (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES orders(id) ON DELETE CASCADE,
    client_id INTEGER REFERENCES clients(id) ON DELETE SET NULL,
    amount DECIMAL(12, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'RUB',
    payment_type VARCHAR(20) NOT NULL, -- prepaid, postpaid, partial
    payment_method VARCHAR(50), -- bank_transfer, cash, card
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'paid', 'overdue', 'cancelled')),
    payment_date TIMESTAMP,
    due_date TIMESTAMP,
    invoice_number VARCHAR(100),
    notes TEXT,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for payments
CREATE INDEX idx_payments_order ON payments(order_id);
CREATE INDEX idx_payments_client ON payments(client_id);
CREATE INDEX idx_payments_status ON payments(status);

-- ============================================
-- DOCUMENTS TABLE
-- ============================================
CREATE TABLE documents (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES orders(id) ON DELETE CASCADE,
    document_type VARCHAR(50) NOT NULL, -- loading_order, delivery_note, invoice, etc.
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INTEGER, -- в байтах
    mime_type VARCHAR(100),
    uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB
);

-- Create index for document lookups
CREATE INDEX idx_documents_order ON documents(order_id);
CREATE INDEX idx_documents_type ON documents(document_type);

-- ============================================
-- VIEWS
-- ============================================

-- View: Active Orders Summary
CREATE VIEW v_active_orders AS
SELECT 
    o.id,
    o.order_number,
    o.client_name,
    o.status,
    o.priority,
    o.pickup_address,
    o.delivery_address,
    o.pickup_datetime,
    o.delivery_deadline,
    v.plate_number AS vehicle_plate,
    v.driver_name AS assigned_driver,
    o.created_at,
    o.updated_at
FROM orders o
LEFT JOIN vehicles v ON o.vehicle_id = v.id
WHERE o.status IN ('new', 'planned', 'in_transit')
ORDER BY o.pickup_datetime;

-- View: Order Statistics by Day
CREATE VIEW v_daily_statistics AS
SELECT 
    DATE(created_at) AS order_date,
    COUNT(*) AS total_orders,
    COUNT(*) FILTER (WHERE status = 'new') AS new_orders,
    COUNT(*) FILTER (WHERE status = 'planned') AS planned_orders,
    COUNT(*) FILTER (WHERE status = 'in_transit') AS in_transit_orders,
    COUNT(*) FILTER (WHERE status = 'delivered') AS delivered_orders,
    COUNT(*) FILTER (WHERE priority = 'urgent') AS urgent_orders,
    SUM(weight_kg) AS total_weight_kg,
    SUM(volume_m3) AS total_volume_m3
FROM orders
GROUP BY DATE(created_at)
ORDER BY order_date DESC;

-- View: Vehicle Utilization
CREATE VIEW v_vehicle_utilization AS
SELECT 
    v.id AS vehicle_id,
    v.plate_number,
    v.type,
    v.status AS vehicle_status,
    COUNT(o.id) AS total_orders,
    COUNT(o.id) FILTER (WHERE o.status = 'in_transit') AS active_orders,
    COUNT(o.id) FILTER (WHERE o.status = 'delivered') AS completed_orders,
    MAX(o.pickup_datetime) AS last_order_date
FROM vehicles v
LEFT JOIN orders o ON v.id = o.vehicle_id
GROUP BY v.id, v.plate_number, v.type, v.status
ORDER BY total_orders DESC;

-- ============================================
-- FUNCTIONS
-- ============================================

-- Function: Generate Order Number
CREATE OR REPLACE FUNCTION generate_order_number()
RETURNS TRIGGER AS $$
BEGIN
    NEW.order_number := 'ORD-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || LPAD(NEW.id::TEXT, 6, '0');
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger: Auto-generate order number
CREATE TRIGGER trg_generate_order_number
    BEFORE INSERT ON orders
    FOR EACH ROW
    WHEN (NEW.order_number IS NULL)
    EXECUTE FUNCTION generate_order_number();

-- Function: Update Timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply update trigger to all tables with updated_at
CREATE TRIGGER trg_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_clients_updated_at
    BEFORE UPDATE ON clients
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_vehicles_updated_at
    BEFORE UPDATE ON vehicles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_orders_updated_at
    BEFORE UPDATE ON orders
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_payments_updated_at
    BEFORE UPDATE ON payments
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function: Log Order Changes
CREATE OR REPLACE FUNCTION log_order_changes()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO order_history (order_id, user_id, action, field_name, old_value, new_value)
        VALUES (NEW.id, NEW.created_by, 'created', NULL, NULL, row_to_json(NEW)::text);
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO order_history (order_id, user_id, action, field_name, old_value, new_value)
        VALUES (
            NEW.id,
            NULL, -- можно передать через session
            'status_changed',
            'status',
            OLD.status::text,
            NEW.status::text
        )
        WHERE OLD.status IS DISTINCT FROM NEW.status;
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Trigger: Log order changes
CREATE TRIGGER trg_log_order_changes
    AFTER INSERT OR UPDATE ON orders
    FOR EACH ROW EXECUTE FUNCTION log_order_changes();

-- ============================================
-- SEED DATA (Optional)
-- ============================================

-- Insert demo clients
INSERT INTO clients (name, company_name, phone, email, contact_person) VALUES
('ООО "ТехноПром"', 'ТехноПром', '+7 (495) 123-45-67', 'info@technoprom.ru', 'Иванов А.С.'),
('ИП Иванов А.В.', NULL, '+7 (916) 234-56-78', 'ivanov@example.com', 'Иванов А.В.'),
('ЗАО "ЛогистикГрупп"', 'ЛогистикГрупп', '+7 (495) 345-67-89', 'contact@logisticgroup.ru', 'Петров В.Д.'),
('ПАО "СтройМаш"', 'СтройМаш', '+7 (812) 456-78-90', 'info@stroymash.ru', 'Сидоров Г.Е.'),
('ООО "Агроторг"', 'Агроторг', '+7 (926) 567-89-01', 'agro@agrotorg.ru', 'Кузнецов Д.Ф.');

-- Insert demo vehicles
INSERT INTO vehicles (plate_number, type, brand, model, capacity_kg, volume_m3, driver_name, driver_phone, status) VALUES
('А123АА 777', 'Фура', 'Volvo', 'FH16', 20000, 82.0, 'Петров С.И.', '+7 (903) 111-22-33', 'available'),
('Б456ВВ 777', 'Газель', 'Gazelle', 'Business', 1500, 16.0, 'Сидоров А.А.', '+7 (903) 222-33-44', 'available'),
('В789СС 777', 'Фура', 'Mercedes', 'Actros', 22000, 90.0, 'Козлов Д.В.', '+7 (903) 333-44-55', 'in_transit'),
('Г012ДД 777', 'Рефрижератор', 'Scania', 'R450', 10000, 60.0, 'Новиков П.С.', '+7 (903) 444-55-66', 'available'),
('Д345ЕЕ 777', 'Газель', 'Gazelle', 'NN', 1600, 18.0, 'Морозов И.Г.', '+7 (903) 555-66-77', 'maintenance');

-- Insert demo users (passwords should be hashed in production)
INSERT INTO users (username, email, password_hash, role, full_name, phone) VALUES
('manager1', 'manager@tms.ru', 'hashed_password_here', 'manager', 'Анна Смирнова', '+7 (495) 100-00-01'),
('logistic1', 'logistic@tms.ru', 'hashed_password_here', 'logistic', 'Серги Петров', '+7 (495) 100-00-02'),
('admin', 'admin@tms.ru', 'hashed_password_here', 'admin', 'Администратор', '+7 (495) 100-00-00');

-- ============================================
-- COMMENTS
-- ============================================

COMMENT ON TABLE orders IS 'Таблица заявок на перевозку';
COMMENT ON COLUMN orders.status IS 'Статус: new-новая, planned-планируемая, in_transit-в пути, delivered-доставлена, cancelled-отменена';
COMMENT ON COLUMN orders.priority IS 'Приоритет: normal-обычный, high-высокий, urgent-срочный';
COMMENT ON TABLE tracking_points IS 'Точки GPS трекинга грузов';
COMMENT ON TABLE order_history IS 'История изменений заявок (аудит)';
