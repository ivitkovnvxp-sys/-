// OSRM маршрутизация - бесплатная альтернатива Яндекс Картам
class RouteCalculator {
    constructor() {
        this.osrmBaseURL = 'https://router.project-osrm.org/route/v1';
        this.osrmGeoURL = 'https://router.project-osrm.org/table/v1';
    }

    // Построить маршрут между точками
    async getRoute(points, profile = 'driving') {
        // points: [{lat, lng}, {lat, lng}, ...]
        // profile: 'driving', 'walking', 'cycling'
        
        if (points.length < 2) {
            throw new Error('Нужно минимум 2 точки для маршрута');
        }
        
        // Формат координат: lng,lat
        const coords = points.map(p => `${p.lng},${p.lat}`).join(';');
        const url = `${this.osrmBaseURL}/${profile}/${coords}?overview=full&geometries=geojson&steps=true`;
        
        try {
            const response = await fetch(url);
            const data = await response.json();
            
            if (data.code !== 'Ok') {
                throw new Error('Ошибка маршрутизации: ' + data.code);
            }
            
            return this.processRouteData(data.routes[0]);
        } catch (error) {
            console.error('Ошибка построения маршрута:', error);
            throw error;
        }
    }

    // Обработать данные маршрута
    processRouteData(route) {
        return {
            geometry: route.geometry, // GeoJSON координаты
            distance: route.distance, // метры
            duration: route.duration, // секунды
            legs: route.legs.map(leg => ({
                distance: leg.distance,
                duration: leg.duration,
                steps: leg.steps.map(step => ({
                    instruction: step.maneuver.instruction,
                    distance: step.distance,
                    duration: step.duration,
                    name: step.name || '',
                    mode: step.mode || 'driving'
                }))
            }))
        };
    }

    // Рассчитать таблицу расстояний между точками
    async getDistanceMatrix(points, profile = 'driving') {
        // points: [{lat, lng}, {lat, lng}, ...]
        
        if (points.length === 0) {
            throw new Error('Нет точек для расчёта');
        }
        
        const coords = points.map(p => `${p.lng},${p.lat}`).join(';');
        const url = `${this.osrmGeoURL}/${profile}/${coords}?sources=all&destinations=all`;
        
        try {
            const response = await fetch(url);
            const data = await response.json();
            
            if (data.code !== 'Ok') {
                throw new Error('Ошибка расчёта: ' + data.code);
            }
            
            return {
                distances: data.distances, // матрица расстояний (метры)
                durations: data.durations, // матрица времени (секунды)
                sources: data.sources,
                destinations: data.destinations
            };
        } catch (error) {
            console.error('Ошибка расчёта матрицы:', error);
            throw error;
        }
    }

    // Преобразовать GeoJSON в массив координат для Leaflet
    geojsonToLatLngs(geojson) {
        if (!geojson || !geojson.coordinates) return [];
        return geojson.coordinates.map(coord => [coord[1], coord[0]]);
    }

    // Расчитать время с учётом типа транспорта
    calculateTimeEstimate(distanceMeters, transportType) {
        const distanceKm = distanceMeters / 1000;
        
        // Средняя скорость по типу транспорта
        const speeds = {
            auto: 60,      // км/ч
            fly: 800,      // км/ч
            walking: 5,    // км/ч
            cycling: 20    // км/ч
        };
        
        const speed = speeds[transportType] || speeds.auto;
        const hours = distanceKm / speed;
        
        return {
            hours: Math.floor(hours),
            minutes: Math.round((hours - Math.floor(hours)) * 60),
            totalMinutes: Math.round(hours * 60),
            distanceKm: Math.round(distanceKm)
        };
    }

    // Оптимизировать порядок точек (TSP - Travelling Salesman Problem)
    async optimizeRoute(points, profile = 'driving') {
        if (points.length < 3) return points;
        
        try {
            // Получить матрицу расстояний
            const matrix = await this.getDistanceMatrix(points, profile);
            
            // Простой алгоритм ближайшего соседа
            const optimized = this.nearestNeighbor(points, matrix.distances);
            return optimized;
        } catch (error) {
            console.error('Ошибка оптимизации:', error);
            return points; // Возвращаем оригинальный порядок
        }
    }

    // Алгоритм ближайшего соседа
    nearestNeighbor(points, distances) {
        const n = points.length;
        const used = new Array(n).fill(false);
        const result = [];
        
        // Начинаем с первой точки
        let current = 0;
        used[current] = true;
        result.push(points[current]);
        
        // Идём к ближайшей непосещённой точке
        for (let i = 1; i < n; i++) {
            let nearest = -1;
            let minDist = Infinity;
            
            for (let j = 0; j < n; j++) {
                if (!used[j]) {
                    const dist = distances[current][j];
                    if (dist < minDist) {
                        minDist = dist;
                        nearest = j;
                    }
                }
            }
            
            if (nearest !== -1) {
                used[nearest] = true;
                result.push(points[nearest]);
                current = nearest;
            }
        }
        
        return result;
    }
}

// Экземпляр для использования
const routeCalculator = new RouteCalculator();
window.routeCalculator = routeCalculator;
