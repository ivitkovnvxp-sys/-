// Модуль календарного планирования (как в 1С)
class RoutePlanner {
    constructor() {
        this.orders = [];
        this.drivers = [];
        this.routeStages = []; // Прямые этапы из API
        this.savedRoutes = []; // Сохранённые маршруты с точками
        this.currentDate = new Date();
        this.planningDays = 7; // Уменьшил до 7 дней для компактности
        
        this.init();
    }

    init() {
        this.loadData();
        this.setupEventListeners();
        
        // Тестирование подключения к 1C API при загрузке
        setTimeout(() => {
            API_1C.testConnection().then(success => {
                if (success) {
                    console.log('✅ 1C API готов к работе');
                } else {
                    console.warn('⚠️ 1C API недоступен, используется режим моковых данных');
                }
            });
        }, 1000);
    }

    loadData() {
        // Загружаем данные из API 1C или моковые данные
        Promise.all([
            API_1C.getOrders(),
            API_1C.getDrivers(),
            API_1C.getRouteStages(),
            API_1C.getSavedRoutes()
        ]).then(([orders, drivers, routeStages, savedRoutes]) => {
            this.orders = orders.map(o => ({ ...o })); // Deep copy
            this.drivers = drivers.map(d => ({ ...d }));
            this.routeStages = routeStages; // Прямые этапы
            this.savedRoutes = savedRoutes; // Сохранённые маршруты с точками
            
            console.log('[Planner] Данные загружены:', {
                orders: this.orders.length,
                drivers: this.drivers.length,
                routeStages: this.routeStages.length,
                savedRoutes: this.savedRoutes.length
            });
            
            this.renderPlanner();
        }).catch(error => {
            console.error('[Planner] Ошибка загрузки данных:', error);
            // Возвращаем моковые данные при ошибке
            this.orders = JSON.parse(JSON.stringify(API_1C.mockOrders));
            this.drivers = JSON.parse(JSON.stringify(API_1C.mockDrivers));
            this.routeStages = JSON.parse(JSON.stringify(API_1C.mockRouteStages));
            this.savedRoutes = JSON.parse(JSON.stringify(API_1C.mockSavedRoutes));
            this.renderPlanner();
        });
    }

    setupEventListeners() {
        // Кнопки навигации - вешаем после рендера
        document.addEventListener('click', (e) => {
            if (e.target.id === 'planner-prev') {
                this.prevPeriod();
            }
            if (e.target.id === 'planner-next') {
                this.nextPeriod();
            }
        });
        
        document.getElementById('planner-filter-driver')?.addEventListener('change', () => this.renderPlanner());
        document.getElementById('planner-filter-status')?.addEventListener('change', () => this.renderPlanner());
    }

    getPeriodDates() {
        const dates = [];
        const start = new Date(this.currentDate);
        start.setDate(start.getDate() - Math.floor(this.planningDays / 2));
        
        for (let i = 0; i < this.planningDays; i++) {
            const date = new Date(start);
            date.setDate(date.getDate() + i);
            dates.push(date);
        }
        
        return dates;
    }

    renderPlanner() {
        const container = document.getElementById('planner-grid');
        if (!container) return;
        
        const dates = this.getPeriodDates();
        const driverFilter = document.getElementById('planner-filter-driver')?.value || 'all';
        const statusFilter = document.getElementById('planner-filter-status')?.value || 'all';
        
        // Фильтруем заявки
        let filteredOrders = this.orders.filter(o => {
            if (statusFilter !== 'all' && o.status !== statusFilter) return false;
            return o.status === 'new' || o.status === 'planned';
        });
        
        // Получаем этапы из маршрутов
        const routeStages = this.extractRouteStages();
        
        container.innerHTML = `
            <div class="planner-toolbar">
                <button class="btn btn-secondary" id="planner-prev">◀ Назад</button>
                <div class="planner-period-info">
                    <h3>Планирование: ${this.formatPeriod(dates[0], dates[dates.length-1])}</h3>
                </div>
                <button class="btn btn-secondary" id="planner-next">Вперёд ▶</button>
                
                <div class="planner-filters">
                    <select id="planner-filter-driver">
                        <option value="all">Все водители</option>
                        ${this.drivers.map(d => `<option value="${d.id}">${this.escapeHtml(d.name)}</option>`).join('')}
                    </select>
                    <select id="planner-filter-status">
                        <option value="all">Все статусы</option>
                        <option value="new">Новые</option>
                        <option value="planned">Планированные</option>
                    </select>
                    <button class="btn btn-primary" onclick="logistic.showNewRouteModal()">➕ Новый маршрут</button>
                </div>
            </div>
            
            <div class="planner-wrapper">
                <div class="planner-grid">
                    <div class="planner-header">
                        <div class="planner-header-cell sticky">Водитель</div>
                        ${dates.map(date => `
                            <div class="planner-header-cell ${this.isToday(date) ? 'today' : ''}">
                                <div class="date-day">${date.toLocaleDateString('ru-RU', { weekday: 'short' })}</div>
                                <div class="date-number">${date.getDate()}</div>
                                <div class="date-month">${date.toLocaleDateString('ru-RU', { month: 'short' })}</div>
                            </div>
                        `).join('')}
                    </div>
                    
                    <div class="planner-body">
                        ${this.renderPlannerRows(filteredOrders, routeStages, dates, driverFilter)}
                    </div>
                </div>
            </div>
            
            <!-- Календарь событий -->
            <div class="events-calendar-section">
                <h3>📅 Календарь событий</h3>
                ${this.renderEventsCalendar(filteredOrders, routeStages, dates)}
            </div>
        `;
    }

    renderEventsCalendar(orders, routeStages, dates) {
        const allEvents = [];
        
        // Собираем все заявки
        orders.forEach(order => {
            const orderDate = order.orderDate?.split('T')[0];
            if (orderDate) {
                allEvents.push({
                    type: 'order',
                    date: orderDate,
                    data: order,
                    driverId: order.assignedDriver
                });
            }
        });
        
        // Собираем все этапы
        routeStages.forEach(stage => {
            if (stage.date) {
                allEvents.push({
                    type: 'stage',
                    date: stage.date,
                    data: stage,
                    driverId: stage.driverId
                });
            }
        });
        
        // Группируем по датам
        const eventsByDate = {};
        allEvents.forEach(event => {
            if (!eventsByDate[event.date]) {
                eventsByDate[event.date] = [];
            }
            eventsByDate[event.date].push(event);
        });
        
        // Сортируем даты
        const sortedDates = Object.keys(eventsByDate).sort();
        
        if (sortedDates.length === 0) {
            return '<div class="empty-calendar">Нет запланированных событий</div>';
        }
        
        return `
            <div class="events-calendar">
                ${sortedDates.map(date => {
                    const dateObj = new Date(date);
                    const dayEvents = eventsByDate[date];
                    const weekday = dateObj.toLocaleDateString('ru-RU', { weekday: 'long' });
                    
                    return `
                        <div class="calendar-day">
                            <div class="calendar-date-header">
                                <span class="calendar-date">${dateObj.getDate()} ${dateObj.toLocaleDateString('ru-RU', { month: 'long' })}</span>
                                <span class="calendar-weekday">${weekday}</span>
                                <span class="calendar-count">${dayEvents.length} событий</span>
                            </div>
                            <div class="calendar-events-list">
                                ${dayEvents.map(event => this.renderCalendarEvent(event)).join('')}
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
        `;
    }

    renderCalendarEvent(event) {
        const driverName = event.driverId ? 
            this.drivers.find(d => d.id == event.driverId)?.name || 'Без водителя' : 
            '📋 Без назначения';
        
        if (event.type === 'order') {
            const order = event.data;
            return `
                <div class="calendar-event-item order-event">
                    <div class="event-icon">📦</div>
                    <div class="event-details">
                        <div class="event-title">Заявка #${order.id} - ${this.escapeHtml(order.client)}</div>
                        <div class="event-meta">
                            <span class="event-driver">👤 ${this.escapeHtml(driverName)}</span>
                            <span class="event-status status-${order.status}">${this.getStatusText(order.status)}</span>
                        </div>
                    </div>
                    <button class="btn-view" onclick="logistic.showRoute(${order.id})">👁️</button>
                </div>
            `;
        } else {
            const stage = event.data;
            return `
                <div class="calendar-event-item stage-event">
                    <div class="event-icon">🛣️</div>
                    <div class="event-details">
                        <div class="event-title">Этап: ${this.escapeHtml(stage.routeName)}</div>
                        <div class="event-meta">
                            <span class="event-driver">👤 ${this.escapeHtml(driverName)}</span>
                            <span class="event-address">${this.truncate(stage.address, 30)}</span>
                        </div>
                    </div>
                    <button class="btn-view" onclick="logistic.loadRoute(${stage.routeId})">👁️</button>
                </div>
            `;
        }
    }

    getStatusText(status) {
        const texts = {
            'new': 'Новая',
            'planned': 'Планированная',
            'in_transit': 'В пути',
            'delivered': 'Доставлена'
        };
        return texts[status] || status;
    }

    extractRouteStages() {
        const stages = [];
        
        // Собираем этапы из сохранённых маршрутов
        this.savedRoutes.forEach(route => {
            route.points.forEach((point, index) => {
                if (point.date) {
                    stages.push({
                        id: `route-${route.id}-point-${point.id}`,
                        routeId: route.id,
                        routeName: route.name,
                        pointIndex: index,
                        date: point.date,
                        address: point.address,
                        driverId: point.driverId || null,
                        type: 'route_stage'
                    });
                }
            });
        });
        
        // Добавляем прямые этапы из routeStages
        this.routeStages.forEach(stage => {
            stages.push({
                id: stage.id,
                routeId: stage.routeId,
                routeName: stage.routeName,
                date: stage.date,
                address: stage.address,
                driverId: stage.driverId,
                type: 'route_stage'
            });
        });
        
        return stages;
    }

    renderPlannerRows(orders, routeStages, dates, driverFilter) {
        const rows = [];
        
        // Для каждого водителя создаём строку
        this.drivers.forEach(driver => {
            if (driverFilter !== 'all' && driverFilter != driver.id) return;
            
            // Заявки назначенные этому водителю
            const driverOrders = orders.filter(o => o.assignedDriver == driver.id);
            
            // Этапы маршрутов этого водителя
            const driverStages = routeStages.filter(s => s.driverId == driver.id);
            
            // Объединяем все события для этого водителя
            const allEvents = [];
            
            driverOrders.forEach(order => {
                const orderDate = order.orderDate?.split('T')[0];
                allEvents.push({
                    type: 'order',
                    date: orderDate,
                    data: order,
                    id: order.id
                });
            });
            
            driverStages.forEach(stage => {
                allEvents.push({
                    type: 'stage',
                    date: stage.date,
                    data: stage,
                    id: stage.id
                });
            });
            
            rows.push(`
                <div class="planner-row">
                    <div class="planner-row-header sticky">
                        <strong>${this.escapeHtml(driver.name)}</strong>
                        <small>${allEvents.length} событий</small>
                    </div>
                    ${dates.map(date => {
                        const dateStr = date.toISOString().split('T')[0];
                        const dayEvents = allEvents.filter(e => e.date === dateStr);
                        
                        return `
                            <div class="planner-cell ${dayEvents.length > 0 ? 'has-events' : ''}">
                                ${dayEvents.map(event => this.renderEventCard(event)).join('')}
                            </div>
                        `;
                    }).join('')}
                </div>
            `);
        });
        
        // Незапланированные заявки (без водителя)
        const unassignedOrders = orders.filter(o => !o.assignedDriver);
        if (unassignedOrders.length > 0 && (driverFilter === 'all' || driverFilter === 'unassigned')) {
            const allEvents = unassignedOrders.map(order => ({
                type: 'order',
                date: order.orderDate?.split('T')[0],
                data: order,
                id: order.id
            }));
            
            rows.push(`
                <div class="planner-row unassigned">
                    <div class="planner-row-header sticky">
                        <strong>📋 Без назначения</strong>
                        <small>${allEvents.length} заявок</small>
                    </div>
                    ${dates.map(date => {
                        const dateStr = date.toISOString().split('T')[0];
                        const dayEvents = allEvents.filter(e => e.date === dateStr);
                        
                        return `
                            <div class="planner-cell ${dayEvents.length > 0 ? 'has-events' : ''}">
                                ${dayEvents.map(event => this.renderEventCard(event)).join('')}
                            </div>
                        `;
                    }).join('')}
                </div>
            `);
        }
        
        return rows.join('');
    }

    renderEventCard(event) {
        if (!event.date) return '';
        
        if (event.type === 'order') {
            const order = event.data;
            return `
                <div class="event-card order-card" onclick="logistic.showRoute(${order.id})">
                    <div class="event-badge status-${order.status}"></div>
                    <div class="event-id">#${order.id}</div>
                    <div class="event-client">${this.truncate(order.client, 12)}</div>
                </div>
            `;
        } else {
            const stage = event.data;
            return `
                <div class="event-card stage-card" onclick="logistic.loadRoute(${stage.routeId})">
                    <div class="event-badge stage-badge">Этап</div>
                    <div class="event-route">${this.truncate(stage.routeName, 12)}</div>
                </div>
            `;
        }
    }

    prevPeriod() {
        this.currentDate.setDate(this.currentDate.getDate() - this.planningDays);
        this.renderPlanner();
    }

    nextPeriod() {
        this.currentDate.setDate(this.currentDate.getDate() + this.planningDays);
        this.renderPlanner();
    }

    isToday(date) {
        const today = new Date();
        return date.toDateString() === today.toDateString();
    }

    formatPeriod(start, end) {
        const options1 = { day: '2-digit', month: 'short' };
        const options2 = { day: '2-digit', month: 'short', year: 'numeric' };
        return `${start.toLocaleDateString('ru-RU', options1)} - ${end.toLocaleDateString('ru-RU', options2)}`;
    }

    truncate(text, maxLength) {
        if (!text) return '-';
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength) + '...';
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Инициализация
let planner;
document.addEventListener('DOMContentLoaded', () => {
    planner = new RoutePlanner();
    window.planner = planner;
});
