// API слой для взаимодействия с backend
class TMSAPI {
    constructor() {
        // Для демонстрации используем localStorage
        // В production заменить на реальный API endpoint
        this.baseURL = '/api';
        this.useMock = true;
    }

    // Методы для работы с заявками
    async getOrders() {
        if (this.useMock) {
            return this.mockGetOrders();
        }
        const response = await fetch(`${this.baseURL}/orders`);
        return response.json();
    }

    async createOrder(orderData) {
        if (this.useMock) {
            return this.mockCreateOrder(orderData);
        }
        const response = await fetch(`${this.baseURL}/orders`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });
        return response.json();
    }

    async updateOrder(orderId, orderData) {
        if (this.useMock) {
            return this.mockUpdateOrder(orderId, orderData);
        }
        const response = await fetch(`${this.baseURL}/orders/${orderId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(orderData)
        });
        return response.json();
    }

    async deleteOrder(orderId) {
        if (this.useMock) {
            return this.mockDeleteOrder(orderId);
        }
        const response = await fetch(`${this.baseURL}/orders/${orderId}`, {
            method: 'DELETE'
        });
        return response.json();
    }

    // Методы для работы с клиентами
    async getClients() {
        if (this.useMock) {
            return this.mockGetClients();
        }
        const response = await fetch(`${this.baseURL}/clients`);
        return response.json();
    }

    async searchClients(query) {
        if (this.useMock) {
            return this.mockSearchClients(query);
        }
        const response = await fetch(`${this.baseURL}/clients/search?q=${query}`);
        return response.json();
    }

    async createClient(clientData) {
        if (this.useMock) {
            return this.mockCreateClient(clientData);
        }
        const response = await fetch(`${this.baseURL}/clients`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(clientData)
        });
        return response.json();
    }

    // Методы для работы с транспортными средствами
    async getVehicles() {
        if (this.useMock) {
            return this.mockGetVehicles();
        }
        const response = await fetch(`${this.baseURL}/vehicles`);
        return response.json();
    }

    // Методы для работы с адресами (геокодинг)
    async geocodeAddress(address) {
        // Используем Nominatim API (бесплатный, не требует ключа)
        const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}&limit=5`;
        const response = await fetch(url);
        return response.json();
    }

    async reverseGeocode(lat, lng) {
        const url = `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`;
        const response = await fetch(url);
        return response.json();
    }

    // Методы для отчетов
    async getReport(startDate, endDate) {
        if (this.useMock) {
            return this.mockGetReport(startDate, endDate);
        }
        const response = await fetch(
            `${this.baseURL}/reports?start=${startDate}&end=${endDate}`
        );
        return response.json();
    }

    // MOCK методы для демонстрации
    mockGetOrders() {
        const orders = JSON.parse(localStorage.getItem('orders') || '[]');
        return Promise.resolve(orders);
    }

    mockCreateOrder(orderData) {
        const orders = JSON.parse(localStorage.getItem('orders') || '[]');
        const newOrder = {
            id: Date.now(),
            ...orderData,
            status: 'new',
            createdAt: new Date().toISOString(),
            pickupCoords: orderData.pickupCoords || null,
            deliveryCoords: orderData.deliveryCoords || null
        };
        orders.push(newOrder);
        localStorage.setItem('orders', JSON.stringify(orders));
        return Promise.resolve(newOrder);
    }

    mockUpdateOrder(orderId, orderData) {
        const orders = JSON.parse(localStorage.getItem('orders') || '[]');
        const index = orders.findIndex(o => o.id == orderId);
        if (index === -1) {
            return Promise.reject(new Error('Order not found'));
        }
        orders[index] = { ...orders[index], ...orderData };
        localStorage.setItem('orders', JSON.stringify(orders));
        return Promise.resolve(orders[index]);
    }

    mockDeleteOrder(orderId) {
        let orders = JSON.parse(localStorage.getItem('orders') || '[]');
        orders = orders.filter(o => o.id != orderId);
        localStorage.setItem('orders', JSON.stringify(orders));
        return Promise.resolve({ success: true });
    }

    mockGetClients() {
        const clients = JSON.parse(localStorage.getItem('clients') || '[]');
        if (clients.length === 0) {
            // Создадим тестовые данные
            const testClients = [
                { id: 1, name: 'ООО "ТехноПром"', phone: '+7 (495) 123-45-67', email: 'info@technoprom.ru' },
                { id: 2, name: 'ИП Иванов А.В.', phone: '+7 (916) 234-56-78', email: 'ivanov@example.com' },
                { id: 3, name: 'ЗАО "ЛогистикГрупп"', phone: '+7 (495) 345-67-89', email: 'contact@logisticgroup.ru' },
                { id: 4, name: 'ПАО "СтройМаш"', phone: '+7 (812) 456-78-90', email: 'info@stroymash.ru' },
                { id: 5, name: 'ООО "Агроторг"', phone: '+7 (926) 567-89-01', email: 'agro@agrotorg.ru' }
            ];
            localStorage.setItem('clients', JSON.stringify(testClients));
            return Promise.resolve(testClients);
        }
        return Promise.resolve(clients);
    }

    mockSearchClients(query) {
        return this.mockGetClients().then(clients => {
            const lowerQuery = query.toLowerCase();
            return clients.filter(c => 
                c.name.toLowerCase().includes(lowerQuery) ||
                c.email?.toLowerCase().includes(lowerQuery)
            );
        });
    }

    mockCreateClient(clientData) {
        return this.mockGetClients().then(clients => {
            const newClient = {
                id: Date.now(),
                ...clientData
            };
            clients.push(newClient);
            localStorage.setItem('clients', JSON.stringify(clients));
            return newClient;
        });
    }

    mockGetVehicles() {
        const vehicles = [
            { id: 1, plate: 'А123АА 777', type: 'Фура', capacity: 20000, transport: 'auto', status: 'available', driver: 'Петров С.И.' },
            { id: 2, plate: 'Б456ВВ 777', type: 'Газель', capacity: 1500, transport: 'auto', status: 'available', driver: 'Сидоров А.А.' },
            { id: 3, plate: 'В789СС 777', type: 'Фура', capacity: 22000, transport: 'auto', status: 'in_transit', driver: 'Козлов Д.В.' },
            { id: 4, plate: 'Г012ДД 777', type: 'Рефрижератор', capacity: 10000, transport: 'auto', status: 'available', driver: 'Новиков П.С.' },
            { id: 5, plate: 'Д345ЕЕ 777', type: 'Газель', capacity: 1600, transport: 'auto', status: 'maintenance', driver: 'Морозов И.Г.' },
            // Авиатехника для экспресс-заявок
            { id: 6, plate: 'SU-001', type: 'Авиаборт №1', capacity: 5000, transport: 'fly', status: 'available', driver: 'Летов А.П.' },
            { id: 7, plate: 'SU-002', type: 'Авиаборт №2', capacity: 8000, transport: 'fly', status: 'available', driver: 'Волков С.М.' },
            { id: 8, plate: 'SU-003', type: 'Авиаборт №3', capacity: 3000, transport: 'fly', status: 'in_transit', driver: 'Орлов В.К.' }
        ];
        return Promise.resolve(vehicles);
    }

    mockGetReport(startDate, endDate) {
        return this.mockGetOrders().then(orders => {
            const start = new Date(startDate);
            const end = new Date(endDate);
            const filtered = orders.filter(o => {
                const date = new Date(o.createdAt);
                return date >= start && date <= end;
            });
            
            const stats = {
                total: filtered.length,
                delivered: filtered.filter(o => o.status === 'delivered').length,
                inTransit: filtered.filter(o => o.status === 'in_transit').length,
                planned: filtered.filter(o => o.status === 'planned').length,
                new: filtered.filter(o => o.status === 'new').length
            };
            
            return { orders: filtered, stats };
        });
    }

    // Поиск адресов через Nominatim
    async searchAddresses(query) {
        if (!query || query.length < 3) {
            return [];
        }
        
        try {
            const url = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=10&countrycodes=ru`;
            const response = await fetch(url);
            const data = await response.json();
            return data.map(item => ({
                display_name: item.display_name,
                lat: parseFloat(item.lat),
                lon: parseFloat(item.lon),
                address: item.display_name
            }));
        } catch (error) {
            console.error('Ошибка геокодинга:', error);
            return [];
        }
    }
}

// Экземпляр API
const api = new TMSAPI();
