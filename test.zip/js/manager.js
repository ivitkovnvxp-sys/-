// Модуль менеджера - работа с заявками
class ManagerModule {
    constructor() {
        this.form = document.getElementById('order-form');
        this.ordersTable = document.getElementById('orders-table').querySelector('tbody');
        this.addressInputs = document.querySelectorAll('.address-input');
        this.debounceTimers = {};
        
        this.init();
    }

    init() {
        // Обработка формы
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        
        // Очистка формы
        document.getElementById('btn-clear').addEventListener('click', () => this.clearForm());
        
        // Настройка автодополнения адресов
        this.setupAddressAutocomplete();
        
        // Настройка автодополнения клиентов
        this.setupClientAutocomplete();
        
        // Установка минимальной даты
        this.setMinDate();
        
        // Загрузка заявок
        this.loadOrders();
    }

    setMinDate() {
        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        document.getElementById('order-date').min = now.toISOString().slice(0, 16);
    }

    setupAddressAutocomplete() {
        this.addressInputs.forEach(input => {
            const suggestionsBox = document.getElementById(
                input.id === 'pickup-address' ? 'pickup-suggestions' : 'delivery-suggestions'
            );
            
            input.addEventListener('input', () => {
                clearTimeout(this.debounceTimers[input.id]);
                
                const query = input.value.trim();
                if (query.length < 3) {
                    suggestionsBox.classList.remove('active');
                    return;
                }

                this.debounceTimers[input.id] = setTimeout(() => {
                    this.searchAddresses(query, suggestionsBox, input);
                }, 300);
            });

            // Закрытие подсказок при клике вне
            document.addEventListener('click', (e) => {
                if (!input.contains(e.target) && !suggestionsBox.contains(e.target)) {
                    suggestionsBox.classList.remove('active');
                }
            });
        });
    }

    async searchAddresses(query, suggestionsBox, input) {
        const addresses = await api.searchAddresses(query);
        
        if (addresses.length === 0) {
            suggestionsBox.classList.remove('active');
            return;
        }

        suggestionsBox.innerHTML = addresses.map(addr => `
            <div class="suggestion-item" data-lat="${addr.lat}" data-lon="${addr.lon}" data-address="${addr.address}">
                ${addr.address}
            </div>
        `).join('');

        suggestionsBox.classList.add('active');

        // Обработка клика
        suggestionsBox.querySelectorAll('.suggestion-item').forEach(item => {
            item.addEventListener('click', () => {
                input.value = item.dataset.address;
                input.dataset.lat = item.dataset.lat;
                input.dataset.lon = item.dataset.lon;
                suggestionsBox.classList.remove('active');
            });
        });

        // Навигация клавишами
        input.addEventListener('keydown', (e) => {
            const items = suggestionsBox.querySelectorAll('.suggestion-item');
            const highlighted = suggestionsBox.querySelector('.highlighted');
            let index = highlighted ? Array.from(items).indexOf(highlighted) : -1;

            if (e.key === 'ArrowDown') {
                e.preventDefault();
                index = Math.min(index + 1, items.length - 1);
                this.highlightSuggestion(items, index);
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                index = Math.max(index - 1, 0);
                this.highlightSuggestion(items, index);
            } else if (e.key === 'Enter' && highlighted) {
                e.preventDefault();
                highlighted.click();
            }
        });
    }

    highlightSuggestion(items, index) {
        items.forEach(item => item.classList.remove('highlighted'));
        if (index >= 0) {
            items[index].classList.add('highlighted');
            items[index].scrollIntoView({ block: 'nearest' });
        }
    }

    setupClientAutocomplete() {
        api.getClients().then(clients => {
            const datalist = document.getElementById('clients-list');
            datalist.innerHTML = clients.map(client => 
                `<option value="${client.name}" data-phone="${client.phone}"></option>`
            ).join('');
        });
    }

    async handleSubmit(e) {
        e.preventDefault();

        const formData = new FormData(this.form);
        const orderData = {
            client: formData.get('client'),
            orderType: formData.get('order-type'),
            pickupAddress: formData.get('pickup-address'),
            pickupCoords: {
                lat: parseFloat(document.getElementById('pickup-address').dataset.lat),
                lng: parseFloat(document.getElementById('pickup-address').dataset.lon)
            },
            pickupContact: formData.get('pickup-contact'),
            pickupPhone: formData.get('pickup-phone'),
            deliveryAddress: formData.get('delivery-address'),
            deliveryCoords: {
                lat: parseFloat(document.getElementById('delivery-address').dataset.lat),
                lng: parseFloat(document.getElementById('delivery-address').dataset.lon)
            },
            deliveryContact: formData.get('delivery-contact'),
            deliveryPhone: formData.get('delivery-phone'),
            cargoType: formData.get('cargo-type'),
            weight: formData.get('weight'),
            volume: formData.get('volume'),
            orderDate: formData.get('order-date'),
            deadline: formData.get('deadline'),
            priority: formData.get('priority'),
            comments: formData.get('comments')
        };

        try {
            const order = await api.createOrder(orderData);
            this.showNotification('Заявка успешно создана!');
            this.clearForm();
            this.loadOrders();
        } catch (error) {
            this.showNotification('Ошибка при создании заявки', 'error');
            console.error(error);
        }
    }

    clearForm() {
        this.form.reset();
        document.querySelectorAll('.address-input').forEach(input => {
            delete input.dataset.lat;
            delete input.dataset.lon;
        });
    }

    async loadOrders() {
        try {
            const orders = await api.getOrders();
            this.renderOrdersTable(orders);
        } catch (error) {
            console.error('Ошибка загрузки заявок:', error);
        }
    }

    renderOrdersTable(orders) {
        if (orders.length === 0) {
            this.ordersTable.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px;">
                        Нет активных заявок
                    </td>
                </tr>
            `;
            return;
        }

        this.ordersTable.innerHTML = orders
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
            .map(order => `
                <tr data-id="${order.id}">
                    <td>#${order.id}</td>
                    <td>${this.escapeHtml(order.client)}</td>
                    <td>${this.escapeHtml(order.pickupAddress)}</td>
                    <td>${this.escapeHtml(order.deliveryAddress)}</td>
                    <td>${this.formatDate(order.orderDate)}</td>
                    <td>
                        <span class="status-badge status-${this.getStatusClass(order.status)}">
                            ${this.getStatusText(order.status)}
                        </span>
                    </td>
                    <td>
                        <button class="btn btn-small" onclick="manager.editOrder(${order.id})">
                            ✏️
                        </button>
                        <button class="btn btn-small" onclick="manager.deleteOrder(${order.id})">
                            🗑️
                        </button>
                        <button class="btn btn-small" onclick="manager.viewOnMap(${order.id})">
                            🗺️
                        </button>
                    </td>
                </tr>
            `).join('');
    }

    getStatusClass(status) {
        const statusMap = {
            'new': 'new',
            'planned': 'planned',
            'in_transit': 'in-transit',
            'delivered': 'delivered'
        };
        return statusMap[status] || 'new';
    }

    getStatusText(status) {
        const statusText = {
            'new': 'Новая',
            'planned': 'Планированная',
            'in_transit': 'В пути',
            'delivered': 'Доставлена'
        };
        return statusText[status] || 'Новая';
    }

    formatDate(dateString) {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU', {
            day: '2-digit',
            month: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    async editOrder(orderId) {
        try {
            const orders = await api.getOrders();
            const order = orders.find(o => o.id == orderId);
            if (!order) return;

            // Заполнение формы данными заявки
            document.getElementById('client').value = order.client;
            document.getElementById('order-type').value = order.orderType;
            document.getElementById('pickup-address').value = order.pickupAddress;
            document.getElementById('pickup-address').dataset.lat = order.pickupCoords?.lat;
            document.getElementById('pickup-address').dataset.lon = order.pickupCoords?.lng;
            document.getElementById('pickup-contact').value = order.pickupContact || '';
            document.getElementById('pickup-phone').value = order.pickupPhone || '';
            document.getElementById('delivery-address').value = order.deliveryAddress;
            document.getElementById('delivery-address').dataset.lat = order.deliveryCoords?.lat;
            document.getElementById('delivery-address').dataset.lon = order.deliveryCoords?.lng;
            document.getElementById('delivery-contact').value = order.deliveryContact || '';
            document.getElementById('delivery-phone').value = order.deliveryPhone || '';
            document.getElementById('cargo-type').value = order.cargoType || 'general';
            document.getElementById('weight').value = order.weight || '';
            document.getElementById('volume').value = order.volume || '';
            document.getElementById('order-date').value = order.orderDate;
            document.getElementById('deadline').value = order.deadline || '';
            document.getElementById('priority').value = order.priority || 'normal';
            document.getElementById('comments').value = order.comments || '';

            // Скролл к форме
            this.form.scrollIntoView({ behavior: 'smooth' });
        } catch (error) {
            console.error('Ошибка загрузки данных заявки:', error);
        }
    }

    async deleteOrder(orderId) {
        if (!confirm('Вы уверены, что хотите удалить эту заявку?')) {
            return;
        }

        try {
            await api.deleteOrder(orderId);
            this.showNotification('Заявка удалена');
            this.loadOrders();
        } catch (error) {
            this.showNotification('Ошибка при удалении', 'error');
        }
    }

    viewOnMap(orderId) {
        // Переключаемся на вкладку карты
        document.querySelector('[data-view="map"]').click();
        
        // Через небольшую задержку показываем маркер
        setTimeout(() => {
            if (window.mapModule) {
                window.mapModule.focusOnOrder(orderId);
            }
        }, 500);
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.add('active'), 10);
        setTimeout(() => {
            notification.classList.remove('active');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}

// Инициализация
let manager;
document.addEventListener('DOMContentLoaded', () => {
    manager = new ManagerModule();
    window.manager = manager;
});
