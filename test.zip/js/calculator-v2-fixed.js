// ============================================
// КАЛЬКУЛЯТОР "ВТОРАЯ МИЛЯ" - Полная версия
// ============================================

var tmsCities = {};
var selectedCity = null;
var tmsMap = null;
var isFullscreen = false;

// Форматирование валюты - доступно сразу
var formatCurrency = function(amount) {
    return amount.toLocaleString('ru-RU', { style: 'currency', currency: 'RUB' });
};

// Переключение табов - доступно сразу
var showCalcTab = function(tabId, event) {
    console.log('showCalcTab called:', tabId);
    if (event && event.target) event.target.classList.add('active');
    document.querySelectorAll('.calc-tab-btn').forEach(function(btn) { 
        if (btn.getAttribute('onclick') && btn.getAttribute('onclick').includes(tabId)) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
    document.querySelectorAll('.calc-tab-content').forEach(function(content) { 
        if (content.id === tabId) {
            content.classList.add('active');
        } else {
            content.classList.remove('active');
        }
    });
};

// Экспорт в window сразу
window.formatCurrency = formatCurrency;
window.showCalcTab = showCalcTab;

console.log('✅ Calculator core functions loaded');

// Координаты городов
const TMS_CITY_COORDS = {
    "Москва": [55.7558, 37.6173], "Санкт-Петербург": [59.9343, 30.3351],
    "Екатеринбург": [56.8389, 60.6057], "Новосибирск": [55.0084, 82.9357],
    "Владивосток": [43.1155, 131.8855], "Казань": [55.8304, 49.0661],
    "Краснодар": [45.0355, 38.9753], "Ростов-на-Дону": [47.2221, 39.7203],
    "Самара": [53.1959, 50.1008], "Уфа": [54.7388, 55.9721],
    "Воронеж": [51.6708, 39.2113], "Ярославль": [57.6260, 39.8935],
    "Рязань": [54.6194, 39.7319], "Тула": [54.1931, 37.6177],
    "Калуга": [54.5069, 36.2514], "Тверь": [56.8584, 35.9006],
    "Брянск": [53.2421, 34.3693], "Курск": [51.7308, 36.1930],
    "Белгород": [50.5955, 36.5873], "Липецк": [52.6088, 39.5991],
    "Орёл": [52.9703, 36.0637], "Смоленск": [54.7826, 31.8696],
    "Тамбов": [52.7213, 41.4523], "Иваново": [56.9993, 40.9720],
    "Владимир": [56.1289, 40.4072], "Кострома": [57.7673, 40.9268],
    "Нижний Новгород": [56.2965, 43.9361], "Пермь": [58.0105, 56.2294],
    "Оренбург": [51.7682, 55.0970], "Ижевск": [56.8526, 53.2067],
    "Чебоксары": [56.1442, 47.2488], "Киров": [58.6033, 49.6679],
    "Саранск": [54.1939, 45.1837], "Йошкар-Ола": [56.6328, 47.8953],
    "Саратов": [51.5331, 45.9728], "Пенза": [53.2521, 45.0165],
    "Ульяновск": [54.3170, 48.4026], "Волгоград": [48.7071, 44.5170],
    "Астрахань": [46.3472, 48.3046], "Ставрополь": [45.0448, 41.9694],
    "Майкоп": [44.6093, 40.1007], "Элиста": [46.3084, 44.2701],
    "Нальчик": [43.4853, 43.6078], "Черкесск": [44.2268, 42.0578],
    "Сочи": [43.6028, 39.7342], "Тольятти": [53.5077, 49.4203],
    "Тюмень": [57.1530, 65.5343], "Челябинск": [55.1644, 61.4368],
    "Курган": [55.4573, 65.3181], "Омск": [54.9924, 73.3686],
    "Красноярск": [56.0153, 92.8932], "Иркутск": [52.2970, 104.2965],
    "Барнаул": [53.3548, 83.7698], "Томск": [56.4951, 84.9722],
    "Кемерово": [55.3543, 86.0874], "Новокузнецк": [53.7575, 87.1098],
    "Улан-Удэ": [51.8344, 107.5843], "Абакан": [53.7224, 91.4423],
    "Горно-Алтайск": [51.7923, 85.9767], "Хабаровск": [48.4802, 135.0719],
    "Магадан": [59.5682, 150.8086], "Сургут": [61.2540, 73.3968],
    "Нижневартовск": [60.9400, 76.5300], "Петропавловск-Камчатский": [53.0452, 158.6511],
    "Якутск": [62.0276, 129.7321], "Южно-Сахалинск": [46.9540, 142.7360],
    "Благовещенск": [50.2900, 127.5300], "Анадырь": [64.7337, 177.5144],
    "Махачкала": [42.9849, 47.5037], "Калининград": [54.7075, 20.5073],
    "Мурманск": [68.9585, 33.0827], "Архангельск": [64.5440, 40.5145],
    "Петрозаводск": [61.7851, 34.3466], "Сыктывкар": [61.6640, 50.8089],
    "Псков": [57.8193, 28.3300], "Вологда": [59.2239, 39.8830],
    "Череповец": [59.1333, 37.9000], "Новгород": [58.5215, 31.2755],
    "Симферополь": [44.9480, 34.1131], "Севастополь": [44.5431, 33.5308]
};

// Города по умолчанию - 100+ городов
const TMS_DEFAULT_CITIES = {
    "Москва": {"region":"Москва","terminal":"г. Москва, ул. Промышленная, д. 10","transport_type":"auto","mile1_type":"fixed","mile1_price":500,"mile2_prices":{50:18,100:15,150:12,200:10},"mile2_price":15,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Санкт-Петербург": {"region":"Санкт-Петербург","terminal":"г. Санкт-Петербург, ул. Промышленная, д. 5","transport_type":"auto","mile1_type":"fixed","mile1_price":450,"mile2_prices":{50:21,100:18,150:15,200:13},"mile2_price":18,"mile3_type":"fixed","mile3_price":60,"remote_cities":{"Мурманск":120,"Калининград":80}},
    "Екатеринбург": {"region":"Свердловская область","terminal":"г. Екатеринбург, ул. Промышленная, д. 8","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:23,100:20,150:17,200:15},"mile2_price":20,"mile3_type":"fixed","mile3_price":70,"remote_cities":{"Тюмень":50}},
    "Новосибирск": {"region":"Новосибирская область","terminal":"г. Новосибирск, ул. Промышленная, д. 12","transport_type":"auto","mile1_type":"fixed","mile1_price":350,"mile2_prices":{50:25,100:22,150:19,200:17},"mile2_price":22,"mile3_type":"fixed","mile3_price":80,"remote_cities":{"Красноярск":100,"Иркутск":150}},
    "Владивосток": {"region":"Приморский край","terminal":"г. Владивосток, ул. Промышленная, д. 25","transport_type":"fly","mile1_type":"fixed","mile1_price":280,"mile2_prices":{50:58,100:50,150:43,200:38},"mile2_price":50,"mile3_type":"fixed","mile3_price":120,"remote_cities":{}},
    "Казань": {"region":"Татарстан","terminal":"г. Казань, ул. Промышленная, д. 6","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:19,100:16,150:13,200:11},"mile2_price":16,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Краснодар": {"region":"Краснодарский край","terminal":"г. Краснодар, ул. Промышленная, д. 10","transport_type":"auto","mile1_type":"fixed","mile1_price":430,"mile2_prices":{50:16,100:13,150:11,200:9},"mile2_price":13,"mile3_type":"fixed","mile3_price":45,"remote_cities":{"Сочи":30}},
    "Ростов-на-Дону": {"region":"Ростовская область","terminal":"г. Ростов-на-Дону, ул. Промышленная, д. 8","transport_type":"auto","mile1_type":"fixed","mile1_price":420,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":50,"remote_cities":{"Сочи":40}},
    "Самара": {"region":"Самарская область","terminal":"г. Самара, ул. Промышленная, д. 4","transport_type":"auto","mile1_type":"fixed","mile1_price":390,"mile2_prices":{50:19,100:16,150:13,200:11},"mile2_price":16,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Уфа": {"region":"Башкортостан","terminal":"г. Уфа, ул. Промышленная, д. 7","transport_type":"auto","mile1_type":"fixed","mile1_price":370,"mile2_prices":{50:21,100:18,150:15,200:13},"mile2_price":18,"mile3_type":"fixed","mile3_price":60,"remote_cities":{}},
    "Воронеж": {"region":"Воронежская область","terminal":"г. Воронеж, пр. Революции, д. 15","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":45,"remote_cities":{}},
    "Ярославль": {"region":"Ярославская область","terminal":"г. Ярославль, ул. Гагарина, д. 20","transport_type":"auto","mile1_type":"fixed","mile1_price":350,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Рязань": {"region":"Рязанская область","terminal":"г. Рязань, пр. Ленина, д. 12","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":45,"remote_cities":{}},
    "Тула": {"region":"Тульская область","terminal":"г. Тула, пр. Ленина, д. 8","transport_type":"auto","mile1_type":"fixed","mile1_price":390,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":45,"remote_cities":{}},
    "Калуга": {"region":"Калужская область","terminal":"г. Калуга, ул. Кирова, д. 5","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":45,"remote_cities":{}},
    "Тверь": {"region":"Тверская область","terminal":"г. Тверь, пр. Чайковского, д. 18","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Брянск": {"region":"Брянская область","terminal":"г. Брянск, ул. Советская, д. 22","transport_type":"auto","mile1_type":"fixed","mile1_price":410,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":45,"remote_cities":{}},
    "Курск": {"region":"Курская область","terminal":"г. Курск, ул. Ленина, д. 14","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":45,"remote_cities":{}},
    "Белгород": {"region":"Белгородская область","terminal":"г. Белгород, пр. Победы, д. 35","transport_type":"auto","mile1_type":"fixed","mile1_price":420,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":45,"remote_cities":{}},
    "Липецк": {"region":"Липецкая область","terminal":"г. Липецк, ул. Зегеля, д. 10","transport_type":"auto","mile1_type":"fixed","mile1_price":390,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":45,"remote_cities":{}},
    "Орёл": {"region":"Орловская область","terminal":"г. Орёл, ул. Московская, д. 16","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":45,"remote_cities":{}},
    "Смоленск": {"region":"Смоленская область","terminal":"г. Смоленск, пр. Гагарина, д. 26","transport_type":"auto","mile1_type":"fixed","mile1_price":410,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Тамбов": {"region":"Тамбовская область","terminal":"г. Тамбов, ул. Интернациональная, д. 45","transport_type":"auto","mile1_type":"fixed","mile1_price":390,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":45,"remote_cities":{}},
    "Иваново": {"region":"Ивановская область","terminal":"г. Иваново, пр. Ленина, д. 32","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Владимир": {"region":"Владимирская область","terminal":"г. Владимир, пр. Ленина, д. 28","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Кострома": {"region":"Костромская область","terminal":"г. Кострома, ул. Советская, д. 15","transport_type":"auto","mile1_type":"fixed","mile1_price":370,"mile2_prices":{50:19,100:16,150:13,200:11},"mile2_price":16,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Нижний Новгород": {"region":"Нижегородская область","terminal":"г. Нижний Новгород, пр. Гагарина, д. 18","transport_type":"auto","mile1_type":"fixed","mile1_price":390,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Пермь": {"region":"Пермский край","terminal":"г. Пермь, ул. Ленина, д. 45","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:22,100:19,150:16,200:14},"mile2_price":19,"mile3_type":"fixed","mile3_price":65,"remote_cities":{}},
    "Оренбург": {"region":"Оренбургская область","terminal":"г. Оренбург, пр. Победы, д. 22","transport_type":"auto","mile1_type":"fixed","mile1_price":360,"mile2_prices":{50:21,100:18,150:15,200:13},"mile2_price":18,"mile3_type":"fixed","mile3_price":60,"remote_cities":{}},
    "Ижевск": {"region":"Удмуртия","terminal":"г. Ижевск, ул. Советская, д. 18","transport_type":"auto","mile1_type":"fixed","mile1_price":370,"mile2_prices":{50:20,100:17,150:14,200:12},"mile2_price":17,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Чебоксары": {"region":"Чувашия","terminal":"г. Чебоксары, пр. Ленина, д. 12","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:19,100:16,150:13,200:11},"mile2_price":16,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Киров": {"region":"Кировская область","terminal":"г. Киров, ул. Советская, д. 55","transport_type":"auto","mile1_type":"fixed","mile1_price":370,"mile2_prices":{50:20,100:17,150:14,200:12},"mile2_price":17,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Саранск": {"region":"Мордовия","terminal":"г. Саранск, пр. Стахановца, д. 18","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Йошкар-Ола": {"region":"Марий Эл","terminal":"г. Йошкар-Ола, пр. Ленина, д. 2","transport_type":"auto","mile1_type":"fixed","mile1_price":370,"mile2_prices":{50:19,100:16,150:13,200:11},"mile2_price":16,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Саратов": {"region":"Саратовская область","terminal":"г. Саратов, ул. Московская, д. 65","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Пенза": {"region":"Пензенская область","terminal":"г. Пенза, ул. Аустрина, д. 85","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Ульяновск": {"region":"Ульяновская область","terminal":"г. Ульяновск, пр. Ленина, д. 42","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Волгоград": {"region":"Волгоградская область","terminal":"г. Волгоград, пр. Ленина, д. 12","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Астрахань": {"region":"Астраханская область","terminal":"г. Астрахань, пр. Ленина, д. 15","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Ставрополь": {"region":"Ставропольский край","terminal":"г. Ставрополь, пр. Кулакова, д. 15","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:17,100:14,150:12,200:10},"mile2_price":14,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Майкоп": {"region":"Адыгея","terminal":"г. Майкоп, ул. Советская, д. 163","transport_type":"auto","mile1_type":"fixed","mile1_price":430,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Элиста": {"region":"Калмыкия","terminal":"г. Элиста, ул. им. Ленина, д. 55","transport_type":"auto","mile1_type":"fixed","mile1_price":360,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Нальчик": {"region":"Кабардино-Балкария","terminal":"г. Нальчик, пр. Шогенцукова, д. 10","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Черкесск": {"region":"Карачаево-Черкесия","terminal":"г. Черкесск, ул. Ленина, д. 115","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":50,"remote_cities":{}},
    "Сочи": {"region":"Краснодарский край","terminal":"г. Сочи, ул. Навагинская, д. 12","transport_type":"auto","mile1_type":"fixed","mile1_price":450,"mile2_prices":{50:20,100:17,150:14,200:12},"mile2_price":17,"mile3_type":"fixed","mile3_price":60,"remote_cities":{}},
    "Тольятти": {"region":"Самарская область","terminal":"г. Тольятти, пр. Ленина, д. 1","transport_type":"auto","mile1_type":"fixed","mile1_price":390,"mile2_prices":{50:19,100:16,150:13,200:11},"mile2_price":16,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Тюмень": {"region":"Тюменская область","terminal":"г. Тюмень, ул. Ленина, д. 55","transport_type":"auto","mile1_type":"fixed","mile1_price":370,"mile2_prices":{50:22,100:19,150:16,200:14},"mile2_price":19,"mile3_type":"fixed","mile3_price":65,"remote_cities":{}},
    "Челябинск": {"region":"Челябинская область","terminal":"г. Челябинск, ул. Кирова, д. 95","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:22,100:19,150:16,200:14},"mile2_price":19,"mile3_type":"fixed","mile3_price":65,"remote_cities":{}},
    "Курган": {"region":"Курганская область","terminal":"г. Курган, пр. Конституции, д. 7","transport_type":"auto","mile1_type":"fixed","mile1_price":360,"mile2_prices":{50:23,100:20,150:17,200:15},"mile2_price":20,"mile3_type":"fixed","mile3_price":70,"remote_cities":{}},
    "Омск": {"region":"Омская область","terminal":"г. Омск, пр. Маркса, д. 30","transport_type":"auto","mile1_type":"fixed","mile1_price":360,"mile2_prices":{50:24,100:21,150:18,200:16},"mile2_price":21,"mile3_type":"fixed","mile3_price":70,"remote_cities":{}},
    "Красноярск": {"region":"Красноярский край","terminal":"г. Красноярск, пр. Мира, д. 45","transport_type":"auto","mile1_type":"fixed","mile1_price":350,"mile2_prices":{50:25,100:22,150:19,200:17},"mile2_price":22,"mile3_type":"fixed","mile3_price":80,"remote_cities":{}},
    "Иркутск": {"region":"Иркутская область","terminal":"г. Иркутск, ул. Карла Маркса, д. 23","transport_type":"auto","mile1_type":"fixed","mile1_price":340,"mile2_prices":{50:26,100:23,150:20,200:18},"mile2_price":23,"mile3_type":"fixed","mile3_price":85,"remote_cities":{}},
    "Барнаул": {"region":"Алтайский край","terminal":"г. Барнаул, пр. Ленина, д. 45","transport_type":"auto","mile1_type":"fixed","mile1_price":350,"mile2_prices":{50:25,100:22,150:19,200:17},"mile2_price":22,"mile3_type":"fixed","mile3_price":75,"remote_cities":{}},
    "Томск": {"region":"Томская область","terminal":"г. Томск, пр. Ленина, д. 32","transport_type":"auto","mile1_type":"fixed","mile1_price":350,"mile2_prices":{50:25,100:22,150:19,200:17},"mile2_price":22,"mile3_type":"fixed","mile3_price":80,"remote_cities":{}},
    "Кемерово": {"region":"Кемеровская область","terminal":"г. Кемерово, пр. Ленина, д. 45","transport_type":"auto","mile1_type":"fixed","mile1_price":350,"mile2_prices":{50:24,100:21,150:18,200:16},"mile2_price":21,"mile3_type":"fixed","mile3_price":75,"remote_cities":{}},
    "Новокузнецк": {"region":"Кемеровская область","terminal":"г. Новокузнецк, пр. Мира, д. 32","transport_type":"auto","mile1_type":"fixed","mile1_price":350,"mile2_prices":{50:24,100:21,150:18,200:16},"mile2_price":21,"mile3_type":"fixed","mile3_price":75,"remote_cities":{}},
    "Улан-Удэ": {"region":"Бурятия","terminal":"г. Улан-Удэ, ул. Ленина, д. 55","transport_type":"auto","mile1_type":"fixed","mile1_price":330,"mile2_prices":{50:27,100:24,150:21,200:19},"mile2_price":24,"mile3_type":"fixed","mile3_price":90,"remote_cities":{}},
    "Абакан": {"region":"Хакасия","terminal":"г. Абакан, пр. Ленина, д. 12","transport_type":"auto","mile1_type":"fixed","mile1_price":340,"mile2_prices":{50:26,100:23,150:20,200:18},"mile2_price":23,"mile3_type":"fixed","mile3_price":85,"remote_cities":{}},
    "Горно-Алтайск": {"region":"Алтай","terminal":"г. Горно-Алтайск, пр. Ленина, д. 1","transport_type":"auto","mile1_type":"fixed","mile1_price":340,"mile2_prices":{50:26,100:23,150:20,200:18},"mile2_price":23,"mile3_type":"fixed","mile3_price":85,"remote_cities":{}},
    "Хабаровск": {"region":"Хабаровский край","terminal":"г. Хабаровск, ул. Муравьева-Амурского, д. 30","transport_type":"fly","mile1_type":"fixed","mile1_price":300,"mile2_prices":{50:55,100:48,150:41,200:36},"mile2_price":48,"mile3_type":"fixed","mile3_price":110,"remote_cities":{}},
    "Магадан": {"region":"Магаданская область","terminal":"г. Магадан, ул. Портовая, д. 1","transport_type":"fly","mile1_type":"fixed","mile1_price":280,"mile2_prices":{50:60,100:52,150:45,200:40},"mile2_price":52,"mile3_type":"fixed","mile3_price":130,"remote_cities":{}},
    "Сургут": {"region":"Ханты-Мансийский АО","terminal":"г. Сургут, пр. Ленина, д. 50","transport_type":"auto","mile1_type":"fixed","mile1_price":340,"mile2_prices":{50:24,100:21,150:18,200:16},"mile2_price":21,"mile3_type":"fixed","mile3_price":75,"remote_cities":{}},
    "Нижневартовск": {"region":"Ханты-Мансийский АО","terminal":"г. Нижневартовск, ул. Мира, д. 25","transport_type":"auto","mile1_type":"fixed","mile1_price":340,"mile2_prices":{50:24,100:21,150:18,200:16},"mile2_price":21,"mile3_type":"fixed","mile3_price":75,"remote_cities":{}},
    "Петропавловск-Камчатский": {"region":"Камчатский край","terminal":"г. Петропавловск-Камчатский, ул. Ленина, д. 5","transport_type":"fly","mile1_type":"fixed","mile1_price":270,"mile2_prices":{50:62,100:54,150:47,200:42},"mile2_price":54,"mile3_type":"fixed","mile3_price":140,"remote_cities":{}},
    "Якутск": {"region":"Якутия","terminal":"г. Якутск, пр. Ленина, д. 48","transport_type":"fly","mile1_type":"fixed","mile1_price":290,"mile2_prices":{50:58,100:50,150:43,200:38},"mile2_price":50,"mile3_type":"fixed","mile3_price":120,"remote_cities":{}},
    "Южно-Сахалинск": {"region":"Сахалинская область","terminal":"г. Южно-Сахалинск, пр. Ленина, д. 95","transport_type":"fly","mile1_type":"fixed","mile1_price":300,"mile2_prices":{50:56,100:48,150:42,200:37},"mile2_price":48,"mile3_type":"fixed","mile3_price":115,"remote_cities":{}},
    "Благовещенск": {"region":"Амурская область","terminal":"г. Благовещенск, ул. Ленина, д. 55","transport_type":"auto","mile1_type":"fixed","mile1_price":330,"mile2_prices":{50:27,100:24,150:21,200:19},"mile2_price":24,"mile3_type":"fixed","mile3_price":90,"remote_cities":{}},
    "Анадырь": {"region":"Чукотский АО","terminal":"г. Анадырь, ул. Чаплина, д. 2","transport_type":"fly","mile1_type":"fixed","mile1_price":260,"mile2_prices":{50:65,100:56,150:49,200:44},"mile2_price":56,"mile3_type":"fixed","mile3_price":150,"remote_cities":{}},
    "Махачкала": {"region":"Дагестан","terminal":"г. Махачкала, пр. Имама Шамиля, д. 15","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:18,100:15,150:13,200:11},"mile2_price":15,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Калининград": {"region":"Калининградская область","terminal":"г. Калининград, пр. Мира, д. 10","transport_type":"auto","mile1_type":"fixed","mile1_price":440,"mile2_prices":{50:22,100:19,150:16,200:14},"mile2_price":19,"mile3_type":"fixed","mile3_price":70,"remote_cities":{}},
    "Мурманск": {"region":"Мурманская область","terminal":"г. Мурманск, пр. Ленина, д. 45","transport_type":"auto","mile1_type":"fixed","mile1_price":420,"mile2_prices":{50:24,100:21,150:18,200:16},"mile2_price":21,"mile3_type":"fixed","mile3_price":75,"remote_cities":{}},
    "Архангельск": {"region":"Архангельская область","terminal":"г. Архангельск, наб. Северной Двины, д. 67","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:22,100:19,150:16,200:14},"mile2_price":19,"mile3_type":"fixed","mile3_price":65,"remote_cities":{}},
    "Петрозаводск": {"region":"Карелия","terminal":"г. Петрозаводск, пр. Ленина, д. 26","transport_type":"auto","mile1_type":"fixed","mile1_price":410,"mile2_prices":{50:21,100:18,150:15,200:13},"mile2_price":18,"mile3_type":"fixed","mile3_price":60,"remote_cities":{}},
    "Сыктывкар": {"region":"Коми","terminal":"г. Сыктывкар, пр. Ленина, д. 54","transport_type":"auto","mile1_type":"fixed","mile1_price":380,"mile2_prices":{50:23,100:20,150:17,200:15},"mile2_price":20,"mile3_type":"fixed","mile3_price":70,"remote_cities":{}},
    "Псков": {"region":"Псковская область","terminal":"г. Псков, ул. Ленина, д. 12","transport_type":"auto","mile1_type":"fixed","mile1_price":410,"mile2_prices":{50:20,100:17,150:14,200:12},"mile2_price":17,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Вологда": {"region":"Вологодская область","terminal":"г. Вологда, ул. Ленина, д. 46","transport_type":"auto","mile1_type":"fixed","mile1_price":390,"mile2_prices":{50:20,100:17,150:14,200:12},"mile2_price":17,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Череповец": {"region":"Вологодская область","terminal":"г. Череповец, пр. Металлургов, д. 25","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:20,100:17,150:14,200:12},"mile2_price":17,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Новгород": {"region":"Новгородская область","terminal":"г. Новгород, ул. Большая Санкт-Петербургская, д. 25","transport_type":"auto","mile1_type":"fixed","mile1_price":400,"mile2_prices":{50:20,100:17,150:14,200:12},"mile2_price":17,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Симферополь": {"region":"Крым","terminal":"г. Симферополь, пр. Кирова, д. 18","transport_type":"auto","mile1_type":"fixed","mile1_price":440,"mile2_prices":{50:19,100:16,150:14,200:12},"mile2_price":16,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}},
    "Севастополь": {"region":"Севастополь","terminal":"г. Севастополь, ул. Большая Морская, д. 25","transport_type":"auto","mile1_type":"fixed","mile1_price":450,"mile2_prices":{50:19,100:16,150:14,200:12},"mile2_price":16,"mile3_type":"fixed","mile3_price":55,"remote_cities":{}}
};

// Расчет расстояния (Haversine)
function tmsCalculateDistance(fromCity, toCity) {
    const fromCoords = TMS_CITY_COORDS[fromCity];
    const toCoords = TMS_CITY_COORDS[toCity];
    if (!fromCoords || !toCoords) return null;
    const R = 6371;
    const lat1 = fromCoords[0] * Math.PI / 180;
    const lat2 = toCoords[0] * Math.PI / 180;
    const deltaLat = (toCoords[0] - fromCoords[0]) * Math.PI / 180;
    const deltaLon = (toCoords[1] - fromCoords[1]) * Math.PI / 180;
    const a = Math.sin(deltaLat/2) * Math.sin(deltaLat/2) + Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLon/2) * Math.sin(deltaLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return Math.round(R * c);
}

// Загрузка городов с приоритетом localStorage
function loadTMSCities() {
    console.log('Loading cities...');
    const saved = localStorage.getItem('tms_freight_cities');
    if (saved) {
        tmsCities = JSON.parse(saved);
        console.log('Загружено из localStorage:', Object.keys(tmsCities).length, 'городов');
    } else {
        tmsCities = JSON.parse(JSON.stringify(TMS_DEFAULT_CITIES));
        console.log('Загружены города по умолчанию:', Object.keys(tmsCities).length, 'городов');
    }
}

// Сохранение городов
function saveTMSCities() {
    localStorage.setItem('tms_freight_cities', JSON.stringify(tmsCities));
    localStorage.setItem('tms_city_coords', JSON.stringify(TMS_CITY_COORDS));
}

// Инициализация
function initTMSCalculator() {
    console.log('Initializing TMS Calculator...');
    loadTMSCities();
    populateTMSCitySelects();
    populateTMSRegionFilter();
    renderTMSTariffsTable();
    updateTMSStats();
    console.log('Initialization complete. Total cities:', Object.keys(tmsCities).length);
}

// Заполнение выпадающих списков
function populateTMSCitySelects() {
    const fromInput = document.getElementById('fromCity');
    const toInput = document.getElementById('toCity');
    const dataList = document.getElementById('cityList');
    
    if (!fromInput || !toInput || !dataList) {
        console.error('Не найдены элементы формы!');
        return;
    }
    
    dataList.innerHTML = '';
    const cities = Object.keys(tmsCities).sort();
    cities.forEach(city => {
        const option = document.createElement('option');
        option.value = city;
        dataList.appendChild(option);
    });
    
    console.log('Заполнено', cities.length, 'городов в datalist');
    
    // Обработчики событий для удаленных городов
    toInput.addEventListener('change', () => {
        console.log('toInput change event:', toInput.value);
        setTimeout(() => {
            populateRemoteCities();
        }, 50);
    });
    
    toInput.addEventListener('input', () => {
        console.log('toInput input event:', toInput.value);
        const toCity = toInput.value.trim();
        if (toCity && tmsCities[toCity]) {
            setTimeout(() => {
                populateRemoteCities();
            }, 100);
        }
    });
    
    fromInput.addEventListener('input', () => {
        const fromCity = fromInput.value.trim();
        if (fromCity && tmsCities[fromCity]) {
            document.getElementById('cityInfo').innerHTML = `
                <div class="from-city-info">
                    <h4>📍 Город отправки: ${fromCity}</h4>
                    <p><b>Регион:</b> ${tmsCities[fromCity].region || '-'}</p>
                    <p><b>Терминал:</b> ${tmsCities[fromCity].terminal || '-'}</p>
                    <p><b>Тип:</b> ${tmsCities[fromCity].transport_type === 'auto' ? '🚛 Авто' : '✈️ Авиа'}</p>
                </div>
            `;
        }
    });
}

// Заполнение фильтра регионов
function populateTMSRegionFilter() {
    const regions = new Set();
    Object.values(tmsCities).forEach(data => { if (data.region) regions.add(data.region); });
    const filter = document.getElementById('regionFilter');
    filter.innerHTML = '<option value="all">Все регионы</option>' + Array.from(regions).sort().map(r => `<option value="${r}">${r}</option>`).join('');
}

// Обновление информации о городе
function updateTMSCityInfo() {
    const toCity = document.getElementById('toCity').value.trim();
    const data = toCity ? tmsCities[toCity] : null;
    if (data) {
        const transport = data.transport_type === 'auto' ? '🚛 Авто' : '✈️ Авиа';
        document.getElementById('cityInfo').innerHTML = `<strong>Тип перевозки:</strong> ${transport} | <strong>Терминал:</strong> ${data.terminal}`;
        const remoteSection = document.getElementById('remoteSection');
        const remoteCities = document.getElementById('remoteCities');
        if (data.remote_cities && Object.keys(data.remote_cities).length > 0) {
            remoteSection.style.display = 'block';
            let html = `<div class="calc-remote-item"><input type="radio" name="remote" value="" id="remote_none" checked><label for="remote_none">Нет</label></div>`;
            html += Object.entries(data.remote_cities).map(([city, price]) => `<div class="calc-remote-item"><input type="radio" name="remote" value="${city}" id="remote_${city}"><label for="remote_${city}">${city} (+${price} руб)</label></div>`).join('');
            remoteCities.innerHTML = html;
        } else {
            remoteSection.style.display = 'none';
        }
    }
}

// Авто расчёт расстояния
function calculateDistanceAuto() {
    const fromCity = document.getElementById('fromCity').value;
    const toCity = document.getElementById('toCity').value;
    const distance = tmsCalculateDistance(fromCity, toCity);
    if (distance) {
        document.getElementById('distance').value = distance;
        alert(`Расстояние ${fromCity} - ${toCity}: ${distance} км`);
    } else {
        alert('Не удалось рассчитать расстояние. Координаты городов не найдены.');
    }
}

// Расчет стоимости
function calculate() {
    console.log('=== calculate() вызвана ===');
    
    const fromCity = document.getElementById('fromCity').value.trim();
    const toCity = document.getElementById('toCity').value.trim();
    const distance = parseFloat(document.getElementById('distance').value) || 0;
    const weight = parseFloat(document.getElementById('weight').value) || 0;
    const volume = parseFloat(document.getElementById('volume').value) || 0;
    
    console.log('Входные данные:', { fromCity, toCity, distance, weight, volume });
    
    if (!fromCity || !tmsCities[fromCity]) { 
        alert('Выберите город "Откуда" из списка!'); 
        return;
    }
    if (!toCity || !tmsCities[toCity]) {
        alert('Выберите город "Куда" из списка!'); 
        return;
    }
    if (weight <= 0 && volume <= 0) { 
        alert('Введите вес или объем груза!'); 
        return;
    }
    
    const volumetricWeight = volume * 250;
    const billableWeight = volumetricWeight > weight ? volumetricWeight : weight;
    const weightUsed = volumetricWeight > weight ? 'объемный' : 'фактический';
    const fromData = tmsCities[fromCity];
    const toData = tmsCities[toCity];
    
    console.log('Данные городов:', { fromData, toData });
    
    // Расчет 1-й мили
    let price1 = fromData.mile1_type === 'fixed' ? fromData.mile1_price : fromData.mile1_price * billableWeight;
    
    // Расчет 2-й мили (магистраль)
    let price2 = 0;
    if (toData.transport_type === 'auto') {
        if (billableWeight <= 50) price2 = billableWeight * toData.mile2_prices[50];
        else if (billableWeight <= 100) price2 = billableWeight * toData.mile2_prices[100];
        else if (billableWeight <= 150) price2 = billableWeight * toData.mile2_prices[150];
        else price2 = billableWeight * toData.mile2_prices[200];
    } else {
        price2 = distance * 3.5;
    }
    
    // Расчет 3-й мили (доставка)
    let price3 = toData.mile3_type === 'fixed' ? toData.mile3_price : toData.mile3_price * billableWeight;
    
    // Расчет доплаты за удаленный город
    let remoteExtra = 0;
    const useRemoteCheckbox = document.getElementById('useRemoteCity');
    const remoteSelect = document.getElementById('remoteCitySelect');
    
    console.log('Checkbox:', useRemoteCheckbox, 'checked:', useRemoteCheckbox?.checked);
    console.log('Select:', remoteSelect, 'value:', remoteSelect?.value);
    
    if (useRemoteCheckbox && remoteSelect) {
        if (!useRemoteCheckbox.checked && remoteSelect.value) {
            remoteExtra = toData.remote_cities[remoteSelect.value] || 0;
            console.log('Добавлена доплата за удаленный город:', remoteExtra);
        } else {
            console.log('Удаленный город не учитывается (checkbox или пустой select)');
        }
    }
    
    const total = price1 + price2 + price3 + remoteExtra;
    
    console.log('Итого:', { price1, price2, price3, remoteExtra, total });
    
    const resultHTML = `<div class="calc-result-html">
<div class="calc-result-header">
    <h3>💰 Итоговая стоимость</h3>
    <div class="calc-total-price">${formatCurrency(total)}</div>
</div>
<div class="result-details">
    <div class="detail-row">
        <div class="detail-label">Фактический вес:</div>
        <div class="detail-value">${weight.toFixed(1)} кг</div>
    </div>
    <div class="detail-row">
        <div class="detail-label">Объемный вес:</div>
        <div class="detail-value">${volumetricWeight.toFixed(1)} кг (${volume} м³ × 250)</div>
    </div>
    <div class="detail-row">
        <div class="detail-label">Расчетный вес:</div>
        <div class="detail-value">${billableWeight.toFixed(1)} кг (${weightUsed})</div>
    </div>
</div>
<div class="price-breakdown">
    <h5>📊 Детализация стоимости:</h5>
    <div class="breakdown-item">
        <div class="breakdown-label">1️⃣ Миля 1 (сбор)<small>от ${fromCity}</small></div>
        <div class="breakdown-value">${formatCurrency(price1)}</div>
    </div>
    <div class="breakdown-item">
        <div class="breakdown-label">2️⃣ Миля 2 (магистраль)<small>${toData.transport_type === 'auto' ? 'Авто' : 'Авиа'}</small></div>
        <div class="breakdown-value">${formatCurrency(price2)}</div>
    </div>
    <div class="breakdown-item">
        <div class="breakdown-label">3️⃣ Миля 3 (доставка)<small>до ${toCity}</small></div>
        <div class="breakdown-value">${formatCurrency(price3)}</div>
    </div>
    ${remoteExtra > 0 ? `
    <div class="breakdown-item">
        <div class="breakdown-label">🏙️ Удаленный город<small>${remoteSelect.value}: ${formatCurrency(remoteExtra)}</small></div>
        <div class="breakdown-value">${formatCurrency(remoteExtra)}</div>
    </div>` : ''}
    <div class="breakdown-item total">
        <div class="breakdown-label">Итого:</div>
        <div class="breakdown-value">${formatCurrency(total)}</div>
    </div>
</div>
<div class="disclaimer">
    ⚠️ Данная стоимость является ориентировочной и может измениться после уточнения деталей груза.
</div>
</div>`;
    
    const resultDiv = document.getElementById('result');
    console.log('resultDiv:', resultDiv);
    
    if (resultDiv) {
        resultDiv.innerHTML = resultHTML;
        console.log('Результат отображен');
    } else {
        console.error('resultDiv не найден!');
    }
}

// Таблица тарифов
function renderTMSTariffsTable(searchText = '') {
    const tbody = document.querySelector('#tariffsTable tbody');
    let filteredCities = Object.entries(tmsCities);
    if (searchText) {
        const lower = searchText.toLowerCase();
        filteredCities = filteredCities.filter(([city, data]) => city.toLowerCase().includes(lower) || (data.region && data.region.toLowerCase().includes(lower)));
    }
    tbody.innerHTML = filteredCities.map(([city, data], index) => {
        const mile2Prices = data.mile2_prices || {50: 18, 100: 15, 150: 12, 200: 10};
        return `<tr onclick="selectTMSCityRow('${city}')" ondblclick="openEditTMSCity('${city}')"><td>${index + 1}</td><td>${city}</td><td>${data.region || '-'}</td><td class="${data.transport_type === 'auto' ? 'calc-auto-type' : 'calc-fly-type'}">${data.transport_type === 'auto' ? 'Авто' : 'Авиа'}</td><td>${data.mile1_type === 'fixed' ? 'фикс' : 'кг'}: ${data.mile1_price}</td><td>50:${mile2Prices[50]} 100:${mile2Prices[100]} 150:${mile2Prices[150]} 200+:${mile2Prices[200]}</td><td>${data.mile3_type === 'fixed' ? 'фикс' : 'кг'}: ${data.mile3_price}</td><td>${(data.terminal || '').substring(0, 25)}...</td></tr>`;
    }).join('');
    updateTMSStats();
}

function filterTMSTariffs() { const searchText = document.getElementById('searchInput').value; renderTMSTariffsTable(searchText); }
function selectTMSCityRow(city) { selectedCity = city; }

// Открыть модальное окно редактирования
function openEditTMSCity(city) {
    selectedCity = city;
    const data = tmsCities[city];
    if (!data) return;
    
    document.getElementById('edit-city-name').value = city;
    document.getElementById('edit-city-display').value = city;
    document.getElementById('edit-region').value = data.region || '';
    document.getElementById('edit-terminal').value = data.terminal || '';
    document.getElementById('edit-transport-type').value = data.transport_type || 'auto';
    document.getElementById('edit-mile1-type').value = data.mile1_type || 'fixed';
    document.getElementById('edit-mile1-price').value = data.mile1_price || 0;
    
    const mile2Prices = data.mile2_prices || {50: 18, 100: 15, 150: 12, 200: 10};
    document.getElementById('edit-mile2-50').value = mile2Prices[50] || 18;
    document.getElementById('edit-mile2-100').value = mile2Prices[100] || 15;
    document.getElementById('edit-mile2-150').value = mile2Prices[150] || 12;
    document.getElementById('edit-mile2-200').value = mile2Prices[200] || 10;
    
    document.getElementById('edit-mile3-type').value = data.mile3_type || 'fixed';
    document.getElementById('edit-mile3-price').value = data.mile3_price || 0;
    
    document.getElementById('city-edit-modal').classList.add('active');
    loadRemoteCitiesList();
    
    // Добавляем обработчик Enter для полей удаленных городов
    setTimeout(() => {
        const nameInput = document.getElementById('new-remote-city-name');
        const priceInput = document.getElementById('new-remote-city-price');
        
        if (nameInput && priceInput) {
            priceInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    addRemoteCity();
                }
            });
            
            nameInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    priceInput.focus();
                }
            });
        }
    }, 100);
}

// Закрыть модальное окно
function closeCityEditModal() {
    document.getElementById('city-edit-modal').classList.remove('active');
}

// Сохранить изменения города
function saveCityEdit() {
    const cityName = document.getElementById('edit-city-name').value;
    if (!cityName || !tmsCities[cityName]) {
        alert('Ошибка: город не найден!');
        return;
    }
    
    const newData = {
        region: document.getElementById('edit-region').value,
        terminal: document.getElementById('edit-terminal').value,
        transport_type: document.getElementById('edit-transport-type').value,
        mile1_type: document.getElementById('edit-mile1-type').value,
        mile1_price: parseFloat(document.getElementById('edit-mile1-price').value) || 0,
        mile2_prices: {
            50: parseFloat(document.getElementById('edit-mile2-50').value) || 18,
            100: parseFloat(document.getElementById('edit-mile2-100').value) || 15,
            150: parseFloat(document.getElementById('edit-mile2-150').value) || 12,
            200: parseFloat(document.getElementById('edit-mile2-200').value) || 10
        },
        mile2_price: parseFloat(document.getElementById('edit-mile2-100').value) || 15,
        mile3_type: document.getElementById('edit-mile3-type').value,
        mile3_price: parseFloat(document.getElementById('edit-mile3-price').value) || 0,
        remote_cities: tmsCities[cityName].remote_cities || {}
    };
    
    tmsCities[cityName] = newData;
    saveTMSCities();
    renderTMSTariffsTable();
    updateTMSStats();
    closeCityEditModal();
    alert('✅ Город успешно обновлен!');
}

// Удалить текущий город из модального окна
function deleteCurrentCity() {
    const cityName = document.getElementById('edit-city-name').value;
    if (!cityName) return;
    
    if (confirm(`⚠️ Вы уверены, что хотите удалить город "${cityName}"?\n\nЭто действие нельзя отменить!`)) {
        delete tmsCities[cityName];
        saveTMSCities();
        populateTMSCitySelects();
        populateTMSRegionFilter();
        renderTMSTariffsTable();
        updateTMSStats();
        closeCityEditModal();
        selectedCity = null;
        alert('✅ Город удален!');
    }
}

// Переключение типа цены для мили
function toggleMileType(mile) {
    const type = document.getElementById(`edit-${mile}-type`).value;
    const priceInput = document.getElementById(`edit-${mile}-price`);
    if (type === 'fixed') {
        priceInput.placeholder = 'Фиксированная цена';
    } else {
        priceInput.placeholder = 'Цена за кг';
    }
}

// Загрузить список удаленных городов
function loadRemoteCitiesList() {
    const cityName = document.getElementById('edit-city-name').value;
    const listContainer = document.getElementById('remote-cities-list');
    if (!cityName || !tmsCities[cityName]) return;
    
    const remoteCities = tmsCities[cityName].remote_cities || {};
    const remoteCount = Object.keys(remoteCities).length;
    
    listContainer.innerHTML = '';
    
    // Показываем счетчик
    const counterDiv = document.createElement('div');
    counterDiv.style.cssText = 'margin-bottom: 10px; font-weight: 600; color: var(--primary-color);';
    counterDiv.textContent = `📊 Всего удаленных городов: ${remoteCount}`;
    listContainer.appendChild(counterDiv);
    
    if (remoteCount === 0) {
        const emptyMsg = document.createElement('p');
        emptyMsg.style.cssText = 'text-align: center; color: var(--text-secondary); padding: 20px;';
        emptyMsg.textContent = 'Нет удаленных городов. Добавьте первый город выше.';
        listContainer.appendChild(emptyMsg);
        return;
    }
    
    // Контейнер для списка
    const citiesContainer = document.createElement('div');
    citiesContainer.className = 'remote-cities-scroll-list';
    
    Object.entries(remoteCities).forEach(([city, price]) => {
        const item = document.createElement('div');
        item.className = 'remote-city-item';
        item.innerHTML = `
            <div class="remote-city-info">
                <span class="remote-city-name">${city}</span>
                <span class="remote-city-price">${formatCurrency(price)}</span>
            </div>
            <button class="remote-city-delete" onclick="removeRemoteCity('${city}')">&times;</button>
        `;
        citiesContainer.appendChild(item);
    });
    
    listContainer.appendChild(citiesContainer);
}

// Добавить удаленный город
function addRemoteCity() {
    const cityName = document.getElementById('edit-city-name').value;
    const remoteNameInput = document.getElementById('new-remote-city-name');
    const remotePriceInput = document.getElementById('new-remote-city-price');
    
    const remoteName = remoteNameInput.value.trim();
    const remotePrice = parseFloat(remotePriceInput.value);
    
    console.log('addRemoteCity called:', { cityName, remoteName, remotePrice });
    
    if (!cityName || !tmsCities[cityName]) {
        alert('Ошибка: город не найден!');
        return;
    }
    
    if (!remoteName) {
        alert('Введите название удаленного города!');
        return;
    }
    
    if (isNaN(remotePrice) || remotePrice <= 0) {
        alert('Введите корректный тариф!');
        return;
    }
    
    if (!tmsCities[cityName].remote_cities) {
        tmsCities[cityName].remote_cities = {};
        console.log('Создан объект remote_cities для', cityName);
    }
    
    console.log('Текущие remote_cities:', tmsCities[cityName].remote_cities);
    
    // Проверка на дубликат
    if (tmsCities[cityName].remote_cities[remoteName]) {
        if (confirm(`Город "${remoteName}" уже существует. Заменить тариф?`)) {
            tmsCities[cityName].remote_cities[remoteName] = remotePrice;
        } else {
            return;
        }
    } else {
        tmsCities[cityName].remote_cities[remoteName] = remotePrice;
    }
    
    console.log('После добавления:', tmsCities[cityName].remote_cities);
    
    saveTMSCities();
    loadRemoteCitiesList();
    
    remoteNameInput.value = '';
    remotePriceInput.value = '';
    remoteNameInput.focus();
    
    alert(`✅ Город "${remoteName}" добавлен! Всего удаленных городов: ${Object.keys(tmsCities[cityName].remote_cities).length}`);
}

// Удалить удаленный город
function removeRemoteCity(remoteCityName) {
    const cityName = document.getElementById('edit-city-name').value;
    if (!cityName || !tmsCities[cityName]) return;
    
    if (confirm(`Удалить город "${remoteCityName}" из списка удаленных?`)) {
        if (tmsCities[cityName].remote_cities && tmsCities[cityName].remote_cities[remoteCityName]) {
            delete tmsCities[cityName].remote_cities[remoteCityName];
            saveTMSCities();
            loadRemoteCitiesList();
        }
    }
}

// Переключить выбор удаленного города
function toggleRemoteCitySelect() {
    const checkbox = document.getElementById('useRemoteCity');
    const select = document.getElementById('remoteCitySelect');
    select.style.display = checkbox.checked ? 'none' : 'block';
}

// Заполнить список удаленных городов для выбранного города назначения
function populateRemoteCities() {
    const toCity = document.getElementById('toCity').value.trim();
    const remoteSection = document.getElementById('remoteSection');
    const select = document.getElementById('remoteCitySelect');
    const checkbox = document.getElementById('useRemoteCity');
    
    console.log('=== populateRemoteCities ===');
    console.log('Город:', toCity);
    console.log('tmsCities[toCity]:', tmsCities[toCity]);
    
    if (!remoteSection || !select) {
        console.error('Элементы не найдены! remoteSection:', remoteSection, 'select:', select);
        return;
    }
    
    // Сброс select
    select.innerHTML = '<option value="">-- Выберите удаленный город --</option>';
    
    if (!toCity || !tmsCities[toCity]) {
        console.log('Город не выбран или не найден');
        remoteSection.style.display = 'none';
        document.getElementById('cityInfo').innerHTML = 'Выберите город назначения для просмотра информации';
        return;
    }
    
    const toData = tmsCities[toCity];
    const remoteCities = toData.remote_cities || {};
    
    console.log('Удаленные города:', remoteCities);
    console.log('Количество:', Object.keys(remoteCities).length);
    
    // Обновляем cityInfo
    document.getElementById('cityInfo').innerHTML = `
        <div class="to-city-info">
            <h4>📍 Город доставки: ${toCity}</h4>
            <p><b>Регион:</b> ${toData.region || '-'}</p>
            <p><b>Терминал:</b> ${toData.terminal || '-'}</p>
            <p><b>Тип:</b> ${toData.transport_type === 'auto' ? '🚛 Авто' : '✈️ Авиа'}</p>
            <p><b>Удаленных городов:</b> ${Object.keys(remoteCities).length}</p>
        </div>
    `;
    
    if (Object.keys(remoteCities).length === 0) {
        console.log('Нет удаленных городов для этого города');
        remoteSection.style.display = 'none';
        return;
    }
    
    // Показываем секцию
    remoteSection.style.display = 'block';
    console.log('Секция показана');
    
    // Сброс чекбокса
    if (checkbox) checkbox.checked = false;
    
    // Добавляем опции
    Object.entries(remoteCities).forEach(([city, price]) => {
        const option = document.createElement('option');
        option.value = city;
        option.textContent = `${city} (+${formatCurrency(price)})`;
        select.appendChild(option);
        console.log('Добавлен option:', city, price);
    });
    
    console.log('Всего options:', select.options.length);
    
    // Фокус на select если есть опции
    if (select.options.length > 1) {
        select.style.display = 'block';
    }
}
function updateTMSStats() { document.getElementById('totalCities').textContent = Object.keys(tmsCities).length; document.getElementById('autoCount').textContent = Object.values(tmsCities).filter(c => c.transport_type === 'auto').length; document.getElementById('flyCount').textContent = Object.values(tmsCities).filter(c => c.transport_type === 'fly').length; }
function saveTMSTariffs() { saveTMSCities(); alert('✅ Тарифы сохранены! Всего городов: ' + Object.keys(tmsCities).length); }
function openAddTMSModal() { alert('Функция добавления города в разработке'); }
function openTMSEditModal() { if (!selectedCity) { alert('Выберите город в таблице!'); return; } alert('Функция редактирования в разработке'); }
function deleteTMSCity() { if (!selectedCity) { alert('Выберите город в таблице!'); return; } if (confirm(`Удалить город ${selectedCity}?`)) { delete tmsCities[selectedCity]; selectedCity = null; saveTMSCities(); populateTMSCitySelects(); populateTMSRegionFilter(); renderTMSTariffsTable(); updateTMSStats(); } }
function resetTMSToDefaults() { if (confirm('🔄 Сбросить все данные к заводским настройкам?\n\nЭто восстановит все 100+ городов с тарифами по умолчанию.\n\nВсе ваши изменения будут утеряны!')) { loadTMSCities(); populateTMSCitySelects(); populateTMSRegionFilter(); renderTMSTariffsTable(); updateTMSStats(); alert('✅ Данные восстановлены!\n\nВсего городов: ' + Object.keys(tmsCities).length + '\nАвто: ' + Object.values(tmsCities).filter(c => c.transport_type === 'auto').length + '\nАвиа: ' + Object.values(tmsCities).filter(c => c.transport_type === 'fly').length); } }

// Карта
function generateTMSMap() {
    const regionFilter = document.getElementById('regionFilter').value;
    if (tmsMap) tmsMap.remove();
    tmsMap = L.map('mapContainer').setView([55.75, 37.62], 4);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '© OpenStreetMap' }).addTo(tmsMap);
    Object.entries(tmsCities).forEach(([city, data]) => {
        if (regionFilter !== 'all' && data.region !== regionFilter) return;
        const coords = TMS_CITY_COORDS[city];
        if (!coords) return;
        const color = data.transport_type === 'auto' ? '#3498db' : '#e74c3c';
        L.circleMarker(coords, { radius: 8, color: '#ffffff', weight: 3, fillColor: color, fillOpacity: 0.9 }).bindPopup(`<b>${city}</b><br><b>Регион:</b> ${data.region || '-'}<br><b>Тип:</b> ${data.transport_type === 'auto' ? '🚛 Авто' : '✈️ Авиа'}`).addTo(tmsMap);
    });
    document.getElementById('mapContainer').style.display = 'block';
}

function updateTMSMap() { generateTMSMap(); }
function toggleTMSFullscreen() {
    const mapContainer = document.getElementById('mapContainer');
    isFullscreen = !isFullscreen;
    if (isFullscreen) {
        mapContainer.style.height = '100vh';
        mapContainer.style.borderRadius = '0';
        const exitBtn = document.createElement('button');
        exitBtn.id = 'exitFullscreen';
        exitBtn.style.cssText = 'position:absolute;top:10px;right:10px;z-index:1000;padding:8px 15px;background:#e74c3c;color:white;border:none;border-radius:5px;cursor:pointer;';
        exitBtn.textContent = '✕ Выйти';
        exitBtn.onclick = toggleTMSFullscreen;
        mapContainer.appendChild(exitBtn);
    } else {
        mapContainer.style.height = '500px';
        mapContainer.style.borderRadius = '12px';
        const exitBtn = document.getElementById('exitFullscreen');
        if (exitBtn) exitBtn.remove();
    }
    setTimeout(() => { if (tmsMap) tmsMap.invalidateSize(); }, 100);
}

// Экспорт глобально
window.initTMSCalculator = initTMSCalculator;
window.calculateDistanceAuto = calculateDistanceAuto;
window.calculate = calculate;
window.filterTariffs = filterTMSTariffs;
window.openAddModal = openAddTMSModal;
window.openEditModal = openTMSEditModal;
window.deleteCity = deleteTMSCity;
window.saveTariffs = saveTMSTariffs;
window.resetToDefaults = resetTMSToDefaults;
window.generateMap = generateTMSMap;
window.updateMap = updateTMSMap;
window.toggleFullscreen = toggleTMSFullscreen;
window.populateRemoteCities = populateRemoteCities;
window.toggleRemoteCitySelect = toggleRemoteCitySelect;
window.loadRemoteCitiesList = loadRemoteCitiesList;
window.addRemoteCity = addRemoteCity;
window.removeRemoteCity = removeRemoteCity;
window.openEditTMSCity = openEditTMSCity;
window.closeCityEditModal = closeCityEditModal;
window.saveCityEdit = saveCityEdit;
window.deleteCurrentCity = deleteCurrentCity;
window.toggleMileType = toggleMileType;
window.selectTMSCityRow = selectTMSCityRow;
window.filterTMSTariffs = filterTMSTariffs;

console.log('✅ All calculator functions exported');

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM loaded, initializing calculator...');
    const calcView = document.getElementById('calculator');
    if (calcView) {
        console.log('Calculator view found, calling initTMSCalculator...');
        if (typeof initTMSCalculator === 'function') {
            initTMSCalculator();
        } else {
            console.error('initTMSCalculator не найдена!');
        }
    } else {
        console.log('Calculator view not found on this page');
    }
});