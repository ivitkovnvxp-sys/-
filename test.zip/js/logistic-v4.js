// Модуль логиста v4 - Логика как в 1С (по точкам) + подрядчики
class LogisticModule {
    constructor() {
        this.orders = [];
        this.vehicles = [];
        this.drivers = [];
        this.contractors = []; // Подрядчики
        this.map = null;
        this.markers = [];
        this.routeLayer = null;
        this.routePoints = []; // Точки текущего маршрута
        this.savedRoutes = []; // Сохранённые маршруты
        this.currentWeekStart = this.getWeekStart(new Date());
        
        this.init();
    }

    init() {
        this.loadData();
        this.loadDrivers();
        this.loadContractors();
        this.loadSavedRoutes();
        this.setupEventListeners();
        
        // Инициализация карты при показе вкладки
        setTimeout(() => {
            this.initMapOnShow();
        }, 100);
    }

    loadDrivers() {
        const drivers = JSON.parse(localStorage.getItem('tms_drivers') || '[]');
        if (drivers.length > 0) {
            this.drivers = drivers;
        } else {
            // Тестовые водители
            this.drivers = [
                { id: 1, name: 'Петров С.И.', phone: '+7 (916) 123-45-67' },
                { id: 2, name: 'Сидоров А.А.', phone: '+7 (916) 234-56-78' },
                { id: 3, name: 'Козлов Д.В.', phone: '+7 (916) 345-67-89' }
            ];
            this.saveDrivers();
        }
    }

    saveDrivers() {
        localStorage.setItem('tms_drivers', JSON.stringify(this.drivers));
    }

    showDriverModal() {
        document.getElementById('driver-modal')?.classList.add('active');
    }

    showVehicleModal() {
        document.getElementById('vehicle-modal')?.classList.add('active');
    }

    addDriver() {
        const nameInput = document.getElementById('driver-name');
        const phoneInput = document.getElementById('driver-phone');
        
        if (!nameInput?.value) {
            this.showNotification('Введите ФИО водителя', 'error');
            return;
        }
        
        const driver = {
            id: Date.now(),
            name: nameInput.value,
            phone: phoneInput?.value || ''
        };
        
        this.drivers.push(driver);
        this.saveDrivers();
        
        nameInput.value = '';
        phoneInput.value = '';
        document.getElementById('driver-modal')?.classList.remove('active');
        
        this.showNotification(`✅ Водитель ${driver.name} добавлен`);
    }

    addVehicle() {
        const plateInput = document.getElementById('vehicle-plate');
        const typeInput = document.getElementById('vehicle-type');
        const capacityInput = document.getElementById('vehicle-capacity');
        const transportInput = document.getElementById('vehicle-transport');
        const driverInput = document.getElementById('vehicle-driver');
        
        if (!plateInput?.value) {
            this.showNotification('Введите гос. номер', 'error');
            return;
        }
        
        const vehicle = {
            id: Date.now(),
            plate: plateInput.value,
            type: typeInput?.value || 'Фура',
            capacity: parseInt(capacityInput?.value) || 20000,
            transport: transportInput?.value || 'auto',
            driver: driverInput?.value || '',
            status: 'available'
        };
        
        this.vehicles.push(vehicle);
        
        // Обновляем транспорт в localStorage
        const existingVehicles = JSON.parse(localStorage.getItem('vehicles') || '[]');
        existingVehicles.push(vehicle);
        localStorage.setItem('vehicles', JSON.stringify(existingVehicles));
        
        // Обновляем список в интерфейсе
        this.renderVehiclesList();
        
        plateInput.value = '';
        capacityInput.value = '';
        driverInput.value = '';
        document.getElementById('vehicle-modal')?.classList.remove('active');
        
        this.showNotification(`✅ Транспорт ${vehicle.plate} добавлен`);
    }

    setupEventListeners() {
        // Кнопки навигации по неделям
        document.getElementById('prev-week')?.addEventListener('click', () => this.prevWeek());
        document.getElementById('next-week')?.addEventListener('click', () => this.nextWeek());
        
        // Кнопки маршрутов
        document.getElementById('btn-new-route')?.addEventListener('click', () => this.showNewRouteModal());
        
        // Кнопка добавления точки маршрута
        document.getElementById('btn-add-point')?.addEventListener('click', () => this.addRoutePoint());
        
        // Фильтры таблицы
        document.getElementById('filter-status-table')?.addEventListener('change', () => this.renderOrdersTable());
        document.getElementById('filter-date-from')?.addEventListener('change', () => this.renderOrdersTable());
        document.getElementById('filter-date-to')?.addEventListener('change', () => this.renderOrdersTable());
        document.getElementById('filter-driver-table')?.addEventListener('change', () => this.renderOrdersTable());
        
        // Добавление точки маршрута по Enter
        document.getElementById('new-point-address')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.addRoutePoint();
        });
        
        // Инициализация дат фильтров
        this.initDateFilters();
    }

    initDateFilters() {
        const dateFrom = document.getElementById('filter-date-from');
        const dateTo = document.getElementById('filter-date-to');
        
        if (dateFrom) {
            dateFrom.value = new Date().toISOString().split('T')[0];
        }
        
        if (dateTo) {
            const future = new Date();
            future.setMonth(future.getMonth() + 1);
            dateTo.value = future.toISOString().split('T')[0];
        }
    }

    // ==================== ЗАГРУЗКА ДАННЫХ ====================

    async loadData() {
        try {
            const [orders, vehicles] = await Promise.all([
                api.getOrders(),
                api.getVehicles()
            ]);
            
            this.orders = orders;
            this.vehicles = vehicles;
            
            // Обновляем селекторы водителей
            this.updateDriverSelects();
            
            this.renderOrdersTable();
            this.renderVehiclesList();
            this.updateMap();
        } catch (error) {
            console.error('[LOGISTIC] Ошибка загрузки данных:', error);
        }
    }

    loadContractors() {
        const contractors = JSON.parse(localStorage.getItem('tms_contractors') || '[]');
        if (contractors.length > 0) {
            this.contractors = contractors;
        } else {
            // Тестовые подрядчики
            this.contractors = [
                { id: 1, name: 'ООО "ТрансЛогик"', phone: '+7 (495) 123-45-67', type: 'Перевозчик' },
                { id: 2, name: 'ИП Иванов А.В.', phone: '+7 (916) 234-56-78', type: 'Частник' },
                { id: 3, name: 'ПАО "АвиаТранс"', phone: '+7 (495) 345-67-89', type: 'Авиа' }
            ];
            this.saveContractors();
        }
    }

    saveContractors() {
        localStorage.setItem('tms_contractors', JSON.stringify(this.contractors));
    }

    addContractor(name, phone, type) {
        const contractor = {
            id: Date.now(),
            name,
            phone,
            type
        };
        this.contractors.push(contractor);
        this.saveContractors();
        this.showNotification(`✅ Подрядчик "${name}" добавлен`);
        return contractor;
    }

    loadSavedRoutes() {
        const saved = localStorage.getItem('tms_saved_routes_v4');
        if (saved) {
            this.savedRoutes = JSON.parse(saved);
            this.renderSavedRoutes();
        }
    }

    saveRoutesToStorage() {
        localStorage.setItem('tms_saved_routes_v4', JSON.stringify(this.savedRoutes));
    }

    // ==================== ТАБЛИЦА ЗАЯВОК ====================

    renderOrdersTable() {
        const container = document.getElementById('orders-table-container');
        if (!container) return;
        
        const statusFilter = document.getElementById('filter-status-table')?.value || 'all';
        const dateFrom = document.getElementById('filter-date-from')?.value;
        const dateTo = document.getElementById('filter-date-to')?.value;
        const driverFilter = document.getElementById('filter-driver-table')?.value || 'all';
        
        let filteredOrders = this.orders.filter(o => {
            // Фильтр по статусу
            if (statusFilter !== 'all' && o.status !== statusFilter) return false;
            
            // Фильтр по дате
            if (dateFrom && o.orderDate) {
                const orderDate = new Date(o.orderDate);
                const fromDate = new Date(dateFrom);
                if (orderDate < fromDate) return false;
            }
            if (dateTo && o.orderDate) {
                const orderDate = new Date(o.orderDate);
                const toDate = new Date(dateTo);
                toDate.setHours(23, 59, 59, 999);
                if (orderDate > toDate) return false;
            }
            
            // Фильтр по водителю (если назначен в этапах)
            if (driverFilter !== 'all' && o.assignedDriver && o.assignedDriver !== driverFilter) {
                return false;
            }
            
            return true;
        });
        
        // По умолчанию показываем только новые и планированные
        if (statusFilter === 'all') {
            filteredOrders = filteredOrders.filter(o => o.status === 'new' || o.status === 'planned');
        }
        
        if (filteredOrders.length === 0) {
            container.innerHTML = `
                <div style="padding: 40px; text-align: center; color: #64748b;">
                    Нет заявок с выбранными фильтрами
                </div>
            `;
            return;
        }
        
        container.innerHTML = `
            <div class="table-wrapper">
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Статус</th>
                            <th>Дата</th>
                            <th>Клиент</th>
                            <th>Отправитель</th>
                            <th>Получатель</th>
                            <th>Водитель</th>
                            <th>Груз</th>
                            <th>Вес/Объём</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${filteredOrders.map(order => this.renderOrderRow(order)).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }

    renderOrderRow(order) {
        const hasCoords = order.pickupCoords && order.deliveryCoords;
        const isExpress = order.orderType === 'express';
        const assignedDriver = order.assignedDriver || '-';
        
        return `
            <tr data-order-id="${order.id}" class="${isExpress ? 'express-row' : ''}">
                <td><strong>#${order.id}</strong></td>
                <td>
                    <span class="status-badge status-${order.status}">
                        ${this.getStatusText(order.status)}
                    </span>
                </td>
                <td>${this.formatDate(order.orderDate)}</td>
                <td>${this.escapeHtml(order.client)}</td>
                <td title="${this.escapeHtml(order.pickupAddress || '')}">
                    ${this.truncate(order.pickupAddress, 30)}
                </td>
                <td title="${this.escapeHtml(order.deliveryAddress || '')}">
                    ${this.truncate(order.deliveryAddress, 30)}
                </td>
                <td>
                    <select onchange="logistic.assignDriverToOrder(${order.id}, this.value)" 
                            style="font-size: 12px; padding: 4px; min-width: 150px;">
                        <option value="">Без назначения</option>
                        ${this.drivers.map(d => 
                            `<option value="${d.id}" ${assignedDriver === d.id ? 'selected' : ''}>
                                ${this.escapeHtml(d.name)}
                            </option>`
                        ).join('')}
                    </select>
                </td>
                <td>${this.escapeHtml(order.cargoType || '-')}</td>
                <td>${order.weight || '-'} кг / ${order.volume || '-'} м³</td>
                <td>
                    <div class="row-actions">
                        ${hasCoords ? `
                            <button class="btn-icon" onclick="logistic.showRoute(${order.id})" title="Показать на карте">
                                🗺️
                            </button>
                            <button class="btn-icon btn-primary" onclick="logistic.addOrderToRoute(${order.id})" title="Добавить к маршруту">
                                ➕
                            </button>
                        ` : ''}
                        <button class="btn-icon btn-warning" onclick="logistic.editOrder(${order.id})" title="Редактировать">
                            ✏️
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }

    getStatusText(status) {
        const texts = {
            'new': 'Новая',
            'planned': 'Планированная',
            'in_transit': 'В пути',
            'delivered': 'Доставлена'
        };
        return texts[status] || status;
    }
        
    truncate(text, maxLength) {
        if (!text) return '-';
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength) + '...';
    }

    formatDate(dateString) {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU', {
            day: '2-digit',
            month: '2-digit'
        });
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // ==================== СПИСОК ТРАНСПОРТА ====================

    renderVehiclesList() {
        const container = document.getElementById('vehicles-list');
        if (!container) return;
        
        const available = this.vehicles.filter(v => v.status === 'available');
        
        container.innerHTML = available.map(vehicle => {
            const isAircraft = vehicle.transport === 'fly';
            return `
                <div class="vehicle-card ${isAircraft ? 'aircraft' : ''}" data-vehicle-id="${vehicle.id}">
                    <div class="vehicle-header">
                        <strong>${isAircraft ? '✈️' : '🚛'} ${vehicle.plate}</strong>
                        ${isAircraft ? '<span class="aircraft-badge">АВИА</span>' : ''}
                    </div>
                    <div class="vehicle-info">
                        <div>${vehicle.type}</div>
                        <div>Водитель: ${vehicle.driver || '-'}</div>
                        <div>Грузоподъёмность: ${vehicle.capacity} кг</div>
                    </div>
                </div>
            `;
        }).join('');
    }

    // ==================== ПОСТРОЕНИЕ МАРШРУТА (как в 1С) ====================

    updateDriverSelects() {
        // Обновляем селект водителей в модальном окне
        const modalDriverSelect = document.getElementById('new-point-driver');
        if (modalDriverSelect) {
            modalDriverSelect.innerHTML = `
                <option value="">Без назначения</option>
                ${this.drivers.map(d => 
                    `<option value="${d.id}">${this.escapeHtml(d.name)}</option>`
                ).join('')}
            `;
        }
        
        // Обновляем фильтр по водителю в таблице
        const filterDriverSelect = document.getElementById('filter-driver-table');
        if (filterDriverSelect) {
            const currentValue = filterDriverSelect.value;
            filterDriverSelect.innerHTML = `
                <option value="all">Все водители</option>
                ${this.drivers.map(d => 
                    `<option value="${d.id}">${this.escapeHtml(d.name)}</option>`
                ).join('')}
            `;
            filterDriverSelect.value = currentValue;
        }
    }

    showNewRouteModal() {
        this.routePoints = [];
        this.updateRoutePointsList();
        this.updateDriverSelects();
        
        const modal = document.getElementById('route-modal');
        if (modal) {
            modal.classList.add('active');
            document.getElementById('new-point-address').value = '';
            document.getElementById('new-point-date').value = new Date().toISOString().split('T')[0];
            document.getElementById('new-point-driver').value = '';
            document.getElementById('new-point-address').focus();
        }
    }

    closeRouteModal() {
        document.getElementById('route-modal')?.classList.remove('active');
    }

    async addRoutePoint() {
        const addressInput = document.getElementById('new-point-address');
        const dateInput = document.getElementById('new-point-date');
        const driverInput = document.getElementById('new-point-driver');
        const address = addressInput.value.trim();
        
        if (!address) {
            this.showNotification('Введите адрес точки!', 'error');
            return;
        }
        
        // Геокодинг адреса
        try {
            const results = await api.searchAddresses(address);
            
            if (results.length === 0) {
                this.showNotification('Адрес не найден!', 'error');
                return;
            }
            
            const point = {
                id: Date.now(),
                address: results[0].display_name,
                lat: parseFloat(results[0].lat),
                lng: parseFloat(results[0].lon),
                date: dateInput?.value || new Date().toISOString().split('T')[0],
                driverId: driverInput?.value || null
            };
            
            this.routePoints.push(point);
            addressInput.value = '';
            if (dateInput) dateInput.value = new Date().toISOString().split('T')[0];
            if (driverInput) driverInput.value = '';
            addressInput.focus();
            
            this.updateRoutePointsList();
            this.drawCurrentRoute();
            
            this.showNotification(`✅ Точка ${this.routePoints.length}: ${this.truncate(point.address, 40)}`);
        } catch (error) {
            console.error('Ошибка геокодинга:', error);
            this.showNotification('Ошибка поиска адреса', 'error');
        }
    }

    updateRoutePointsList() {
        const container = document.getElementById('route-points-list');
        if (!container) return;
        
        if (this.routePoints.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: #64748b; padding: 20px;">Добавьте точки маршрута</p>';
            return;
        }
        
        container.innerHTML = this.routePoints.map((point, index) => {
            const driverName = point.driverId ? this.drivers.find(d => d.id == point.driverId)?.name : 'Не назначен';
            const driverColor = point.driverId ? '#10b981' : '#64748b';
            
            return `
                <div class="route-point-item">
                    <div class="route-point-number">${index + 1}</div>
                    <div class="route-point-info">
                        <div class="route-point-address">${this.escapeHtml(point.address)}</div>
                        <div class="route-point-date">📅 ${point.date}</div>
                        <div class="route-point-driver" style="color: ${driverColor}; font-size: 11px; margin: 2px 0;">
                            👤 ${this.escapeHtml(driverName)}
                        </div>
                        <div class="route-point-coords">${point.lat.toFixed(4)}, ${point.lng.toFixed(4)}</div>
                    </div>
                    <button class="route-point-delete" onclick="logistic.removeRoutePoint(${index})">&times;</button>
                </div>
            `;
        }).join('');
        
        this.updateRouteSummary();
    }

    removeRoutePoint(index) {
        this.routePoints.splice(index, 1);
        this.updateRoutePointsList();
        this.drawCurrentRoute();
    }

    async updateRouteSummary() {
        const summaryEl = document.getElementById('route-summary');
        if (!summaryEl) return;
        
        if (this.routePoints.length < 2) {
            summaryEl.innerHTML = '';
            return;
        }
        
        // Получаем тип транспорта
        const transportType = document.getElementById('route-transport-type')?.value || 'auto';
        
        // Строим маршрут через OSRM для точного расстояния
        try {
            const osrmCoords = this.routePoints.map(p => [p.lng, p.lat]);
            const route = await OSRM.getRoute(osrmCoords, transportType === 'fly' ? 'driving' : 'driving');
            
            if (route.success) {
                const distance = Math.round(route.distance / 1000);
                const duration = Math.round(route.duration / 60);
                
                summaryEl.innerHTML = `
                    <div class="route-summary-info">
                        <div>📍 Точек: <strong>${this.routePoints.length}</strong></div>
                        <div>📏 Расстояние: <strong>${distance} км</strong></div>
                        <div>⏱️ Время: <strong>~${Math.floor(duration / 60)}ч ${duration % 60}мин</strong></div>
                    </div>
                `;
            }
        } catch (error) {
            console.error('Ошибка расчёта маршрута:', error);
            // Fallback: расчёт по прямой
            let totalDistance = 0;
            for (let i = 0; i < this.routePoints.length - 1; i++) {
                totalDistance += this.calculateDistance(
                    this.routePoints[i].lat, this.routePoints[i].lng,
                    this.routePoints[i+1].lat, this.routePoints[i+1].lng
                );
            }
            
            summaryEl.innerHTML = `
                <div class="route-summary-info">
                    <div>📍 Точек: <strong>${this.routePoints.length}</strong></div>
                    <div>📏 Расстояние: <strong>${totalDistance} км</strong></div>
                </div>
            `;
        }
    }

    async drawCurrentRoute() {
        if (!this.map || this.routePoints.length < 2) return;
        
        // Удалить старый маршрут
        if (this.routeLayer) {
            this.map.removeLayer(this.routeLayer);
        }
        
        // Удалить старые маркеры
        this.markers.forEach(m => this.map.removeLayer(m));
        this.markers = [];
        
        // Получаем тип транспорта
        const transportType = document.getElementById('route-transport-type')?.value || 'auto';
        
        // Строим маршрут через OSRM
        try {
            const osrmCoords = this.routePoints.map(p => [p.lng, p.lat]);
            const route = await OSRM.getRoute(osrmCoords, 'driving');
            
            if (route.success && route.geometry) {
                const routeCoords = OSRM.geojsonToLatLngs(route.geometry);
                
                this.routeLayer = L.polyline(routeCoords, {
                    color: transportType === 'fly' ? '#e74c3c' : '#3498db',
                    weight: transportType === 'fly' ? 3 : 5,
                    opacity: 0.8,
                    dashArray: transportType === 'fly' ? '10, 10' : null
                }).addTo(this.map);
            }
        } catch (error) {
            console.error('Ошибка построения маршрута:', error);
            // Fallback: прямые линии
            const coords = this.routePoints.map(p => [p.lat, p.lng]);
            this.routeLayer = L.polyline(coords, {
                color: transportType === 'fly' ? '#e74c3c' : '#3498db',
                weight: 3,
                dashArray: transportType === 'fly' ? '10, 10' : null
            }).addTo(this.map);
        }
        
        // Добавить маркеры точек
        this.routePoints.forEach((point, index) => {
            const isStart = index === 0;
            const isEnd = index === this.routePoints.length - 1;
            const color = isStart ? '#f39c12' : isEnd ? '#10b981' : '#3498db';
            
            const icon = L.divIcon({
                className: 'route-point-marker',
                html: `<div style="
                    background: ${color};
                    width: 32px; height: 32px; border-radius: 50%; 
                    border: 3px solid white; 
                    display: flex; align-items: center; justify-content: center;
                    font-weight: bold; color: white; font-size: 14px;
                    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                ">${index + 1}</div>`
            });
            
            const marker = L.marker([point.lat, point.lng], { icon })
                .bindPopup(`<b>Точка ${index + 1}</b><br>${this.escapeHtml(point.address)}`)
                .addTo(this.map);
            
            this.markers.push(marker);
        });
        
        // Центрировать карту
        const coords = this.routePoints.map(p => [p.lat, p.lng]);
        const bounds = L.latLngBounds(coords);
        this.map.fitBounds(bounds.pad(0.1));
    }

    async saveCurrentRoute() {
        if (this.routePoints.length < 2) {
            this.showNotification('Нужно минимум 2 точки!', 'error');
            return;
        }
        
        const name = prompt('Название маршрута:', `Маршрут ${this.savedRoutes.length + 1}`);
        if (!name) return;
        
        const transportType = document.getElementById('route-transport-type')?.value || 'auto';
        
        const route = {
            id: Date.now(),
            name: name,
            points: [...this.routePoints],
            transportType: transportType,
            createdAt: new Date().toISOString()
        };
        
        this.savedRoutes.push(route);
        this.saveRoutesToStorage();
        this.renderSavedRoutes();
        
        this.showNotification(`✅ Маршрут "${name}" сохранён!`);
        this.closeRouteModal();
    }

    clearCurrentRoute() {
        this.routePoints = [];
        
        if (this.routeLayer) {
            this.map.removeLayer(this.routeLayer);
            this.routeLayer = null;
        }
        
        this.markers.forEach(m => this.map.removeLayer(m));
        this.markers = [];
        
        this.updateRoutePointsList();
        this.showNotification('Маршрут очищен');
    }

    loadRoute(routeId) {
        const route = this.savedRoutes.find(r => r.id === routeId);
        if (!route) return;
        
        this.routePoints = [...route.points];
        
        const select = document.getElementById('route-transport-type');
        if (select) select.value = route.transportType;
        
        this.updateRoutePointsList();
        this.drawCurrentRoute();
        
        this.closeRouteModal();
        this.showNotification(`📂 Загружен маршрут: ${route.name}`);
    }

    deleteRoute(routeId) {
        if (!confirm('Удалить этот маршрут?')) return;
        
        this.savedRoutes = this.savedRoutes.filter(r => r.id !== routeId);
        this.saveRoutesToStorage();
        this.renderSavedRoutes();
        
        this.showNotification('Маршрут удалён');
    }

    renderSavedRoutes() {
        const container = document.getElementById('saved-routes-list');
        if (!container) return;
        
        if (this.savedRoutes.length === 0) {
            container.innerHTML = '<p style="padding: 20px; text-align: center; color: #64748b;">Нет сохранённых маршрутов</p>';
            return;
        }
        
        container.innerHTML = this.savedRoutes.map(route => {
            const isFly = route.transportType === 'fly';
            const icon = isFly ? '✈️' : '🚛';
            const distance = this.calculateRouteDistance(route.points);
            
            return `
            <div class="saved-route-item">
                <div class="saved-route-info">
                    <div class="saved-route-name">${icon} ${this.escapeHtml(route.name)}</div>
                    <div class="saved-route-stats">${route.points.length} точек, ${distance} км</div>
                </div>
                <div class="saved-route-actions">
                    <button class="btn-small" onclick="logistic.loadRoute(${route.id})">Загрузить</button>
                    <button class="btn-small btn-danger" onclick="logistic.deleteRoute(${route.id})">&times;</button>
                </div>
            </div>
            `;
        }).join('');
    }

    calculateRouteDistance(points) {
        if (points.length < 2) return 0;
        
        let total = 0;
        for (let i = 0; i < points.length - 1; i++) {
            total += this.calculateDistance(
                points[i].lat, points[i].lng,
                points[i+1].lat, points[i+1].lng
            );
        }
        return Math.round(total);
    }

    // ==================== РАБОТА С ЗАЯВКАМИ ====================

    addOrderToRoute(orderId) {
        const order = this.orders.find(o => o.id == orderId);
        if (!order) return;
        
        if (!order.pickupCoords || !order.deliveryCoords) {
            this.showNotification('У заявки нет координат!', 'error');
            return;
        }
        
        // Открываем модальное окно маршрута
        this.showNewRouteModal();
        
        // Получаем дату заявки
        const orderDate = order.orderDate ? new Date(order.orderDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0];
        
        // Получаем назначенного водителя
        const assignedDriver = order.assignedDriver || '';
        
        // Добавляем точки из заявки с датами и водителем
        this.routePoints = [
            {
                id: Date.now(),
                address: order.pickupAddress,
                lat: order.pickupCoords.lat,
                lng: order.pickupCoords.lng,
                date: orderDate,
                driverId: assignedDriver
            },
            {
                id: Date.now() + 1,
                address: order.deliveryAddress,
                lat: order.deliveryCoords.lat,
                lng: order.deliveryCoords.lng,
                date: orderDate, // или следующий день
                driverId: assignedDriver
            }
        ];
        
        // Устанавливаем тип транспорта
        const select = document.getElementById('route-transport-type');
        if (select) {
            select.value = order.orderType === 'express' ? 'fly' : 'auto';
        }
        
        this.updateRoutePointsList();
        this.drawCurrentRoute();
        
        this.showNotification('🗺️ Маршрут построен по заявке');
    }

    assignDriverToOrder(orderId, driverId) {
        const order = this.orders.find(o => o.id == orderId);
        if (!order) return;
        
        if (driverId) {
            order.assignedDriver = driverId;
            this.showNotification(`✅ Водитель назначен на заявку #${orderId}`);
        } else {
            delete order.assignedDriver;
            this.showNotification('👤 Назначение водителя снято');
        }
        
        // Сохраняем изменения
        this.saveOrders();
    }

    saveOrders() {
        localStorage.setItem('orders', JSON.stringify(this.orders));
    }

    editOrder(orderId) {
        if (window.manager && typeof window.manager.editOrder === 'function') {
            window.manager.editOrder(orderId);
        } else {
            this.showNotification('Модуль менеджера не найден', 'error');
        }
    }

    // ==================== КАРТА ====================

    initMapOnShow() {
        const mapContainer = document.getElementById('logistics-map');
        if (!mapContainer) return;
        
        if (this.map) {
            setTimeout(() => {
                this.map.invalidateSize();
                this.updateMap();
            }, 100);
            return;
        }
        
        try {
            this.map = L.map('logistics-map', {
                center: [55.7558, 37.6173],
                zoom: 8
            });
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            }).addTo(this.map);

            setTimeout(() => {
                if (this.map) {
                    this.map.invalidateSize();
                    this.updateMap();
                }
            }, 300);
            
        } catch (error) {
            console.error('[LOGISTIC] Ошибка карты:', error);
        }
    }

    updateMap() {
        if (!this.map) return;
        
        this.markers.forEach(m => this.map.removeLayer(m));
        this.markers = [];
        
        const ordersToShow = this.orders.filter(o => o.status === 'new' || o.status === 'planned');
        
        ordersToShow.forEach(order => {
            if (order.pickupCoords && typeof order.pickupCoords.lat === 'number') {
                const marker = L.marker([order.pickupCoords.lat, order.pickupCoords.lng])
                    .addTo(this.map)
                    .bindPopup(`<b>Заявка #${order.id}</b><br>${this.escapeHtml(order.client)}`);
                this.markers.push(marker);
            }
        });
        
        if (this.markers.length > 0) {
            const group = L.featureGroup(this.markers);
            this.map.fitBounds(group.getBounds().pad(0.1));
        }
    }

    showRoute(orderId) {
        const order = this.orders.find(o => o.id == orderId);
        if (!order || !this.map) return;
        
        if (!order.pickupCoords || !order.deliveryCoords) {
            this.showNotification('У заявки нет координат', 'error');
            return;
        }
        
        // Убираем старые маркеры
        this.markers.forEach(m => this.map.removeLayer(m));
        this.markers = [];
        
        // Добавляем маркеры заявки
        L.marker([order.pickupCoords.lat, order.pickupCoords.lng])
            .addTo(this.map)
            .bindPopup(`<b>📦 Забор</b><br>${this.escapeHtml(order.pickupAddress)}`);
        
        L.marker([order.deliveryCoords.lat, order.deliveryCoords.lng])
            .addTo(this.map)
            .bindPopup(`<b>🏠 Доставка</b><br>${this.escapeHtml(order.deliveryAddress)}`);
        
        // Рисуем линию
        const routeLine = L.polyline([
            [order.pickupCoords.lat, order.pickupCoords.lng],
            [order.deliveryCoords.lat, order.deliveryCoords.lng]
        ], {
            color: '#667eea',
            weight: 4,
            opacity: 0.7
        }).addTo(this.map);
        
        this.markers.push(routeLine);
        
        // Центрируем
        const group = L.featureGroup([
            L.marker([order.pickupCoords.lat, order.pickupCoords.lng]),
            L.marker([order.deliveryCoords.lat, order.deliveryCoords.lng])
        ]);
        this.map.fitBounds(group.getBounds().pad(0.2));
        
        this.showNotification('🗺️ Маршрут показан на карте');
    }

    // ==================== КАЛЕНДАРЬ ====================

    getWeekStart(date) {
        const d = new Date(date);
        const day = d.getDay();
        const diff = d.getDate() - day + (day === 0 ? -6 : 1);
        return new Date(d.setDate(diff));
    }

    prevWeek() {
        this.currentWeekStart.setDate(this.currentWeekStart.getDate() - 7);
        this.updateWeekDisplay();
    }

    nextWeek() {
        this.currentWeekStart.setDate(this.currentWeekStart.getDate() + 7);
        this.updateWeekDisplay();
    }

    updateWeekDisplay() {
        const end = new Date(this.currentWeekStart);
        end.setDate(end.getDate() + 6);
        
        const options = { day: '2-digit', month: '2-digit' };
        const weekEl = document.getElementById('current-week');
        if (weekEl) {
            weekEl.textContent = 
                `${this.currentWeekStart.toLocaleDateString('ru-RU', options)} - ${end.toLocaleDateString('ru-RU', options)}`;
        }
    }

    // ==================== ВСПОМОГАТЕЛЬНЫЕ ====================

    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371;
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                  Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = 'notification' + (type === 'error' ? ' error' : '');
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.add('active'), 10);
        setTimeout(() => {
            notification.classList.remove('active');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}

// Инициализация
let logistic;
document.addEventListener('DOMContentLoaded', () => {
    logistic = new LogisticModule();
    window.logistic = logistic;
});
