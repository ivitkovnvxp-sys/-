// Модуль карты - отображение всех заявок
class MapModule {
    constructor() {
        this.map = null;
        this.markers = [];
        this.routes = [];
        this.orders = [];
        
        this.init();
    }

    init() {
        this.initMap();
        this.setupFilters();
        this.loadOrders();
    }

    initMap() {
        // Центрируем на Москве по умолчанию
        this.map = L.map('main-map').setView([55.7558, 37.6173], 8);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors',
            maxZoom: 19
        }).addTo(this.map);

        // Кастомные иконки
        this.pickupIcon = L.divIcon({
            className: 'custom-marker',
            html: '<div style="background: #2563eb; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>',
            iconSize: [24, 24],
            iconAnchor: [12, 12]
        });

        this.deliveryIcon = L.divIcon({
            className: 'custom-marker',
            html: '<div style="background: #10b981; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>',
            iconSize: [24, 24],
            iconAnchor: [12, 12]
        });

        this.plannedIcon = L.divIcon({
            className: 'custom-marker',
            html: '<div style="background: #f59e0b; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>',
            iconSize: [24, 24],
            iconAnchor: [12, 12]
        });
    }

    async loadOrders() {
        try {
            this.orders = await api.getOrders();
            this.renderMarkers(this.orders);
        } catch (error) {
            console.error('Ошибка загрузки заявок:', error);
        }
    }

    setupFilters() {
        const filter = document.getElementById('map-status-filter');
        filter.addEventListener('change', (e) => {
            this.filterOrders(e.target.value);
        });

        document.getElementById('btn-show-all').addEventListener('click', () => {
            filter.value = 'all';
            this.filterOrders('all');
        });
    }

    filterOrders(status) {
        if (status === 'all') {
            this.renderMarkers(this.orders);
        } else {
            const filtered = this.orders.filter(o => o.status === status);
            this.renderMarkers(filtered);
        }
    }

    renderMarkers(orders) {
        // Очистка старых маркеров и маршрутов
        this.markers.forEach(marker => this.map.removeLayer(marker));
        this.routes.forEach(route => this.map.removeLayer(route));
        this.markers = [];
        this.routes = [];

        if (orders.length === 0) {
            return;
        }

        const bounds = L.latLngBounds();

        orders.forEach(order => {
            let icon = this.plannedIcon;
            if (order.status === 'new') icon = this.pickupIcon;
            else if (order.status === 'delivered') icon = this.deliveryIcon;

            // Маркер точки загрузки
            if (order.pickupCoords?.lat && order.pickupCoords?.lng) {
                const marker = L.marker([order.pickupCoords.lat, order.pickupCoords.lng], { icon })
                    .addTo(this.map)
                    .bindPopup(this.createPopupContent(order, 'pickup'));
                
                this.markers.push(marker);
                bounds.extend([order.pickupCoords.lat, order.pickupCoords.lng]);
            }

            // Маркер точки доставки
            if (order.deliveryCoords?.lat && order.deliveryCoords?.lng) {
                const marker = L.marker([order.deliveryCoords.lat, order.deliveryCoords.lng], { 
                    icon: order.status === 'delivered' ? this.deliveryIcon : this.plannedIcon 
                })
                    .addTo(this.map)
                    .bindPopup(this.createPopupContent(order, 'delivery'));
                
                this.markers.push(marker);
                bounds.extend([order.deliveryCoords.lat, order.deliveryCoords.lng]);
            }

            // Рисуем маршрут если есть обе точки
            if (order.pickupCoords?.lat && order.deliveryCoords?.lat) {
                this.drawRoute(order);
            }
        });

        // Подгоняем масштаб чтобы все маркеры были видны
        if (bounds.isValid()) {
            this.map.fitBounds(bounds.pad(0.1));
        }
    }

    createPopupContent(order, type) {
        const statusText = {
            'new': 'Новая',
            'planned': 'Планированная',
            'in_transit': 'В пути',
            'delivered': 'Доставлена'
        };

        let html = `
            <div style="min-width: 250px;">
                <h3 style="margin: 0 0 10px 0; color: #2563eb;">Заявка #${order.id}</h3>
                <table style="width: 100%; font-size: 13px;">
                    <tr>
                        <td style="padding: 4px 0;"><strong>Клиент:</strong></td>
                        <td>${this.escapeHtml(order.client)}</td>
                    </tr>
                    <tr>
                        <td style="padding: 4px 0;"><strong>Статус:</strong></td>
                        <td>${statusText[order.status] || order.status}</td>
                    </tr>
                    <tr>
                        <td style="padding: 4px 0;"><strong>Приоритет:</strong></td>
                        <td>${this.formatPriority(order.priority)}</td>
                    </tr>
        `;

        if (type === 'pickup') {
            html += `
                    <tr>
                        <td style="padding: 4px 0;"><strong>📍 Загрузка:</strong></td>
                        <td>${this.escapeHtml(order.pickupAddress)}</td>
                    </tr>
                    ${order.pickupContact ? `<tr><td style="padding: 4px 0;"><strong>Контакт:</strong></td><td>${this.escapeHtml(order.pickupContact)} ${order.pickupPhone ? '(' + order.pickupPhone + ')' : ''}</td></tr>` : ''}
            `;
        } else {
            html += `
                    <tr>
                        <td style="padding: 4px 0;"><strong>📍 Доставка:</strong></td>
                        <td>${this.escapeHtml(order.deliveryAddress)}</td>
                    </tr>
                    ${order.deliveryContact ? `<tr><td style="padding: 4px 0;"><strong>Контакт:</strong></td><td>${this.escapeHtml(order.deliveryContact)} ${order.deliveryPhone ? '(' + order.deliveryPhone + ')' : ''}</td></tr>` : ''}
            `;
        }

        html += `
                    ${order.weight || order.volume ? `
                    <tr>
                        <td style="padding: 4px 0;"><strong>Груз:</strong></td>
                        <td>${order.weight ? order.weight + ' кг' : ''} ${order.volume ? '• ' + order.volume + ' м³' : ''}</td>
                    </tr>
                    ` : ''}
                    ${order.orderDate ? `
                    <tr>
                        <td style="padding: 4px 0;"><strong>Дата:</strong></td>
                        <td>${this.formatDateTime(order.orderDate)}</td>
                    </tr>
                    ` : ''}
                </table>
                <div style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #e2e8f0;">
                    <button onclick="manager.editOrder(${order.id})" style="padding: 6px 12px; margin-right: 8px; background: #2563eb; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        ✏️ Редактировать
                    </button>
                    <button onclick="manager.deleteOrder(${order.id})" style="padding: 6px 12px; background: #ef4444; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        🗑️ Удалить
                    </button>
                </div>
            </div>
        `;

        return html;
    }

    formatPriority(priority) {
        const priorities = {
            'normal': 'Обычный',
            'high': 'Высокий',
            'urgent': 'Срочный'
        };
        return priorities[priority] || 'Обычный';
    }

    formatDateTime(dateString) {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleString('ru-RU', {
            day: '2-digit',
            month: '2-digit',
            year: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    drawRoute(order) {
        // В реальной реализации можно использовать Routing Machine
        // Для демо рисуем прямую линию
        const polyline = L.polyline([
            [order.pickupCoords.lat, order.pickupCoords.lng],
            [order.deliveryCoords.lat, order.deliveryCoords.lng]
        ], {
            color: this.getStatusColor(order.status),
            weight: 3,
            opacity: 0.7,
            dashArray: '5, 10'
        }).addTo(this.map);

        polyline.bindTooltip(`Маршрут заявки #${order.id}`, {
            permanent: false,
            direction: 'center'
        });

        this.routes.push(polyline);
    }

    getStatusColor(status) {
        const colors = {
            'new': '#2563eb',
            'planned': '#f59e0b',
            'in_transit': '#8b5cf6',
            'delivered': '#10b981'
        };
        return colors[status] || '#64748b';
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    focusOnOrder(orderId) {
        const order = this.orders.find(o => o.id == orderId);
        if (!order) return;

        // Очистить все маркеры кроме этой заявки
        this.markers.forEach(marker => this.map.removeLayer(marker));
        this.markers = [];

        // Показать только маркеры этой заявки
        if (order.pickupCoords?.lat && order.pickupCoords?.lng) {
            const marker = L.marker([order.pickupCoords.lat, order.pickupCoords.lng], { icon: this.pickupIcon })
                .addTo(this.map)
                .bindPopup(this.createPopupContent(order, 'pickup'))
                .openPopup();
            
            this.markers.push(marker);
        }

        if (order.deliveryCoords?.lat && order.deliveryCoords?.lng) {
            const marker = L.marker([order.deliveryCoords.lat, order.deliveryCoords.lng], { icon: this.deliveryIcon })
                .addTo(this.map)
                .bindPopup(this.createPopupContent(order, 'delivery'));
            
            this.markers.push(marker);
        }

        // Центрируем карту
        if (order.pickupCoords?.lat && order.deliveryCoords?.lat) {
            const group = L.featureGroup(this.markers);
            this.map.fitBounds(group.getBounds().pad(0.2));
        }
    }
}

// Инициализация
let mapModule;
document.addEventListener('DOMContentLoaded', () => {
    // Карта инициализируется только когда переходим на вкладку
    const mapView = document.getElementById('map-view');
    if (mapView) {
        mapView.addEventListener('click', () => {
            if (!mapModule) {
                mapModule = new MapModule();
                window.mapModule = mapModule;
            }
        }, { once: true });
    }
});
