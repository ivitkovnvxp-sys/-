// OSRM Маршрутизация - бесплатная альтернатива Яндекс Картам
// Использует Open Source Routing Machine

const OSRM = {
    baseURL: 'https://router.project-osrm.org/route/v1',
    tableURL: 'https://router.project-osrm.org/table/v1',
    
    // Построить маршрут по дорогам
    async getRoute(coords, profile = 'driving') {
        // coords: [[lat, lng], [lat, lng], ...]
        const osrmCoords = coords.map(c => `${c[1]},${c[0]}`).join(';');
        const url = `${this.baseURL}/${profile}/${osrmCoords}?overview=full&geometries=geojson&steps=true`;
        
        try {
            const response = await fetch(url);
            const data = await response.json();
            
            if (data.code === 'Ok' && data.routes && data.routes.length > 0) {
                const route = data.routes[0];
                return {
                    success: true,
                    geometry: route.geometry,
                    distance: route.distance, // метры
                    duration: route.duration, // секунды
                    legs: route.legs
                };
            }
            
            return { success: false, error: data.code };
        } catch (error) {
            console.error('OSRM Error:', error);
            return { success: false, error: error.message };
        }
    },
    
    // Рассчитать таблицу расстояний между точками
    async getDistanceMatrix(coords, profile = 'driving') {
        const osrmCoords = coords.map(c => `${c[1]},${c[0]}`).join(';');
        const url = `${this.tableURL}/${profile}/${osrmCoords}?sources=all&destinations=all`;
        
        try {
            const response = await fetch(url);
            const data = await response.json();
            
            if (data.code === 'Ok') {
                return {
                    success: true,
                    distances: data.distances, // матрица расстояний (метры)
                    durations: data.durations, // матрица времени (секунды)
                    sources: data.sources,
                    destinations: data.destinations
                };
            }
            
            return { success: false, error: data.code };
        } catch (error) {
            console.error('OSRM Matrix Error:', error);
            return { success: false, error: error.message };
        }
    },
    
    // Преобразовать GeoJSON в координаты Leaflet
    geojsonToLatLngs(geojson) {
        if (!geojson || !geojson.coordinates) return [];
        return geojson.coordinates.map(c => [c[1], c[0]]);
    },
    
    // Рассчитать время в пути
    calculateTime(distanceMeters, transportType) {
        const distanceKm = distanceMeters / 1000;
        const speeds = {
            auto: 60,
            fly: 800,
            walking: 5,
            cycling: 20
        };
        
        const speed = speeds[transportType] || speeds.auto;
        const hours = distanceKm / speed;
        
        return {
            hours: Math.floor(hours),
            minutes: Math.round((hours - Math.floor(hours)) * 60),
            totalMinutes: Math.round(hours * 60),
            distanceKm: Math.round(distanceKm)
        };
    },
    
    // Оптимизировать порядок точек (алгоритм ближайшего соседа)
    optimizeRoute(points) {
        if (points.length < 3) return points;
        
        // Простая эвристика - начинаем с первой точки
        const optimized = [points[0]];
        const remaining = points.slice(1);
        
        while (remaining.length > 0) {
            const last = optimized[optimized.length - 1];
            let nearestIdx = 0;
            let nearestDist = this.distance(last, remaining[0]);
            
            for (let i = 1; i < remaining.length; i++) {
                const dist = this.distance(last, remaining[i]);
                if (dist < nearestDist) {
                    nearestDist = dist;
                    nearestIdx = i;
                }
            }
            
            optimized.push(remaining[nearestIdx]);
            remaining.splice(nearestIdx, 1);
        }
        
        return optimized;
    },
    
    // Расстояние между двумя точками (Haversine)
    distance(p1, p2) {
        const R = 6371;
        const dLat = (p2[0] - p1[0]) * Math.PI / 180;
        const dLon = (p2[1] - p1[1]) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(p1[0] * Math.PI / 180) * Math.cos(p2[0] * Math.PI / 180) *
                  Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }
};

// Экспорт в глобальную область
window.OSRM = OSRM;
console.log('✅ OSRM маршрутизация загружена');
