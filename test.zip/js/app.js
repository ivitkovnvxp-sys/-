// Основной файл приложения - навигация и инициализация
class TMSApp {
    constructor() {
        this.currentView = 'calculator';
        this.init();
    }

    init() {
        this.setupNavigation();
        this.checkFirstTime();
        
        // Инициализация калькулятора при загрузке
        setTimeout(() => {
            this.initViewModules('calculator');
        }, 100);
    }

    setupNavigation() {
        const navItems = document.querySelectorAll('.nav-item');
        
        navItems.forEach(item => {
            item.addEventListener('click', () => {
                const viewName = item.dataset.view;
                this.switchView(viewName);
            });
        });
    }

    switchView(viewName) {
        // Обновление активной кнопки в меню
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
            if (item.dataset.view === viewName) {
                item.classList.add('active');
            }
        });

        // Скрытие всех views
        document.querySelectorAll('.view').forEach(view => {
            view.classList.remove('active');
        });

        // Показ нужного view
        const targetView = document.getElementById(`${viewName}-view`);
        if (targetView) {
            targetView.classList.add('active');
        }

        // Обновление заголовка
        const titles = {
            'calculator': 'Калькулятор "Вторая Миля"',
            'manager': 'Создание заявки',
            'logistic': 'Планирование перевозок',
            'map': 'Карта заявок',
            'reports': 'Отчеты и статистика'
        };
        document.getElementById('page-title').textContent = titles[viewName] || 'TMS';

        this.currentView = viewName;

        // Инициализация модулей при первом переходе
        this.initViewModules(viewName);
    }

    initViewModules(viewName) {
        console.log('initViewModules called for:', viewName);
        
        // Менеджер инициализируется сразу
        if (viewName === 'manager' && !window.manager) {
            import('./manager.js').then(() => {
                if (!window.manager) {
                    window.manager = new ManagerModule();
                }
            });
        }

        // Калькулятор "Вторая Миля"
        if (viewName === 'calculator') {
            console.log('Calculator view activated');
            if (!window.tmsCalculatorInitialized) {
                window.tmsCalculatorInitialized = true;
                console.log('Initializing TMS Calculator from app.js');
                if (typeof initTMSCalculator === 'function') {
                    initTMSCalculator();
                } else {
                    console.error('initTMSCalculator function not found!');
                }
            } else {
                console.log('TMS Calculator already initialized');
            }
        }

        // Логист
        if (viewName === 'logistic') {
            // Инициализируем карту при активации вкладки
            if (window.logistic && typeof window.logistic.initMapOnShow === 'function') {
                setTimeout(() => {
                    window.logistic.initMapOnShow();
                }, 200);
            }
        }

        // Карта - инициализируется при первом открытии
        if (viewName === 'map' && !window.mapModule) {
            // Карта инициализируется в map.js
        }

        // Отчеты
        if (viewName === 'reports' && !window.reports) {
            // Модуль отчетов уже инициализируется в своем файле
        }
    }

    checkFirstTime() {
        const isFirstTime = localStorage.getItem('tms_first_time');
        
        if (!isFirstTime) {
            this.showWelcomeModal();
            localStorage.setItem('tms_first_time', 'false');
        }
    }

    showWelcomeModal() {
        const modal = document.createElement('div');
        modal.className = 'modal active';
        modal.innerHTML = `
            <div class="modal-content" style="max-width: 600px;">
                <span class="modal-close">&times;</span>
                <h2 style="margin-bottom: 20px;">🚚 Добро пожаловать в TMS Pro!</h2>
                <div style="line-height: 1.8;">
                    <p><strong>TMS Pro</strong> - это система управления перевозками для транспортных компаний.</p>
                    
                    <h3 style="margin: 20px 0 10px 0;">Основные возможности:</h3>
                    <ul style="margin-left: 20px;">
                        <li><strong>Менеджер заявок</strong> - создание и управление заявками на перевозку с автодополнением адресов</li>
                        <li><strong>Планирование</strong> - удобная система Drag & Drop для назначения транспорта и планирования дат</li>
                        <li><strong>Карта заявок</strong> - визуализация всех заявок на карте с маршрутами</li>
                        <li><strong>Отчеты</strong> - статистика и аналитика работы</li>
                    </ul>

                    <h3 style="margin: 20px 0 10px 0;">Как начать:</h3>
                    <ol style="margin-left: 20px;">
                        <li>Перейдите в раздел <strong>"Менеджер заявок"</strong></li>
                        <li>Создайте новую заявку, заполнив форму</li>
                        <li>Используйте автодополнение адресов (начните вводить адрес)</li>
                        <li>Перейдите в <strong>"Планирование"</strong> для назначения транспорта</li>
                        <li>Перетащите заявку на доступное транспортное средство</li>
                    </ol>

                    <p style="margin-top: 20px; color: #64748b; font-size: 14px;">
                        💡 В демо-режиме все данные сохраняются в браузере (localStorage). 
                        Для production используйте backend с PostgreSQL.
                    </p>
                </div>
                <button class="btn btn-primary" style="margin-top: 20px; width: 100%;">
                    Начать работу
                </button>
            </div>
        `;

        document.body.appendChild(modal);

        // Закрытие модального окна
        modal.querySelector('.modal-close').addEventListener('click', () => {
            modal.remove();
        });

        modal.querySelector('.btn-primary').addEventListener('click', () => {
            modal.remove();
        });

        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }
}

// Инициализация приложения
document.addEventListener('DOMContentLoaded', () => {
    const app = new TMSApp();
    window.tmsApp = app;

    // Проверка поддержки localStorage
    try {
        localStorage.setItem('test', 'test');
        localStorage.removeItem('test');
    } catch (e) {
        alert('Ваш браузер не поддерживает localStorage. Некоторые функции могут не работать.');
    }

    // Обработка ошибок
    window.addEventListener('error', (e) => {
        console.error('Global error:', e.error);
    });

    // Печать стилей для уведомлений
    const style = document.createElement('style');
    style.textContent = `
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 25px;
            background: #10b981;
            color: white;
            border-radius: 6px;
            box-shadow: 0 10px 15px rgba(0, 0, 0, 0.1);
            z-index: 3000;
            transform: translateX(400px);
            transition: transform 0.3s ease;
        }
        
        .notification.active {
            transform: translateX(0);
        }
        
        .notification.error {
            background: #ef4444;
        }
    `;
    document.head.appendChild(style);
});

// Глобальные функции для onclick обработчиков
window.editOrder = function(orderId) {
    if (window.manager) {
        window.manager.editOrder(orderId);
    }
};

window.deleteOrder = function(orderId) {
    if (window.manager) {
        window.manager.deleteOrder(orderId);
    }
};

window.viewOnMap = function(orderId) {
    if (window.manager) {
        window.manager.viewOnMap(orderId);
    }
};
