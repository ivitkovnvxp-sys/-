// Модуль логиста v3 - Улучшенная версия с табличным видом
class LogisticModule {
    constructor() {
        this.orders = [];
        this.vehicles = [];
        this.drivers = [];
        this.map = null;
        this.builderMap = null;
        this.markers = [];
        this.currentRoute = {
            id: Date.now(),
            name: '',
            region: '',
            legs: [],
            thermalBoxes: [],
            returnRoute: null
        };
        this.savedRoutes = [];
        this.routeTemplates = [];
        
        this.init();
    }

    init() {
        this.loadData();
        this.loadDrivers();
        this.loadSavedRoutes();
        this.loadRouteTemplates();
        this.setupEventListeners();
    }

    loadDrivers() {
        const drivers = JSON.parse(localStorage.getItem('drivers') || '[]');
        if (drivers.length > 0) {
            this.drivers = drivers;
        }
    }

    showDriverModal() {
        document.getElementById('driver-modal').classList.add('active');
    }

    showVehicleModal() {
        document.getElementById('vehicle-modal').classList.add('active');
    }

    addDriver() {
        const nameInput = document.getElementById('driver-name');
        const phoneInput = document.getElementById('driver-phone');
        
        if (!nameInput.value) {
            this.showNotification('Введите ФИО водителя', 'error');
            return;
        }
        
        const driver = {
            id: Date.now(),
            name: nameInput.value,
            phone: phoneInput.value
        };
        
        this.drivers.push(driver);
        localStorage.setItem('drivers', JSON.stringify(this.drivers));
        
        nameInput.value = '';
        phoneInput.value = '';
        document.getElementById('driver-modal').classList.remove('active');
        
        this.showNotification(`✅ Водитель ${driver.name} добавлен`);
    }

    addVehicle() {
        const plateInput = document.getElementById('vehicle-plate');
        const typeInput = document.getElementById('vehicle-type');
        const capacityInput = document.getElementById('vehicle-capacity');
        const transportInput = document.getElementById('vehicle-transport');
        const driverInput = document.getElementById('vehicle-driver');
        
        if (!plateInput.value) {
            this.showNotification('Введите гос. номер', 'error');
            return;
        }
        
        const vehicle = {
            id: Date.now(),
            plate: plateInput.value,
            type: typeInput.value,
            capacity: parseInt(capacityInput.value) || 0,
            transport: transportInput.value,
            driver: driverInput.value,
            status: 'available'
        };
        
        this.vehicles.push(vehicle);
        
        // Обновляем транспорт в API
        const existingVehicles = JSON.parse(localStorage.getItem('vehicles') || '[]');
        existingVehicles.push(vehicle);
        localStorage.setItem('vehicles', JSON.stringify(existingVehicles));
        
        // Обновляем список в интерфейсе
        this.renderVehiclesList();
        
        plateInput.value = '';
        capacityInput.value = '';
        driverInput.value = '';
        document.getElementById('vehicle-modal').classList.remove('active');
        
        this.showNotification(`✅ Транспорт ${vehicle.plate} добавлен`);
    }

    setupEventListeners() {
        document.getElementById('btn-new-route')?.addEventListener('click', () => this.openRouteBuilder());
        document.getElementById('prev-week')?.addEventListener('click', () => this.prevWeek());
        document.getElementById('next-week')?.addEventListener('click', () => this.nextWeek());
        
        // Фильтры для таблицы
        document.getElementById('filter-status')?.addEventListener('change', () => this.renderOrdersTable());
        document.getElementById('filter-region')?.addEventListener('change', () => this.renderOrdersTable());
        
        // Автокомплит для адресов
        this.setupAddressAutocomplete();
    }

    setupAddressAutocomplete() {
        // Поиск адресов с автоподсказками
        const searchInput = document.getElementById('route-search-address');
        if (!searchInput) return;
        
        let timeoutId = null;
        
        searchInput.addEventListener('input', (e) => {
            clearTimeout(timeoutId);
            const query = e.target.value;
            
            if (query.length < 3) {
                this.hideAddressSuggestions();
                return;
            }
            
            timeoutId = setTimeout(async () => {
                const results = await api.searchAddresses(query);
                this.showAddressSuggestions(results);
            }, 300);
        });
            
        // Скрытие подсказок при клике вне
        document.addEventListener('click', (e) => {
            if (!searchInput.contains(e.target)) {
                this.hideAddressSuggestions();
            }
        });
    }

    showAddressSuggestions(results) {
        const container = document.getElementById('address-suggestions');
        if (!container) return;
        
        if (results.length === 0) {
            this.hideAddressSuggestions();
            return;
        }
        
        container.innerHTML = results.map((item, index) => `
            <div class="address-suggestion" data-index="${index}" 
                 onclick="logistic.selectAddress(${item.lat}, ${item.lon}, '${item.display_name.replace(/'/g, "\\'")}')">
                ${item.display_name}
            </div>
        `).join('');
        
        container.classList.add('visible');
    }

    hideAddressSuggestions() {
        const container = document.getElementById('address-suggestions');
        if (container) {
            container.classList.remove('visible');
        }
    }

    selectAddress(lat, lon, address) {
        const input = document.getElementById('route-search-address');
        if (input) {
            input.value = address;
            input.dataset.lat = lat;
            input.dataset.lon = lon;
        }
        this.hideAddressSuggestions();
    }

    // ==================== ЗАГРУЗКА ДАННЫХ ====================
    
    async loadData() {
        try {
            const [orders, vehicles] = await Promise.all([
                api.getOrders(),
                api.getVehicles()
            ]);
            
            this.orders = orders;
            this.vehicles = vehicles;
            
            this.renderOrdersTable();
            this.renderVehiclesList();
            this.updateCalendar();
            this.initMapOnShow();
        } catch (error) {
            console.error('[LOGISTIC] Ошибка загрузки данных:', error);
        }
    }

    loadSavedRoutes() {
        const saved = localStorage.getItem('tms_routes_v3');
        if (saved) {
            this.savedRoutes = JSON.parse(saved);
            this.renderSavedRoutesList();
        }
    }

    saveRoutesToStorage() {
        localStorage.setItem('tms_routes_v3', JSON.stringify(this.savedRoutes));
    }

    loadRouteTemplates() {
        const templates = localStorage.getItem('tms_route_templates');
        if (templates) {
            this.routeTemplates = JSON.parse(templates);
        } else {
            // Базовые шаблоны
            this.routeTemplates = [
                {
                    id: 1,
                    name: 'Москва - Санкт-Петербург',
                    region: 'Центр - Северо-Запад',
                    legs: [
                        { type: 'mile1', name: 'Забор груза (Москва)', transport: 'auto', agent: '' },
                        { type: 'mile2', name: 'Магистраль', transport: 'auto', agent: '' },
                        { type: 'mile3', name: 'Доставка (СПб)', transport: 'auto', agent: '' }
                    ]
                }
            ];
            this.saveTemplates();
        }
    }

    saveTemplates() {
        localStorage.setItem('tms_route_templates', JSON.stringify(this.routeTemplates));
    }

    // ==================== ТАБЛИЦА ЗАЯВОК ====================
    
    renderOrdersTable() {
        const container = document.getElementById('orders-table-container');
        if (!container) return;
        
        const statusFilter = document.getElementById('filter-status')?.value || 'all';
        const regionFilter = document.getElementById('filter-region')?.value || 'all';
        
        let filteredOrders = this.orders.filter(o => o.status === 'new' || o.status === 'planned');
        
        // Фильтр по статусу
        if (statusFilter !== 'all') {
            filteredOrders = filteredOrders.filter(o => o.status === statusFilter);
        }
        
        // Фильтр по региону (пример)
        if (regionFilter !== 'all') {
            filteredOrders = filteredOrders.filter(o => {
                if (!o.deliveryAddress) return false;
                const regionMap = {
                    'center': ['Москва', 'Тверь', 'Ярославль'],
                    'northwest': ['Санкт-Петербург', 'Псков', 'Новгород'],
                    'south': ['Краснодар', 'Сочи', 'Ростов'],
                    'siberia': ['Новосибирск', 'Омск', 'Красноярск'],
                    'far-east': ['Владивосток', 'Хабаровск', 'Якутск']
                };
                const regionKeywords = regionMap[regionFilter] || [];
                return regionKeywords.some(keyword => o.deliveryAddress.includes(keyword));
            });
        }
        
        if (filteredOrders.length === 0) {
            container.innerHTML = `
                <div style="padding: 40px; text-align: center; color: #64748b;">
                    Нет заявок с выбранными фильтрами
                </div>
            `;
            return;
        }
        
        container.innerHTML = `
            <div class="table-wrapper">
                <table class="orders-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Статус</th>
                            <th>Клиент</th>
                            <th>Адрес отправителя</th>
                            <th>Адрес получателя</th>
                            <th>Груз</th>
                            <th>Температура</th>
                            <th>Вес / Объем</th>
                            <th>Дата</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${filteredOrders.map(order => this.renderOrderRow(order)).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }

    renderOrderRow(order) {
        const hasCoords = order.pickupCoords && order.deliveryCoords;
        const isExpress = order.orderType === 'express';
        
        return `
            <tr data-order-id="${order.id}" class="${isExpress ? 'express-row' : ''}">
                <td><strong>#${order.id}</strong></td>
                <td>
                    <span class="status-badge status-${order.status}">
                        ${this.getStatusText(order.status)}
                    </span>
                </td>
                <td>${this.escapeHtml(order.client)}</td>
                <td title="${this.escapeHtml(order.pickupAddress || '')}">
                    ${this.truncate(order.pickupAddress, 40)}
                </td>
                <td title="${this.escapeHtml(order.deliveryAddress || '')}">
                    ${this.truncate(order.deliveryAddress, 40)}
                </td>
                <td>${this.escapeHtml(order.cargoType || '-')}</td>
                <td>${order.temperature ? order.temperature + '°C' : '-'}</td>
                <td>${order.weight || '-'} кг / ${order.volume || '-'} м³</td>
                <td>${this.formatDate(order.orderDate)}</td>
                <td>
                    <div class="row-actions">
                        ${hasCoords ? `
                            <button class="btn-icon" onclick="logistic.viewOnMap(${order.id})" title="Показать на карте">
                                🗺️
                            </button>
                            <button class="btn-icon btn-primary" onclick="logistic.addOrderToRoute(${order.id})" title="Добавить в маршрут">
                                ➕
                            </button>
                        ` : ''}
                        <button class="btn-icon btn-warning" onclick="logistic.editOrder(${order.id})" title="Редактировать">
                            ✏️
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }

    getStatusText(status) {
        const texts = {
            'new': 'Новая',
            'planned': 'Планированная',
            'in_transit': 'В пути',
            'delivered': 'Доставлена'
        };
        return texts[status] || status;
    }

    truncate(text, maxLength) {
        if (!text) return '-';
        if (text.length <= maxLength) return text;
        return text.substring(0, maxLength) + '...';
    }

    formatDate(dateString) {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleDateString('ru-RU', {
            day: '2-digit',
            month: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // ==================== СПИСОК ТРАНСПОРТА ====================
    
    renderVehiclesList() {
        const container = document.getElementById('vehicles-list');
        if (!container) return;
        
        const available = this.vehicles.filter(v => v.status === 'available');
        
        container.innerHTML = available.map(vehicle => {
            const isAircraft = vehicle.transport === 'fly';
            return `
                <div class="vehicle-card ${isAircraft ? 'aircraft' : ''}" data-vehicle-id="${vehicle.id}">
                    <div class="vehicle-header">
                        <strong>${isAircraft ? '✈️' : '🚛'} ${vehicle.plate}</strong>
                        ${isAircraft ? '<span class="aircraft-badge">АВИА</span>' : ''}
                    </div>
                    <div class="vehicle-info">
                        <div>${vehicle.type}</div>
                        <div>Водитель: ${vehicle.driver}</div>
                        <div>Грузоподъемность: ${vehicle.capacity} кг</div>
                    </div>
                </div>
            `;
        }).join('');
    }

    // ==================== КОНСТРУКТОР МАРШРУТОВ ====================
    
    openRouteBuilder() {
        this.currentRoute = {
            id: Date.now(),
            name: '',
            region: '',
            legs: [],
            thermalBoxes: [],
            returnRoute: null,
            sourceOrder: null
        };
        
        const modal = document.getElementById('route-builder-modal');
        if (modal) {
            modal.classList.add('active');
            this.renderRouteBuilder();
            
            // Инициализируем карту конструктора
            setTimeout(() => {
                this.initBuilderMap();
            }, 100);
        }
    }

    initBuilderMap() {
        const container = document.getElementById('builder-map');
        if (!container) return;
        
        // Уничтожаем старую карту если есть
        if (this.builderMap) {
            this.builderMap.remove();
        }
        
        try {
            this.builderMap = L.map('builder-map', {
                center: [55.7558, 37.6173],
                zoom: 8
            });
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            }).addTo(this.builderMap);
            
            console.log('[LOGISTIC] Карта конструктора инициализирована');
        } catch (error) {
            console.error('[LOGISTIC] Ошибка карты конструктора:', error);
        }
    }

    renderRouteBuilder() {
        const nameInput = document.getElementById('route-name');
        const regionInput = document.getElementById('route-region');
        
        if (nameInput) nameInput.value = this.currentRoute.name || '';
        if (regionInput) regionInput.value = this.currentRoute.region || '';
        
        this.renderLegsList();
        this.renderTemplatesList();
        this.calculateRouteSummary();
        
        // Обновляем карту если есть
        if (this.builderMap) {
            this.updateBuilderMap();
        }
    }

    async updateBuilderMap() {
        if (!this.builderMap || this.currentRoute.legs.length === 0) return;
        
        // Очищаем маркеры и линии
        this.builderMap.eachLayer(layer => {
            if (layer instanceof L.Marker || layer instanceof L.Polyline) {
                this.builderMap.removeLayer(layer);
            }
        });
        
        const coords = [];
        
        // Проходим по всем этапам с координатами
        for (const leg of this.currentRoute.legs) {
            if (leg.coords && leg.coords.lat && leg.coords.lng) {
                coords.push([leg.coords.lat, leg.coords.lng]);
                
                // Добавляем маркер
                L.marker([leg.coords.lat, leg.coords.lng])
                    .addTo(this.builderMap)
                    .bindPopup(`<b>${leg.name || leg.type}</b>`);
            }
        }
        
        // Если есть координаты - строим маршрут через OSRM
        if (coords.length >= 2) {
            try {
                // Преобразуем для OSRM: [lng,lat] для каждого
                const osrmCoords = coords.map(c => [c[1], c[0]]);
                
                // Получаем маршрут через OSRM
                const route = await OSRM.getRoute(osrmCoords, 'driving');
                
                if (route.success && route.geometry) {
                    // Преобразуем обратно в [lat,lng]
                    const routeCoords = OSRM.geojsonToLatLngs(route.geometry);
                    
                    // Рисуем маршрут
                    L.polyline(routeCoords, {
                        color: '#667eea',
                        weight: 5,
                        opacity: 0.7
                    }).addTo(this.builderMap);
                    
                    console.log('[LOGISTIC] Маршрут построен:', route.distance / 1000, 'км');
                }
            } catch (error) {
                console.error('[LOGISTIC] Ошибка построения маршрута:', error);
                // Fallback: рисуем прямые линии
                L.polyline(coords, { color: '#667eea', weight: 3 }).addTo(this.builderMap);
            }
        }
        
        // Центрируем карту
        if (coords.length > 0) {
            const group = L.featureGroup(coords.map(c => L.marker(c)));
            this.builderMap.fitBounds(group.getBounds().pad(0.1));
        }
    }

    closeRouteBuilder() {
        document.getElementById('route-builder-modal')?.classList.remove('active');
    }

    renderLegsList() {
        const container = document.getElementById('route-legs-list');
        if (!container) return;
        
        if (this.currentRoute.legs.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <p>📭 Добавьте этапы маршрута</p>
                    <div class="add-leg-buttons">
                        <button class="btn btn-small" onclick="logistic.addLeg('mile1')">📦 1 миля (Забор)</button>
                        <button class="btn btn-small" onclick="logistic.addLeg('mile2')">🚚 2 миля (Магистраль)</button>
                        <button class="btn btn-small" onclick="logistic.addLeg('mile3')">🏠 3 миля (Доставка)</button>
                        <button class="btn btn-small btn-warning" onclick="logistic.addLeg('pickup')">📥 Загрузка (склад)</button>
                        <button class="btn btn-small btn-warning" onclick="logistic.addLeg('delivery')">📤 Выгрузка (склад)</button>
                    </div>
                </div>
            `;
            return;
        }
        
        container.innerHTML = this.currentRoute.legs.map((leg, index) => `
            <div class="leg-card ${leg.type}">
                <div class="leg-header">
                    <span class="leg-type-badge ${leg.type}">
                        ${this.getLegTypeIcon(leg.type)} ${this.getLegTypeName(leg.type)}
                    </span>
                    <button class="btn-remove-leg" onclick="logistic.removeLeg(${index})">&times;</button>
                </div>
                
                <div class="leg-body">
                    <div class="leg-row">
                        <label>Название этапа:</label>
                        <input type="text" value="${leg.name || ''}" 
                               placeholder="Например: Забор груза в Москве"
                               onchange="logistic.updateLeg(${index}, 'name', this.value)">
                    </div>
                    
                    <div class="leg-row">
                        <label>Тип транспорта:</label>
                        <select onchange="logistic.updateLeg(${index}, 'transport', this.value)">
                            <option value="auto" ${leg.transport === 'auto' ? 'selected' : ''}>🚛 Авто</option>
                            <option value="fly" ${leg.transport === 'fly' ? 'selected' : ''}>✈️ Авиа</option>
                        </select>
                    </div>
                    
                    ${leg.addressType ? `
                    <div class="leg-row">
                        <label>Адрес (из заявки):</label>
                        <input type="text" value="${this.escapeHtml(leg.address)}" 
                               readonly 
                               style="background: #f8f9fa; cursor: default;"
                               title="Адрес автоматически взят из заявки #${leg.orderRef}">
                        <small style="color: #10b981;">✅ ${leg.addressType === 'pickup' ? 'Забор у отправителя' : 'Доставка получателю'}</small>
                    </div>
                    ` : ''}
                    
                    <div class="leg-row">
                        <label>Агент/Перевозчик:</label>
                        <select onchange="logistic.updateLeg(${index}, 'agent', this.value)">
                            <option value="">-- Выберите агента --</option>
                            ${this.getAgentsOptions(leg.agent)}
                        </select>
                    </div>
                    
                    <div class="leg-row">
                        <label>Водитель:</label>
                        <select onchange="logistic.updateLeg(${index}, 'driver', this.value)">
                            <option value="">-- Выберите водителя --</option>
                            ${this.getDriversOptions(leg.driver)}
                        </select>
                    </div>
                    
                    <div class="leg-row">
                        <label>Транспорт:</label>
                        <select onchange="logistic.updateLeg(${index}, 'vehicle', this.value)">
                            <option value="">-- Выберите ТС --</option>
                            ${this.getVehiclesOptions(leg.vehicle)}
                        </select>
                    </div>
                    
                    <div class="leg-row">
                        <label>Время:</label>
                        <input type="time" value="${leg.time || ''}" 
                               onchange="logistic.updateLeg(${index}, 'time', this.value)">
                    </div>
                </div>
            </div>
        `).join('');
    }

    getLegTypeIcon(type) {
        const icons = {
            mile1: '📦',
            mile2: '🚚',
            mile3: '🏠',
            return: '🔄'
        };
        return icons[type] || '📍';
    }

    getLegTypeName(type) {
        const names = {
            mile1: '1 миля - Забор груза',
            mile2: '2 миля - Магистраль',
            mile3: '3 миля - Доставка',
            return: 'Возврат боксов'
        };
        return names[type] || type;
    }

    getAgentsOptions(selectedAgent) {
        const agents = [
            { id: 1, name: 'ООО "ТрансЛогик"' },
            { id: 2, name: 'ИП Иванов А.В.' },
            { id: 3, name: 'ПАО "АвиаТранс"' },
            { id: 4, name: 'Самовывоз' }
        ];
        
        return agents.map(agent => 
            `<option value="${agent.name}" ${agent.name === selectedAgent ? 'selected' : ''}>
                ${agent.name}
            </option>`
        ).join('');
    }

    getDriversOptions(selectedDriver) {
        // Получаем водителей из localStorage или создаём тестовые
        let drivers = JSON.parse(localStorage.getItem('drivers') || '[]');
        
        if (drivers.length === 0) {
            drivers = [
                { id: 1, name: 'Петров С.И.', phone: '+7 (916) 123-45-67' },
                { id: 2, name: 'Сидоров А.А.', phone: '+7 (916) 234-56-78' },
                { id: 3, name: 'Козлов Д.В.', phone: '+7 (916) 345-67-89' },
                { id: 4, name: 'Новиков П.С.', phone: '+7 (916) 456-78-90' }
            ];
            localStorage.setItem('drivers', JSON.stringify(drivers));
        }
        
        return drivers.map(driver => 
            `<option value="${driver.name}" ${driver.name === selectedDriver ? 'selected' : ''}>
                👤 ${driver.name} ${driver.phone ? `(${driver.phone})` : ''}
            </option>`
        ).join('');
    }

    getVehiclesOptions(selectedVehicle) {
        // Получаем транспорт из API или localStorage
        const vehicles = this.vehicles || [];
        
        if (vehicles.length === 0) {
            return '<option value="">Нет доступного транспорта</option>';
        }
        
        return vehicles.map(vehicle => 
            `<option value="${vehicle.plate}" ${vehicle.plate === selectedVehicle ? 'selected' : ''}>
                ${vehicle.plate} - ${vehicle.type} ${vehicle.driver ? `(${vehicle.driver})` : ''}
            </option>`
        ).join('');
    }

    getOrdersForLegOptions(selectedAddress) {
        const ordersWithCoords = this.orders.filter(o => 
            (o.status === 'new' || o.status === 'planned') &&
            o.pickupCoords && o.deliveryCoords
        );
        
        return ordersWithCoords.map(order => {
            const pickupText = `Забор: ${order.pickupAddress.substring(0, 30)}`;
            const deliveryText = `Доставка: ${order.deliveryAddress.substring(0, 30)}`;
            
            return `
                <optgroup label="Заявка #${order.id}">
                    <option value="pickup:${order.id}" ${selectedAddress === `pickup:${order.id}` ? 'selected' : ''}>
                        📦 ${pickupText}
                    </option>
                    <option value="delivery:${order.id}" ${selectedAddress === `delivery:${order.id}` ? 'selected' : ''}>
                        🏠 ${deliveryText}
                    </option>
                </optgroup>
            `;
        }).join('');
    }

    addLeg(type) {
        const order = this.currentRoute.sourceOrder;
        
        let newLeg = {
            type: type,
            name: '',
            transport: 'auto',
            address: '',
            coords: null,
            orderRef: order ? order.id : null,
            addressType: '',
            agent: '',
            vehicle: '',
            driver: '',
            time: ''
        };
        
        // Автоматически заполняем адреса из заявки
        if (order && order.pickupCoords && order.deliveryCoords) {
            if (type === 'mile1' || type === 'pickup') {
                // Забор у отправителя или загрузка на складе
                newLeg.name = type === 'mile1' ? `Забор груза: ${this.truncate(order.pickupAddress, 30)}` : 'Загрузка на складе';
                newLeg.address = type === 'mile1' ? order.pickupAddress : '';
                newLeg.coords = type === 'mile1' ? order.pickupCoords : null;
                newLeg.addressType = 'pickup';
            } else if (type === 'mile3' || type === 'delivery') {
                // Доставка получателю или выгрузка на складе
                newLeg.name = type === 'mile3' ? `Доставка: ${this.truncate(order.deliveryAddress, 30)}` : 'Выгрузка на складе';
                newLeg.address = type === 'mile3' ? order.deliveryAddress : '';
                newLeg.coords = type === 'mile3' ? order.deliveryCoords : null;
                newLeg.addressType = 'delivery';
            } else if (type === 'mile2') {
                // 2 миля - магистраль, адрес не нужен
                newLeg.name = 'Магистральная перевозка';
            } else if (type === 'return') {
                newLeg.name = 'Возврат боксов';
            }
        }
        
        this.currentRoute.legs.push(newLeg);
        this.renderLegsList();
        this.calculateRouteSummary();
    }

    removeLeg(index) {
        this.currentRoute.legs.splice(index, 1);
        this.renderLegsList();
        this.calculateRouteSummary();
    }

    updateLeg(index, field, value) {
        this.currentRoute.legs[index][field] = value;
    }

    setLegAddress(legIndex, value) {
        if (!value) return;
        
        const [addressType, orderId] = value.split(':');
        const order = this.orders.find(o => o.id == orderId);
        
        if (!order) return;
        
        const address = addressType === 'pickup' ? order.pickupAddress : order.deliveryAddress;
        const coords = addressType === 'pickup' ? order.pickupCoords : order.deliveryCoords;
        
        this.currentRoute.legs[legIndex].address = address;
        this.currentRoute.legs[legIndex].coords = coords;
        this.currentRoute.legs[legIndex].orderRef = orderId;
        this.currentRoute.legs[legIndex].addressType = addressType;
        
        this.renderLegsList();
        this.showNotification(`Адрес выбран: ${address}`);
    }

    renderTemplatesList() {
        const container = document.getElementById('route-templates-list');
        if (!container) return;
        
        container.innerHTML = this.routeTemplates.map(template => `
            <div class="template-card">
                <div class="template-info">
                    <strong>${template.name}</strong>
                    <small>${template.region}</small>
                </div>
                <button class="btn btn-small" onclick="logistic.applyTemplate(${template.id})">
                    Использовать
                </button>
            </div>
        `).join('');
    }

    applyTemplate(templateId) {
        const template = this.routeTemplates.find(t => t.id === templateId);
        if (!template) return;
        
        this.currentRoute.legs = template.legs.map(leg => ({
            ...leg,
            address: '',
            coords: null,
            time: ''
        }));
        
        this.renderLegsList();
        this.showNotification(`Шаблон "${template.name}" применен`);
    }

    // ==================== СОХРАНЕНИЕ МАРШРУТА ====================
    
    saveCurrentRoute() {
        if (this.currentRoute.legs.length === 0) {
            this.showNotification('Добавьте этапы маршрута!', 'error');
            return;
        }
        
        const nameInput = document.getElementById('route-name');
        const regionInput = document.getElementById('route-region');
        
        if (!nameInput || !regionInput) {
            this.showNotification('Ошибка интерфейса', 'error');
            return;
        }
        
        const name = nameInput.value || `Маршрут ${this.savedRoutes.length + 1}`;
        const region = regionInput.value || 'Не указан';
        
        // Глубокое копирование для сохранения
        const routeToSave = {
            id: Date.now(),
            name: name,
            region: region,
            legs: JSON.parse(JSON.stringify(this.currentRoute.legs)),
            thermalBoxes: this.currentRoute.thermalBoxes,
            returnRoute: this.currentRoute.returnRoute,
            createdAt: new Date().toISOString()
        };
        
        this.savedRoutes.push(routeToSave);
        
        try {
            this.saveRoutesToStorage();
            this.renderSavedRoutesList();
            this.showNotification(`✅ Маршрут "${name}" сохранен!`, 'success');
            
            // Показываем что делать дальше
            setTimeout(() => {
                this.showRouteAppliedNotification(routeToSave);
            }, 1000);
            
            this.closeRouteBuilder();
        } catch (error) {
            console.error('[LOGISTIC] Ошибка сохранения:', error);
            this.showNotification('❌ Ошибка при сохранении', 'error');
        }
    }

    showRouteAppliedNotification(route) {
        // Создаём уведомление с кнопками действий
        const notification = document.createElement('div');
        notification.className = 'notification notification-with-actions';
        notification.innerHTML = `
            <div class="notification-content">
                <strong>✅ Маршрут "${this.escapeHtml(route.name)}" сохранён!</strong>
                <p>Что делать дальше:</p>
                <div class="notification-actions">
                    <button class="btn btn-small btn-primary" onclick="logistic.applyRouteToOrders(${route.id})">
                        📋 Применить к заявкам
                    </button>
                    <button class="btn btn-small" onclick="logistic.viewSavedRoutes()">
                        📂 Смотреть все маршруты
                    </button>
                    <button class="btn btn-small" onclick="this.parentElement.parentElement.remove()">
                        Закрыть
                    </button>
                </div>
            </div>
        `;
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.add('active'), 10);
    }

    applyRouteToOrders(routeId) {
        const route = this.savedRoutes.find(r => r.id === routeId);
        if (!route) {
            this.showNotification('Маршрут не найден', 'error');
            return;
        }
        
        // Применяем маршрут ко всем новым заявкам
        const newOrders = this.orders.filter(o => o.status === 'new');
        
        if (newOrders.length === 0) {
            this.showNotification('Нет новых заявок для применения маршрута', 'warning');
            return;
        }
        
        // Обновляем заявки - помечаем как planned и привязываем маршрут
        let appliedCount = 0;
        newOrders.forEach(order => {
            const orderIndex = this.orders.findIndex(o => o.id === order.id);
            if (orderIndex !== -1) {
                this.orders[orderIndex].status = 'planned';
                this.orders[orderIndex].assignedRoute = route.id;
                this.orders[orderIndex].routeName = route.name;
                appliedCount++;
            }
        });
        
        // Сохраняем изменения
        this.saveOrdersToStorage();
        this.renderOrdersTable();
        
        this.showNotification(`✅ Маршрут "${route.name}" применён к ${appliedCount} заявкам!`, 'success');
    }

    saveOrdersToStorage() {
        localStorage.setItem('orders', JSON.stringify(this.orders));
    }

    viewSavedRoutes() {
        // Прокрутка к списку сохранённых маршрутов
        const routesList = document.getElementById('saved-routes-list');
        if (routesList) {
            routesList.scrollIntoView({ behavior: 'smooth' });
        }
    }

    renderSavedRoutesList() {
        const container = document.getElementById('saved-routes-list');
        if (!container) return;
        
        if (this.savedRoutes.length === 0) {
            container.innerHTML = '<p style="padding: 20px; text-align: center; color: #64748b;">Нет сохраненных маршрутов</p>';
            return;
        }
        
        container.innerHTML = this.savedRoutes.map(route => {
            const legsCount = route.legs?.length || 0;
            const boxesCount = route.thermalBoxes?.length || 0;
            
            return `
            <div class="saved-route-item">
                <div class="saved-route-info">
                    <div class="saved-route-name">📦 ${route.name || 'Без названия'}</div>
                    <div class="saved-route-region">${route.region || 'Регион не указан'}</div>
                    <div class="saved-route-stats">
                        <span>🛣️ ${legsCount} этапа</span>
                        <span>🌡️ ${boxesCount} боксов</span>
                    </div>
                </div>
                <div class="saved-route-actions">
                    <button class="btn-small" onclick="logistic.loadRoute(${route.id})">📂 Открыть</button>
                    <button class="btn-small btn-success" onclick="logistic.applyRouteToOrders(${route.id})">📋 Применить</button>
                    <button class="btn-small btn-danger" onclick="logistic.deleteRoute(${route.id})">&times;</button>
                </div>
            </div>
            `;
        }).join('');
    }

    loadRoute(routeId) {
        const route = this.savedRoutes.find(r => r.id === routeId);
        if (!route) {
            console.error('[LOGISTIC] Маршрут не найден:', routeId);
            this.showNotification('Маршрут не найден', 'error');
            return;
        }
        
        console.log('[LOGISTIC] Загрузка маршрута:', route);
        
        // Создаём копию маршрута с правильным форматом
        this.currentRoute = {
            id: route.id,
            name: route.name || '',
            region: route.region || '',
            legs: route.legs ? JSON.parse(JSON.stringify(route.legs)) : [],
            thermalBoxes: route.thermalBoxes || [],
            returnRoute: route.returnRoute || null,
            sourceOrder: route.sourceOrder || null,
            createdAt: route.createdAt
        };
        
        console.log('[LOGISTIC] Этапы маршрута:', this.currentRoute.legs.length);
        
        this.openRouteBuilder();
        this.renderLegsList();
        this.showNotification(`✅ Маршрут "${route.name}" загружен`);
    }

    deleteRoute(routeId) {
        if (!confirm('Удалить маршрут?')) return;
        
        this.savedRoutes = this.savedRoutes.filter(r => r.id !== routeId);
        this.saveRoutesToStorage();
        this.renderSavedRoutesList();
        this.showNotification('Маршрут удален');
    }

    calculateRouteSummary() {
        const summaryEl = document.getElementById('route-summary');
        if (!summaryEl) return;
        
        summaryEl.innerHTML = `
            <div class="route-summary-grid">
                <div class="summary-item">
                    <span class="summary-label">Этапов</span>
                    <span class="summary-value">${this.currentRoute.legs.length}</span>
                </div>
            </div>
        `;
    }

    // ==================== ДРУГИЕ МЕТОДЫ ====================
    
    addOrderToRoute(orderId) {
        const order = this.orders.find(o => o.id == orderId);
        if (!order) {
            this.showNotification('Заявка не найдена', 'error');
            return;
        }
        
        // Проверяем координаты
        if (!order.pickupCoords || !order.deliveryCoords) {
            this.showNotification('У заявки нет координат. Создайте заявку через Менеджер с полными адресами.', 'error');
            console.error('[LOGISTIC] Заявка #', orderId, 'coords:', order.pickupCoords, order.deliveryCoords);
            return;
        }
        
        // Очищаем текущий маршрут и создаём новый ТОЛЬКО из этой заявки
        this.currentRoute = {
            id: Date.now(),
            name: `Маршрут #${order.id}`,
            region: this.detectRegion(order.deliveryAddress),
            legs: [],
            thermalBoxes: [],
            returnRoute: null,
            sourceOrder: order // Сохраняем ссылку на исходную заявку
        };
        
        // Автоматически создаём ВСЕ этапы с адресами из заявки
        const isExpress = order.orderType === 'express';
        
        this.currentRoute.legs = [
            { 
                type: 'mile1', 
                name: `Забор груза: ${this.truncate(order.pickupAddress, 30)}`, 
                transport: 'auto', 
                address: order.pickupAddress,
                coords: order.pickupCoords,
                orderRef: orderId,
                addressType: 'pickup',
                agent: '',
                time: ''
            },
            { 
                type: 'mile2', 
                name: 'Магистральная перевозка', 
                transport: isExpress ? 'fly' : 'auto',
                address: '',
                coords: null,
                orderRef: orderId,
                addressType: '',
                agent: '',
                time: ''
            },
            { 
                type: 'mile3', 
                name: `Доставка: ${this.truncate(order.deliveryAddress, 30)}`, 
                transport: 'auto', 
                address: order.deliveryAddress,
                coords: order.deliveryCoords,
                orderRef: orderId,
                addressType: 'delivery',
                agent: '',
                time: ''
            }
        ];
        
        this.openRouteBuilder();
        this.renderLegsList();
        this.showNotification(`✅ Маршрут создан на основе заявки #${order.id}`);
        
        // Центрируем карту на маршруте
        this.focusMapOnOrder(orderId);
    }

    detectRegion(address) {
        if (!address) return 'Не указан';
        
        const regionMap = {
            'center': ['Москва', 'Тверь', 'Ярославль', 'Владимир', 'Рязань'],
            'northwest': ['Санкт-Петербург', 'Псков', 'Новгород', 'Архангельск'],
            'south': ['Краснодар', 'Сочи', 'Ростов', 'Волгоград'],
            'siberia': ['Новосибирск', 'Омск', 'Красноярск', 'Иркутск'],
            'far-east': ['Владивосток', 'Хабаровск', 'Якутск', 'Комсомольск']
        };
        
        for (const [region, keywords] of Object.entries(regionMap)) {
            if (keywords.some(k => address.includes(k))) {
                return region.charAt(0).toUpperCase() + region.slice(1);
            }
        }
        
        return 'Другой регион';
    }

    focusMapOnOrder(orderId) {
        const order = this.orders.find(o => o.id == orderId);
        if (!order || !this.map) return;
        
        // Убираем все старые маркеры
        this.markers.forEach(m => this.map.removeLayer(m));
        this.markers = [];
        
        // Добавляем маркеры ТОЛЬКО для этой заявки
        const pickupMarker = L.marker([order.pickupCoords.lat, order.pickupCoords.lng])
            .addTo(this.map)
            .bindPopup(`<b>📦 Забор - Заявка #${order.id}</b><br>${this.escapeHtml(order.pickupAddress)}`);
        
        const deliveryMarker = L.marker([order.deliveryCoords.lat, order.deliveryCoords.lng])
            .addTo(this.map)
            .bindPopup(`<b>🏠 Доставка - Заявка #${order.id}</b><br>${this.escapeHtml(order.deliveryAddress)}`);
        
        this.markers.push(pickupMarker, deliveryMarker);
        
        // Рисуем линию маршрута
        const routeLine = L.polyline([
            [order.pickupCoords.lat, order.pickupCoords.lng],
            [order.deliveryCoords.lat, order.deliveryCoords.lng]
        ], {
            color: '#667eea',
            weight: 4,
            opacity: 0.7
        }).addTo(this.map);
        
        this.markers.push(routeLine);
        
        // Центрируем карту
        const group = L.featureGroup([pickupMarker, deliveryMarker]);
        this.map.fitBounds(group.getBounds().pad(0.2));
        
        this.showNotification('🗺️ Маршрут показан на карте');
    }

    viewOnMap(orderId) {
        if (!this.map) {
            this.showNotification('Карта не загружена', 'error');
            return;
        }
        
        const order = this.orders.find(o => o.id == orderId);
        if (!order) return;
        
        // Проверяем координаты
        if (!order.pickupCoords || !order.deliveryCoords) {
            this.showNotification('У заявки нет координат', 'error');
            return;
        }
        
        this.focusMapOnOrder(orderId);
    }

    editOrder(orderId) {
        if (window.manager && typeof window.manager.editOrder === 'function') {
            window.manager.editOrder(orderId);
        } else {
            this.showNotification('Модуль менеджера не найден', 'error');
        }
    }

    // ==================== КАЛЕНДАРЬ И КАРТА ====================
    
    getWeekStart(date) {
        const d = new Date(date);
        const day = d.getDay();
        const diff = d.getDate() - day + (day === 0 ? -6 : 1);
        return new Date(d.setDate(diff));
    }

    prevWeek() {
        this.currentWeekStart = this.getWeekStart(new Date(this.currentWeekStart));
        this.currentWeekStart.setDate(this.currentWeekStart.getDate() - 7);
        this.updateWeekDisplay();
    }

    nextWeek() {
        this.currentWeekStart = this.getWeekStart(new Date(this.currentWeekStart));
        this.currentWeekStart.setDate(this.currentWeekStart.getDate() + 7);
        this.updateWeekDisplay();
    }

    updateWeekDisplay() {
        const end = new Date(this.currentWeekStart);
        end.setDate(end.getDate() + 6);
        
        const options = { day: '2-digit', month: '2-digit' };
        const weekEl = document.getElementById('current-week');
        if (weekEl) {
            weekEl.textContent = 
                `${this.currentWeekStart.toLocaleDateString('ru-RU', options)} - ${end.toLocaleDateString('ru-RU', options)}`;
        }
    }

    updateCalendar() {
        // TODO: реализация календаря
    }

    initMapOnShow() {
        try {
            const mapContainer = document.getElementById('logistics-map');
            if (!mapContainer) return;
            
            if (this.map) {
                setTimeout(() => {
                    this.map.invalidateSize();
                    this.updateMap();
                }, 100);
                return;
            }
            
            this.map = L.map('logistics-map', {
                center: [55.7558, 37.6173],
                zoom: 8
            });
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            }).addTo(this.map);

            setTimeout(() => {
                if (this.map) {
                    this.map.invalidateSize();
                    this.updateMap();
                }
            }, 300);
            
        } catch (error) {
            console.error('[LOGISTIC] Ошибка карты:', error);
        }
    }

    updateMap() {
        if (!this.map) return;
        
        // Очищаем все маркеры
        this.markers.forEach(m => this.map.removeLayer(m));
        this.markers = [];
        
        const ordersToShow = this.orders.filter(o => o.status === 'new' || o.status === 'planned');
        
        ordersToShow.forEach(order => {
            // Проверяем координаты забора
            if (order.pickupCoords && 
                typeof order.pickupCoords.lat === 'number' && 
                typeof order.pickupCoords.lng === 'number') {
                
                const marker = L.marker([order.pickupCoords.lat, order.pickupCoords.lng])
                    .addTo(this.map)
                    .bindPopup(`
                        <strong>📦 Забор - Заявка #${order.id}</strong><br>
                        ${this.escapeHtml(order.client)}<br>
                        ${this.escapeHtml(order.pickupAddress)}
                    `);
                this.markers.push(marker);
            }
            
            // Проверяем координаты доставки
            if (order.deliveryCoords && 
                typeof order.deliveryCoords.lat === 'number' && 
                typeof order.deliveryCoords.lng === 'number') {
                
                const marker = L.marker([order.deliveryCoords.lat, order.deliveryCoords.lng])
                    .addTo(this.map)
                    .bindPopup(`
                        <strong>🏠 Доставка - Заявка #${order.id}</strong><br>
                        ${this.escapeHtml(order.deliveryAddress)}
                    `);
                this.markers.push(marker);
            }
        });
        
        console.log('[LOGISTIC] Маркеров на карте:', this.markers.length);
        
        // Центрируем карту по всем маркерам
        if (this.markers.length > 0) {
            const group = L.featureGroup(this.markers);
            this.map.fitBounds(group.getBounds().pad(0.1));
        } else {
            // Если маркеров нет - центрируем на Москве
            this.map.setView([55.7558, 37.6173], 8);
        }
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = 'notification' + (type === 'error' ? ' error' : '');
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.add('active'), 10);
        setTimeout(() => {
            notification.classList.remove('active');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}

// Инициализация
let logistic;
document.addEventListener('DOMContentLoaded', () => {
    logistic = new LogisticModule();
    window.logistic = logistic;
});
