// Модуль логиста - Планирование маршрутов с термобоксами
class LogisticModule {
    constructor() {
        this.currentWeekStart = this.getWeekStart(new Date());
        this.orders = [];
        this.vehicles = [];
        this.map = null;
        this.markers = [];
        this.routeLayer = null;
        
        // Маршруты с термобоксами
        this.currentRoute = {
            id: null,
            name: '',
            region: '',
            legs: [], // Этапы маршрута
            thermalBoxes: [], // Термобоксы
            returnRoute: null // Маршрут возврата
        };
        
        this.savedRoutes = [];
        this.routeTemplates = []; // Шаблоны для регионов
        
        this.init();
    }

    init() {
        this.loadData();
        this.loadSavedRoutes();
        this.loadRouteTemplates();
        this.setupMap();
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Кнопки управления маршрутами
        document.getElementById('btn-new-route')?.addEventListener('click', () => this.openRouteBuilder());
        document.getElementById('btn-save-route')?.addEventListener('click', () => this.saveCurrentRoute());
        document.getElementById('btn-clear-route')?.addEventListener('click', () => this.clearRoute());
        document.getElementById('btn-add-leg')?.addEventListener('click', () => this.addLeg());
        document.getElementById('btn-calculate-boxes')?.addEventListener('click', () => this.calculateBoxes());
        document.getElementById('btn-return-route')?.addEventListener('click', () => this.buildReturnRoute());
        
        // Недели
        document.getElementById('prev-week')?.addEventListener('click', () => this.prevWeek());
        document.getElementById('next-week')?.addEventListener('click', () => this.nextWeek());
    }

    // ==================== ЗАГРУЗКА ДАННЫХ ====================
    
    async loadData() {
        try {
            const [orders, vehicles] = await Promise.all([
                api.getOrders(),
                api.getVehicles()
            ]);
            
            this.orders = orders;
            this.vehicles = vehicles;
            
            this.renderOrders();
            this.renderVehicles();
            this.updateCalendar();
            this.updateMap();
        } catch (error) {
            console.error('Ошибка загрузки данных:', error);
        }
    }

    loadSavedRoutes() {
        const saved = localStorage.getItem('tms_routes_v2');
        if (saved) {
            this.savedRoutes = JSON.parse(saved);
            this.renderSavedRoutes();
        }
    }

    saveRoutesToStorage() {
        localStorage.setItem('tms_routes_v2', JSON.stringify(this.savedRoutes));
    }

    loadRouteTemplates() {
        const templates = localStorage.getItem('tms_route_templates');
        if (templates) {
            this.routeTemplates = JSON.parse(templates);
            this.renderTemplates();
        } else {
            // Шаблоны по умолчанию
            this.routeTemplates = [
                {
                    id: 1,
                    name: 'Москва - Санкт-Петербург',
                    region: 'Центр - Северо-Запад',
                    legs: [
                        { type: 'mile1', name: 'Забор груза (Москва)', transport: 'auto' },
                        { type: 'mile2', name: 'Магистраль (авто)', transport: 'auto' },
                        { type: 'mile3', name: 'Доставка (СПб)', transport: 'auto' },
                        { type: 'return', name: 'Возврат боксов', transport: 'auto' }
                    ]
                },
                {
                    id: 2,
                    name: 'Москва - Владивосток (Авиа)',
                    region: 'Центр - Дальний Восток',
                    legs: [
                        { type: 'mile1', name: 'Забор груза (Москва)', transport: 'auto' },
                        { type: 'mile2', name: 'Магистраль (авиа)', transport: 'fly' },
                        { type: 'mile3', name: 'Доставка (Владивосток)', transport: 'auto' },
                        { type: 'return', name: 'Возврат боксов (авто)', transport: 'auto' }
                    ]
                }
            ];
            this.saveTemplates();
            this.renderTemplates();
        }
    }

    saveTemplates() {
        localStorage.setItem('tms_route_templates', JSON.stringify(this.routeTemplates));
    }

    // ==================== КОНСТРУКТОР МАРШРУТОВ ====================
    
    openRouteBuilder() {
        this.currentRoute = {
            id: Date.now(),
            name: '',
            region: '',
            legs: [],
            thermalBoxes: [],
            returnRoute: null
        };
        
        const modal = document.getElementById('route-builder-modal');
        if (modal) {
            modal.classList.add('active');
            this.renderRouteBuilder();
        }
    }

    closeRouteBuilder() {
        document.getElementById('route-builder-modal')?.classList.remove('active');
    }

    renderRouteBuilder() {
        // Регион
        document.getElementById('route-region').value = this.currentRoute.region;
        document.getElementById('route-name').value = this.currentRoute.name;
        
        // Этапы маршрута
        this.renderLegsList();
        
        // Термобоксы
        this.renderBoxesList();
        
        // Итого
        this.calculateRouteSummary();
    }

    renderLegsList() {
        const container = document.getElementById('route-legs-list');
        if (!container) return;
        
        if (this.currentRoute.legs.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <p>📭 Добавьте этапы маршрута или выберите шаблон</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = this.currentRoute.legs.map((leg, index) => `
            <div class="leg-item ${leg.type}" data-index="${index}">
                <div class="leg-header">
                    <span class="leg-type-badge ${leg.type}">
                        ${this.getLegTypeIcon(leg.type)} ${this.getLegTypeName(leg.type)}
                    </span>
                    <button class="btn-remove-leg" onclick="logistic.removeLeg(${index})">&times;</button>
                </div>
                <div class="leg-body">
                    <div class="form-row">
                        <input type="text" value="${leg.name || ''}" 
                               placeholder="Название этапа" 
                               onchange="logistic.updateLeg(${index}, 'name', this.value)">
                        <select onchange="logistic.updateLeg(${index}, 'transport', this.value)">
                            <option value="auto" ${leg.transport === 'auto' ? 'selected' : ''}>🚛 Авто</option>
                            <option value="fly" ${leg.transport === 'fly' ? 'selected' : ''}>✈️ Авиа</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <input type="text" value="${leg.address || ''}" 
                               placeholder="Адрес/Город"
                               onchange="logistic.updateLeg(${index}, 'address', this.value)">
                        <input type="time" value="${leg.time || ''}" 
                               onchange="logistic.updateLeg(${index}, 'time', this.value)">
                    </div>
                </div>
            </div>
        `).join('');
    }

    renderBoxesList() {
        const container = document.getElementById('route-boxes-list');
        if (!container) return;
        
        if (this.currentRoute.thermalBoxes.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: #64748b; padding: 15px;">Термобоксы будут рассчитаны автоматически</p>';
            return;
        }
        
        container.innerHTML = this.currentRoute.thermalBoxes.map((box, index) => `
            <div class="box-item">
                <span class="box-number">Бокс #${index + 1}</span>
                <span class="box-info">${box.volume}л / ${box.weight}кг</span>
                <button class="btn-remove-box" onclick="logistic.removeBox(${index})">&times;</button>
            </div>
        `).join('');
    }

    getLegTypeIcon(type) {
        const icons = {
            mile1: '📦',
            mile2: '🚚',
            mile3: '🏠',
            return: '🔄'
        };
        return icons[type] || '📍';
    }

    getLegTypeName(type) {
        const names = {
            mile1: '1 миля (Забор груза)',
            mile2: '2 миля (Магистраль)',
            mile3: '3 миля (Доставка)',
            return: 'Возврат боксов'
        };
        return names[type] || type;
    }

    // ==================== УПРАВЛЕНИЕ ЭТАПАМИ ====================
    
    addLeg(type = null) {
        const legType = type || prompt('Тип этапа:\n- mile1: Забор груза\n- mile2: Магистраль\n- mile3: Доставка\n- return: Возврат', 'mile1');
        
        if (!legType) return;
        
        this.currentRoute.legs.push({
            type: legType,
            name: '',
            transport: 'auto',
            address: '',
            time: ''
        });
        
        this.renderLegsList();
        this.calculateRouteSummary();
    }

    removeLeg(index) {
        this.currentRoute.legs.splice(index, 1);
        this.renderLegsList();
        this.calculateRouteSummary();
    }

    updateLeg(index, field, value) {
        this.currentRoute.legs[index][field] = value;
    }

    // ==================== ТЕРМОБОКСЫ ====================
    
    calculateBoxes() {
        // Собираем грузы из заявок в маршруте
        const totalWeight = this.currentRoute.legs.reduce((sum, leg) => {
            if (leg.orders) {
                return sum + leg.orders.reduce((s, o) => s + (o.weight || 0), 0);
            }
            return sum;
        }, 0);
        
        const totalVolume = this.currentRoute.legs.reduce((sum, leg) => {
            if (leg.orders) {
                return sum + leg.orders.reduce((s, o) => s + (o.volume || 0), 0);
            }
            return sum;
        }, 0);
        
        // Стандартный термобокс: 60л, макс 20кг
        const BOX_VOLUME = 60;
        const BOX_MAX_WEIGHT = 20;
        
        const boxesByWeight = Math.ceil(totalWeight / BOX_MAX_WEIGHT);
        const boxesByVolume = Math.ceil(totalVolume / BOX_VOLUME);
        
        const boxCount = Math.max(boxesByWeight, boxesByVolume, 1);
        
        this.currentRoute.thermalBoxes = [];
        for (let i = 0; i < boxCount; i++) {
            this.currentRoute.thermalBoxes.push({
                id: i + 1,
                volume: BOX_VOLUME,
                weight: Math.min(BOX_MAX_WEIGHT, totalWeight / boxCount),
                items: []
            });
        }
        
        this.renderBoxesList();
        this.showNotification(`✅ Рассчитано ${boxCount} термобоксов`);
    }

    removeBox(index) {
        this.currentRoute.thermalBoxes.splice(index, 1);
        this.renderBoxesList();
    }

    // ==================== ВОЗВРАТ БОКСОВ ====================
    
    buildReturnRoute() {
        // Создаём обратный маршрут
        const returnLegs = [...this.currentRoute.legs].reverse().map(leg => ({
            ...leg,
            type: 'return',
            name: `Возврат: ${leg.name}`
        }));
        
        this.currentRoute.returnRoute = {
            legs: returnLegs,
            boxes: this.currentRoute.thermalBoxes.length
        };
        
        this.showNotification('🔄 Маршрут возврата построен');
    }

    // ==================== СОХРАНЕНИЕ МАРШРУТА ====================
    
    saveCurrentRoute() {
        if (this.currentRoute.legs.length === 0) {
            this.showNotification('Добавьте этапы маршрута!', 'error');
            return;
        }
        
        const nameInput = document.getElementById('route-name');
        const regionInput = document.getElementById('route-region');
        
        if (!nameInput || !regionInput) {
            this.showNotification('Ошибка: модальное окно не найдено', 'error');
            return;
        }
        
        const name = nameInput.value || `Маршрут ${this.savedRoutes.length + 1}`;
        const region = regionInput.value || 'Не указан';
        
        // Создаём копию маршрута для сохранения (чтобы избежать проблем с ссылками)
        const routeToSave = {
            id: this.currentRoute.id || Date.now(),
            name: name,
            region: region,
            legs: JSON.parse(JSON.stringify(this.currentRoute.legs)), // Глубокое копирование
            thermalBoxes: this.currentRoute.thermalBoxes,
            returnRoute: this.currentRoute.returnRoute,
            updatedAt: new Date().toISOString()
        };
        
        this.savedRoutes.push(routeToSave);
        
        try {
            this.saveRoutesToStorage();
            this.renderSavedRoutes();
            this.showNotification(`✅ Маршрут "${name}" сохранен!`);
            this.closeRouteBuilder();
        } catch (error) {
            console.error('Ошибка сохранения маршрута:', error);
            this.showNotification('❌ Ошибка при сохранении маршрута', 'error');
        }
    }

    clearRoute() {
        this.currentRoute = {
            id: Date.now(),
            name: '',
            region: '',
            legs: [],
            thermalBoxes: [],
            returnRoute: null
        };
        this.renderRouteBuilder();
        this.showNotification('Маршрут очищен');
    }

    // ==================== ОТРИСОВКА ====================
    
    renderSavedRoutes() {
        const container = document.getElementById('saved-routes-list');
        if (!container) return;
        
        if (this.savedRoutes.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: #64748b; padding: 10px;">Нет сохраненных маршрутов</p>';
            return;
        }
        
        container.innerHTML = this.savedRoutes.map(route => {
            const boxCount = route.thermalBoxes?.length || 0;
            const legsCount = route.legs?.length || 0;
            
            return `
            <div class="saved-route-item">
                <div class="saved-route-info">
                    <div class="saved-route-name">📦 ${route.name || 'Без названия'}</div>
                    <div class="saved-route-region">${route.region || 'Регион не указан'}</div>
                    <div class="saved-route-stats">
                        <span>🛣️ ${legsCount} этапов</span>
                        <span>🌡️ ${boxCount} боксов</span>
                    </div>
                </div>
                <div class="saved-route-actions">
                    <button class="btn-small" onclick="logistic.loadRoute(${route.id})">Открыть</button>
                    <button class="btn-small btn-success" onclick="logistic.applyRouteToOrders(${route.id})">Применить</button>
                    <button class="btn-small btn-danger" onclick="logistic.deleteRoute(${route.id})">&times;</button>
                </div>
            </div>
            `;
        }).join('');
    }

    renderTemplates() {
        const container = document.getElementById('route-templates-list');
        if (!container) return;
        
        container.innerHTML = this.routeTemplates.map(template => `
            <div class="template-item">
                <div class="template-info">
                    <div class="template-name">${template.name}</div>
                    <div class="template-region">${template.region}</div>
                </div>
                <button class="btn-small" onclick="logistic.applyTemplate(${template.id})">Использовать</button>
            </div>
        `).join('');
    }

    applyTemplate(templateId) {
        const template = this.routeTemplates.find(t => t.id === templateId);
        if (!template) return;
        
        this.currentRoute.legs = template.legs.map(leg => ({
            ...leg,
            name: leg.name,
            transport: leg.transport,
            address: '',
            time: ''
        }));
        
        this.renderLegsList();
        this.showNotification(`Шаблон "${template.name}" применен`);
    }

    loadRoute(routeId) {
        const route = this.savedRoutes.find(r => r.id === routeId);
        if (!route) return;
        
        this.currentRoute = { ...route };
        this.openRouteBuilder();
        this.renderRouteBuilder();
    }

    deleteRoute(routeId) {
        if (!confirm('Удалить этот маршрут?')) return;
        
        this.savedRoutes = this.savedRoutes.filter(r => r.id !== routeId);
        this.saveRoutesToStorage();
        this.renderSavedRoutes();
        
        this.showNotification('Маршрут удален');
    }

    applyRouteToOrders(routeId) {
        const route = this.savedRoutes.find(r => r.id === routeId);
        if (!route) return;
        
        // Применяем маршрут к заявкам
        this.showNotification(`Маршрут "${route.name}" применяется к заявкам`);
        // TODO: логика применения к заявкам
    }

    calculateRouteSummary() {
        const summaryEl = document.getElementById('route-summary');
        if (!summaryEl) return;
        
        const legsCount = this.currentRoute.legs.length;
        const boxesCount = this.currentRoute.thermalBoxes.length;
        const hasReturn = !!this.currentRoute.returnRoute;
        
        summaryEl.innerHTML = `
            <div class="route-summary-grid">
                <div class="summary-item">
                    <span class="summary-label">Этапов</span>
                    <span class="summary-value">${legsCount}</span>
                </div>
                <div class="summary-item">
                    <span class="summary-label">Термобоксов</span>
                    <span class="summary-value">${boxesCount}</span>
                </div>
                <div class="summary-item">
                    <span class="summary-label">Возврат</span>
                    <span class="summary-value">${hasReturn ? '✅' : '❌'}</span>
                </div>
            </div>
        `;
    }

    // ==================== ОСТАЛЬНЫЕ МЕТОДЫ ====================
    
    getWeekStart(date) {
        const d = new Date(date);
        const day = d.getDay();
        const diff = d.getDate() - day + (day === 0 ? -6 : 1);
        return new Date(d.setDate(diff));
    }

    prevWeek() {
        this.currentWeekStart.setDate(this.currentWeekStart.getDate() - 7);
        this.updateWeekDisplay();
        this.updateCalendar();
    }

    nextWeek() {
        this.currentWeekStart.setDate(this.currentWeekStart.getDate() + 7);
        this.updateWeekDisplay();
        this.updateCalendar();
    }

    updateWeekDisplay() {
        const end = new Date(this.currentWeekStart);
        end.setDate(end.getDate() + 6);
        
        const options = { day: '2-digit', month: '2-digit' };
        document.getElementById('current-week').textContent = 
            `${this.currentWeekStart.toLocaleDateString('ru-RU', options)} - ${end.toLocaleDateString('ru-RU', options)}`;
    }

    updateCalendar() {
        // TODO: реализация календаря
    }

    setupMap() {
        // Инициализация при показе вкладки
    }

    initMapOnShow() {
        try {
            const mapContainer = document.getElementById('logistics-map');
            if (!mapContainer) {
                console.error('[LOGISTIC] Контейнер карты не найден!');
                return;
            }
            
            // Если карта уже инициализирована - просто обновим размер
            if (this.map) {
                setTimeout(() => {
                    this.map.invalidateSize();
                    this.updateMap();
                }, 100);
                return;
            }
            
            try {
                this.map = L.map('logistics-map', {
                    center: [55.7558, 37.6173],
                    zoom: 8
                });
                
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; OpenStreetMap contributors'
                }).addTo(this.map);

                console.log('[LOGISTIC] Карта инициализирована');
                
                setTimeout(() => {
                    if (this.map) {
                        this.map.invalidateSize();
                        this.updateMap();
                    }
                }, 300);
                
            } catch (mapError) {
                console.error('[LOGISTIC] Ошибка инициализации карты:', mapError);
                mapContainer.innerHTML = '<div style="padding: 40px; text-align: center; color: #e74c3c;">Ошибка загрузки карты</div>';
            }
        } catch (error) {
            console.error('[LOGISTIC] Ошибка в initMapOnShow:', error);
        }
    }

    updateMap() {
        if (!this.map) return;
        
        // Очищаем старые маркеры
        this.markers.forEach(m => this.map.removeLayer(m));
        this.markers = [];
        
        const plannedOrders = this.orders.filter(o => o.status === 'planned' || o.status === 'new');
        
        console.log('[LOGISTIC] Всего заявок:', plannedOrders.length);
        
        plannedOrders.forEach(order => {
            console.log('[LOGISTIC] Заявка #', order.id, 'coords:', order.pickupCoords, order.deliveryCoords);
            
            // Проверяем координаты забора
            if (order.pickupCoords && 
                typeof order.pickupCoords.lat === 'number' && 
                typeof order.pickupCoords.lng === 'number' &&
                order.pickupCoords.lat !== null &&
                order.pickupCoords.lng !== null) {
                
                const marker = L.marker([order.pickupCoords.lat, order.pickupCoords.lng])
                    .addTo(this.map)
                    .bindPopup(`
                        <strong>📦 Загрузка - Заявка #${order.id}</strong><br>
                        ${this.escapeHtml(order.client)}<br>
                        ${this.escapeHtml(order.pickupAddress)}
                    `);
                this.markers.push(marker);
                console.log('[LOGISTIC] Добавлен маркер загрузки:', [order.pickupCoords.lat, order.pickupCoords.lng]);
            } else {
                console.warn('[LOGISTIC] Нет координат забора для заявки #', order.id);
            }
            
            // Проверяем координаты доставки
            if (order.deliveryCoords && 
                typeof order.deliveryCoords.lat === 'number' && 
                typeof order.deliveryCoords.lng === 'number' &&
                order.deliveryCoords.lat !== null &&
                order.deliveryCoords.lng !== null) {
                
                const marker = L.marker([order.deliveryCoords.lat, order.deliveryCoords.lng])
                    .addTo(this.map)
                    .bindPopup(`
                        <strong>🏁 Доставка - Заявка #${order.id}</strong><br>
                        ${this.escapeHtml(order.deliveryAddress)}
                    `);
                this.markers.push(marker);
                console.log('[LOGISTIC] Добавлен маркер доставки:', [order.deliveryCoords.lat, order.deliveryCoords.lng]);
            } else {
                console.warn('[LOGISTIC] Нет координат доставки для заявки #', order.id);
            }
        });
        
        console.log('[LOGISTIC] Всего маркеров:', this.markers.length);
        
        // Центрируем карту по маркерам
        if (this.markers.length > 0) {
            const group = L.featureGroup(this.markers);
            this.map.fitBounds(group.getBounds().pad(0.1));
            console.log('[LOGISTIC] Карта центрирована по маркерам');
        } else {
            // Если маркеров нет - центрируем на Москве
            this.map.setView([55.7558, 37.6173], 8);
        }
    }

    renderOrders() {
        const container = document.getElementById('unassigned-orders');
        if (!container) return;
        
        const newOrders = this.orders.filter(o => o.status === 'new');
        
        if (newOrders.length === 0) {
            container.innerHTML = '<p style="padding: 20px; text-align: center; color: #64748b;">Нет новых заявок</p>';
            return;
        }
        
        container.innerHTML = newOrders.map(order => {
            const isExpress = order.orderType === 'express';
            return `
            <div class="order-item" data-order-id="${order.id}" data-order-type="${order.orderType || 'full'}">
                <div class="order-header">
                    <h4>Заявка #${order.id} ${isExpress ? '<span class="express-badge">✈️ ЭКСПРЕСС</span>' : ''}</h4>
                </div>
                <p><strong>Клиент:</strong> ${order.client}</p>
                <p><strong>Загрузка:</strong> ${order.pickupAddress}</p>
                <p><strong>Доставка:</strong> ${order.deliveryAddress}</p>
                <p><strong>Груз:</strong> ${order.weight || '-'} кг, ${order.volume || '-'} м³</p>
                <div class="order-actions">
                    <button class="btn-small" onclick="logistic.addOrderToRoute(${order.id})">➕ В маршрут</button>
                </div>
                <span class="status-badge status-new">Новая</span>
            </div>
            `;
        }).join('');
    }

    renderVehicles() {
        const container = document.getElementById('available-vehicles');
        if (!container) return;
        
        const available = this.vehicles.filter(v => v.status === 'available');
        
        if (available.length === 0) {
            container.innerHTML = '<p style="padding: 20px; text-align: center; color: #64748b;">Нет доступного транспорта</p>';
            return;
        }
        
        container.innerHTML = available.map(vehicle => {
            const isAircraft = vehicle.transport === 'fly';
            return `
            <div class="vehicle-item ${isAircraft ? 'aircraft' : ''}" data-vehicle-id="${vehicle.id}">
                <div>
                    <strong>${isAircraft ? '✈️' : '🚛'} ${vehicle.plate}</strong>
                    ${isAircraft ? '<span class="aircraft-badge">АВИА</span>' : ''}
                    <br>
                    <small>${vehicle.type}</small>
                    <br>
                    <small>Водитель: ${vehicle.driver}</small>
                    <br>
                    <small>Грузоподъемность: ${vehicle.capacity} кг</small>
                </div>
                <span class="status-badge status-planned">Свободен</span>
            </div>
            `;
        }).join('');
    }

    addOrderToRoute(orderId) {
        const order = this.orders.find(o => o.id == orderId);
        if (!order) {
            this.showNotification('Заявка не найдена', 'error');
            return;
        }
        
        // Проверяем координаты
        const hasPickupCoords = order.pickupCoords && 
            typeof order.pickupCoords.lat === 'number' && 
            typeof order.pickupCoords.lng === 'number';
        const hasDeliveryCoords = order.deliveryCoords && 
            typeof order.deliveryCoords.lat === 'number' && 
            typeof order.deliveryCoords.lng === 'number';
        
        if (!hasPickupCoords || !hasDeliveryCoords) {
            this.showNotification('❌ У заявки нет координат! Создайте заявку через Менеджер с правильными адресами.', 'error');
            console.error('[LOGISTIC] Заявка #', orderId, 'has coords:', { pickup: hasPickupCoords, delivery: hasDeliveryCoords });
            return;
        }
        
        // Добавляем заявку к текущему маршруту
        if (this.currentRoute.legs.length === 0) {
            // Создаём стандартный маршрут
            this.currentRoute.legs = [
                { 
                    type: 'mile1', 
                    name: `Забор: ${order.pickupAddress}`, 
                    transport: 'auto', 
                    address: order.pickupAddress,
                    coords: order.pickupCoords
                },
                { 
                    type: 'mile2', 
                    name: 'Магистраль', 
                    transport: order.orderType === 'express' ? 'fly' : 'auto' 
                },
                { 
                    type: 'mile3', 
                    name: `Доставка: ${order.deliveryAddress}`, 
                    transport: 'auto', 
                    address: order.deliveryAddress,
                    coords: order.deliveryCoords
                }
            ];
        }
        
        // Добавляем заказ к первому этапу
        if (!this.currentRoute.legs[0].orders) {
            this.currentRoute.legs[0].orders = [];
        }
        this.currentRoute.legs[0].orders.push(order);
        
        this.renderLegsList();
        this.calculateBoxes();
        
        this.showNotification(`Заявка #${orderId} добавлена в маршрут`);
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = 'notification' + (type === 'error' ? ' error' : '');
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.add('active'), 10);
        setTimeout(() => {
            notification.classList.remove('active');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
    
    // Экранирование HTML для безопасности
    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Инициализация
let logistic;
document.addEventListener('DOMContentLoaded', () => {
    logistic = new LogisticModule();
    window.logistic = logistic;
});
