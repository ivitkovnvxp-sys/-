// Модуль отчетов
class ReportsModule {
    constructor() {
        this.orders = [];
        this.init();
    }

    init() {
        // Установка дат по умолчанию (последний месяц)
        this.setDefaultDates();
        
        // Обработчик кнопки генерации отчета
        document.getElementById('btn-generate-report')
            .addEventListener('click', () => this.generateReport());
        
        // Загрузка начальных данных
        this.loadInitialData();
    }

    setDefaultDates() {
        const endDate = new Date();
        const startDate = new Date();
        startDate.setMonth(startDate.getMonth() - 1);

        document.getElementById('report-start-date').value = 
            startDate.toISOString().split('T')[0];
        document.getElementById('report-end-date').value = 
            endDate.toISOString().split('T')[0];
    }

    async loadInitialData() {
        try {
            this.orders = await api.getOrders();
            this.updateStats(this.orders);
            this.renderReportTable(this.orders);
        } catch (error) {
            console.error('Ошибка загрузки данных:', error);
        }
    }

    async generateReport() {
        const startDate = document.getElementById('report-start-date').value;
        const endDate = document.getElementById('report-end-date').value;

        if (!startDate || !endDate) {
            alert('Пожалуйста, выберите даты периода');
            return;
        }

        try {
            const report = await api.getReport(startDate, endDate);
            this.orders = report.orders || [];
            
            this.updateStats(this.orders);
            this.renderReportTable(this.orders);
            
            this.showNotification('Отчет сгенерирован');
        } catch (error) {
            console.error('Ошибка генерации отчета:', error);
            this.showNotification('Ошибка при генерации отчета', 'error');
        }
    }

    updateStats(orders) {
        const stats = {
            total: orders.length,
            delivered: orders.filter(o => o.status === 'delivered').length,
            inTransit: orders.filter(o => o.status === 'in_transit').length,
            planned: orders.filter(o => o.status === 'planned').length,
            new: orders.filter(o => o.status === 'new').length
        };

        // Расчет среднего времени доставки
        const deliveredOrders = orders.filter(o => 
            o.status === 'delivered' && o.orderDate && o.updatedAt
        );
        
        let avgTime = 0;
        if (deliveredOrders.length > 0) {
            const totalTime = deliveredOrders.reduce((sum, order) => {
                const orderDate = new Date(order.orderDate);
                const updateDate = new Date(order.updatedAt || Date.now());
                const diffDays = (updateDate - orderDate) / (1000 * 60 * 60 * 24);
                return sum + diffDays;
            }, 0);
            avgTime = (totalTime / deliveredOrders.length).toFixed(1);
        }

        // Обновление UI
        document.getElementById('stat-total').textContent = stats.total;
        document.getElementById('stat-delivered').textContent = stats.delivered;
        document.getElementById('stat-in-transit').textContent = stats.inTransit;
        document.getElementById('stat-avg-time').textContent = avgTime + ' дней';
    }

    renderReportTable(orders) {
        const tbody = document.querySelector('#report-table tbody');
        
        if (orders.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; padding: 40px;">
                        Нет данных за выбранный период
                    </td>
                </tr>
            `;
            return;
        }

        tbody.innerHTML = orders
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
            .map(order => {
                const orderDate = new Date(order.orderDate);
                const createdAt = new Date(order.createdAt);
                const timeInTransit = order.orderDate ? 
                    this.calculateDays(createdAt, orderDate) : '-';

                return `
                    <tr>
                        <td>#${order.id}</td>
                        <td>${this.escapeHtml(order.client)}</td>
                        <td>${this.formatDate(createdAt)}</td>
                        <td>${order.orderDate ? this.formatDate(new Date(order.orderDate)) : '-'}</td>
                        <td>
                            <span class="status-badge status-${this.getStatusClass(order.status)}">
                                ${this.getStatusText(order.status)}
                            </span>
                        </td>
                        <td>${timeInTransit}</td>
                    </tr>
                `;
            }).join('');
    }

    calculateDays(date1, date2) {
        const diffTime = Math.abs(date2 - date1);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return diffDays + ' дн.';
    }

    getStatusClass(status) {
        const statusMap = {
            'new': 'new',
            'planned': 'planned',
            'in_transit': 'in-transit',
            'delivered': 'delivered'
        };
        return statusMap[status] || 'new';
    }

    getStatusText(status) {
        const statusText = {
            'new': 'Новая',
            'planned': 'Планированная',
            'in_transit': 'В пути',
            'delivered': 'Доставлена'
        };
        return statusText[status] || 'Новая';
    }

    formatDate(date) {
        return date.toLocaleDateString('ru-RU', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.add('active'), 10);
        setTimeout(() => {
            notification.classList.remove('active');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}

// Инициализация
let reports;
document.addEventListener('DOMContentLoaded', () => {
    reports = new ReportsModule();
    window.reports = reports;
});
