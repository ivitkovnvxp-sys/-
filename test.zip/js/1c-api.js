// API для интеграции с 1С: Управление торговлей
// Ссылка на OData: https://app810581.1capp.net/1SUpravleniye-torgovley-8/odata/standard.odata
const API_1C = {
    baseUrl: 'https://app810581.1capp.net/1SUpravleniye-torgovley-8/odata/standard.odata',
    enabled: false, // Включить при наличии данных в 1С
    
    // ==================== РЕЖИМ МОКА (Тестовые данные) ====================
    useMockData: true,
    
    // Тестовые заявки
    mockOrders: [
        { id: 123, orderDate: '2025-01-15', client: 'ООО Ромашка', status: 'new', assignedDriver: null },
        { id: 124, orderDate: '2025-01-15', client: 'ПАО Vector', status: 'planned', assignedDriver: 'driver1' },
        { id: 125, orderDate: '2025-01-16', client: 'ИП Иванов', status: 'new', assignedDriver: null },
        { id: 134, orderDate: '2025-01-16', client: 'ЗАО Техно', status: 'planned', assignedDriver: 'driver2' },
        { id: 140, orderDate: '2025-01-17', client: 'ООО Строй', status: 'new', assignedDriver: null },
        { id: 145, orderDate: '2025-01-17', client: 'ООО Комфорт', status: 'planned', assignedDriver: 'driver1' },
        { id: 156, orderDate: '2025-01-18', client: 'ИП Петров', status: 'new', assignedDriver: null },
        { id: 160, orderDate: '2025-01-19', client: 'ПАО Газпром', status: 'planned', assignedDriver: 'driver2' },
    ],
    
    // Тестовые водители
    mockDrivers: [
        { id: 'driver1', name: 'Петров Сергей Иванович', phone: '+7 (900) 123-45-67', status: 'active' },
        { id: 'driver2', name: 'Сидоров Александр Алексеевич', phone: '+7 (900) 765-43-21', status: 'active' },
        { id: 'driver3', name: 'Козлов Дмитрий Владимирович', phone: '+7 (900) 111-22-33', status: 'active' },
    ],
    
    // Тестовые этапы маршрутов (с правильным форматом)
    mockRouteStages: [
        { id: 'stage1', routeId: 124, routeName: 'Москва - СПб', date: '2025-01-15', address: 'Москва, ул. Ленина 1', driverId: 'driver1' },
        { id: 'stage2', routeId: 124, routeName: 'Москва - СПб', date: '2025-01-16', address: 'Тверь, ТК Центр', driverId: 'driver1' },
        { id: 'stage3', routeId: 134, routeName: 'Казань - Уфа', date: '2025-01-16', address: 'Казань, ЦТР', driverId: 'driver2' },
        { id: 'stage4', routeId: 134, routeName: 'Казань - Уфа', date: '2025-01-17', address: 'Уфа, склад №5', driverId: 'driver2' },
        { id: 'stage5', routeId: 145, routeName: 'Москва - Воронеж', date: '2025-01-17', address: 'Москва, склад А1', driverId: 'driver1' },
        { id: 'stage6', routeId: 160, routeName: 'Екатеринбург - Пермь', date: '2025-01-19', address: 'Екатеринбург, ТК Урал', driverId: 'driver2' },
    ],
    
    // Сохранённые маршруты с точками (для planner.js)
    mockSavedRoutes: [
        {
            id: 124,
            name: 'Москва - СПб',
            transportType: 'auto',
            points: [
                { id: 1, address: 'Москва, ул. Ленина 1', lat: 55.7558, lng: 37.6173, date: '2025-01-15', driverId: 'driver1' },
                { id: 2, address: 'Тверь, ТК Центр', lat: 56.8587, lng: 35.9075, date: '2025-01-16', driverId: 'driver1' }
            ]
        },
        {
            id: 134,
            name: 'Казань - Уфа',
            transportType: 'auto',
            points: [
                { id: 3, address: 'Казань, ЦТР', lat: 55.7897, lng: 49.1219, date: '2025-01-16', driverId: 'driver2' },
                { id: 4, address: 'Уфа, склад №5', lat: 54.7388, lng: 55.9721, date: '2025-01-17', driverId: 'driver2' }
            ]
        },
        {
            id: 145,
            name: 'Москва - Воронеж',
            transportType: 'auto',
            points: [
                { id: 5, address: 'Москва, склад А1', lat: 55.7558, lng: 37.6173, date: '2025-01-17', driverId: 'driver1' }
            ]
        },
        {
            id: 160,
            name: 'Екатеринбург - Пермь',
            transportType: 'auto',
            points: [
                { id: 6, address: 'Екатеринбург, ТК Урал', lat: 56.8389, lng: 60.6057, date: '2025-01-19', driverId: 'driver2' }
            ]
        }
    ],
    
    // ==================== ЗАЯВКИ ====================
    async getOrders() {
        try {
            if (this.useMockData || !this.enabled) {
                console.log('[1C API] Используем моковые данные для заявок');
                return [...this.mockOrders];
            }
            
            // Реальный запрос к 1С (когда будут данные)
            const response = await fetch(`${this.baseUrl}/AccumulationRegister_ЗаказыКлиентов?$top=100`);
            const data = await response.json();
            return this.transformOrders(data.value || []);
        } catch (error) {
            console.error('[1C API] Ошибка загрузки заявок:', error);
            return [...this.mockOrders]; // Возвращаем моковые данные при ошибке
        }
    },
    
    transformOrders(orders) {
        return orders.map(order => ({
            id: order.ID || order.Ref || Math.random().toString(36).substr(2, 9),
            orderDate: order.Date || new Date().toISOString().split('T')[0],
            client: order.Client?.Description || order.Client?.Name || 'Без клиента',
            pickupAddress: order.PickupAddress || '',
            deliveryAddress: order.DeliveryAddress || '',
            weight: order.Weight || 0,
            volume: order.Volume || 0,
            status: this.mapStatus(order.Status),
            assignedDriver: order.Driver?.ID || null
        }));
    },
    
    mapStatus(status) {
        const statusMap = {
            'new': 'new',
            'planned': 'planned',
            'in_transit': 'in_transit',
            'delivered': 'delivered'
        };
        return statusMap[status] || 'new';
    },
    
    // ==================== ВОДИТЕЛИ ====================
    async getDrivers() {
        try {
            if (this.useMockData || !this.enabled) {
                console.log('[1C API] Используем моковые данные для водителей');
                return [...this.mockDrivers];
            }
            
            // Реальный запрос к 1С (когда будут данные)
            const response = await fetch(`${this.baseUrl}/Ref.Catalogs.PhysPersons?$top=100`);
            const data = await response.json();
            return this.transformDrivers(data.value || []);
        } catch (error) {
            console.error('[1C API] Ошибка загрузки водителей:', error);
            return [...this.mockDrivers];
        }
    },
    
    transformDrivers(drivers) {
        return drivers.map(driver => ({
            id: driver.ID || driver.Ref,
            name: driver.Description || driver.Name || 'Без имени',
            phone: driver.Phone || '',
            status: driver.Status || 'active'
        }));
    },
    
    // ==================== ТРАНСПОРТ ====================
    async getVehicles() {
        try {
            if (this.useMockData || !this.enabled) {
                console.log('[1C API] Используем моковые данные для транспорта');
                return [
                    { id: 'v1', plate: 'А123АА 77', type: 'Фура', capacity: 20000, status: 'available' },
                    { id: 'v2', plate: 'В456ВВ 77', type: 'Газель', capacity: 1500, status: 'available' },
                    { id: 'v3', plate: 'С789СС 77', type: 'Фура', capacity: 22000, status: 'maintenance' },
                ];
            }
            
            // Реальный запрос к 1С
            const response = await fetch(`${this.baseUrl}/Ref.Catalogs.Automobiles?$top=100`);
            const data = await response.json();
            return this.transformVehicles(data.value || []);
        } catch (error) {
            console.error('[1C API] Ошибка загрузки транспорта:', error);
            return [];
        }
    },
    
    transformVehicles(vehicles) {
        return vehicles.map(vehicle => ({
            id: vehicle.ID || vehicle.Ref,
            plate: vehicle.PlateNumber || vehicle.Number || 'А000АА 00',
            type: vehicle.Type || 'Фура',
            capacity: vehicle.Capacity || 20000,
            status: vehicle.Status || 'available'
        }));
    },
    
    // ==================== ЭТАПЫ МАРШРУТОВ ====================
    async getRouteStages() {
        try {
            if (this.useMockData || !this.enabled) {
                console.log('[1C API] Используем моковые данные для этапов');
                return [...this.mockRouteStages];
            }
            
            // Реальный запрос к 1С (когда будут данные)
            const response = await fetch(`${this.baseUrl}/InformationRegister_ТК_МаршрутныеЗадачи?$top=200`);
            const data = await response.json();
            return this.transformRouteStages(data.value || []);
        } catch (error) {
            console.error('[1C API] Ошибка загрузки этапов:', error);
            return [...this.mockRouteStages];
        }
    },
    
    // ==================== СОХРАНЁННЫЕ МАРШРУТЫ ====================
    async getSavedRoutes() {
        try {
            if (this.useMockData || !this.enabled) {
                console.log('[1C API] Используем моковые данные для маршрутов');
                return [...this.mockSavedRoutes];
            }
            
            // Реальный запрос к 1С
            const response = await fetch(`${this.baseUrl}/InformationRegister_ТК_Маршруты?$top=100`);
            const data = await response.json();
            return this.transformSavedRoutes(data.value || []);
        } catch (error) {
            console.error('[1C API] Ошибка загрузки маршрутов:', error);
            return [...this.mockSavedRoutes];
        }
    },
    
    transformSavedRoutes(routes) {
        return routes.map(route => ({
            id: route.ID || route.Ref,
            name: route.Name || 'Маршрут',
            transportType: route.TransportType || 'auto',
            points: route.Points || []
        }));
    },
    
    transformRouteStages(stages) {
        return stages.map(stage => ({
            id: stage.ID || stage.Ref,
            routeId: stage.Route?.ID || stage.RouteID,
            routeName: stage.RouteName || 'Маршрут',
            date: stage.Date || new Date().toISOString().split('T')[0],
            address: stage.Address || '',
            driverId: stage.Driver?.ID || null,
            pointIndex: stage.PointIndex || 0
        }));
    },
    
    // ==================== СОЗДАНИЕ/ОБНОВЛЕНИЕ ====================
    async createOrder(order) {
        try {
            if (this.useMockData || !this.enabled) {
                console.log('[1C API] Моковое создание заявки:', order);
                const newOrder = { ...order, id: Date.now() };
                this.mockOrders.push(newOrder);
                return newOrder;
            }
            
            const response = await fetch(`${this.baseUrl}/Ref.Documents.Orders`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(order)
            });
            return await response.json();
        } catch (error) {
            console.error('[1C API] Ошибка создания заявки:', error);
            throw error;
        }
    },
    
    async updateOrder(order) {
        try {
            if (this.useMockData || !this.enabled) {
                console.log('[1C API] Моковое обновление заявки:', order);
                const index = this.mockOrders.findIndex(o => o.id == order.id);
                if (index !== -1) {
                    this.mockOrders[index] = { ...this.mockOrders[index], ...order };
                }
                return order;
            }
            
            const response = await fetch(`${this.baseUrl}/Ref.Documents.Orders('${order.id}')`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(order)
            });
            return await response.json();
        } catch (error) {
            console.error('[1C API] Ошибка обновления заявки:', error);
            throw error;
        }
    },
    
    // ==================== ТЕСТИРОВАНИЕ ====================
    async testConnection() {
        try {
            const response = await fetch(`${this.baseUrl}/$metadata`);
            if (response.ok) {
                console.log('✅ 1C API подключён успешно');
                this.enabled = true;
                return true;
            }
            console.warn('⚠️ 1C API недоступен, используем моковые данные');
            return false;
        } catch (error) {
            console.error('❌ 1C API ошибка:', error);
            return false;
        }
    },
    
    // ==================== СПИСОК ТАБЛИЦ 1С ====================
    getAvailableTables() {
        return {
            'Регистры': [
                'AccumulationRegister_ЗаказыКлиентов',
                'AccumulationRegister_РасчетыСКлиентами',
                'InformationRegister_ТК_СоответствиеНоменклатурыКМилям',
            ],
            'Документы (если доступны)': [
                'Document_ЗаказыКлиентов',
                'Document_РеализацияТоваровУслуг',
            ],
            'Справочники (если доступны)': [
                'Catalog_Контрагенты',
                'Catalog_ФизическиеЛица',
                'Catalog_Номенклатура',
            ],
            'Задачи': [
                'Task_ЗадачаИсполнителя',
            ]
        };
    }
};

// Экспорт
window.API_1C = API_1C;
