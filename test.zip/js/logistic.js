// Модуль логиста - планирование заявок
class LogisticModule {
    constructor() {
        this.currentWeekStart = this.getWeekStart(new Date());
        this.orders = [];
        this.vehicles = [];
        this.map = null;
        this.markers = [];
        this.routeLayer = null;
        this.routePoints = []; // Точки текущего маршрута
        this.savedRoutes = []; // Сохраненные маршруты
        
        this.init();
    }

    init() {
        this.loadData();
        this.setupDragAndDrop();
        this.setupCalendar();
        this.setupMap();
        this.loadSavedRoutes();
        
        document.getElementById('prev-week').addEventListener('click', () => this.prevWeek());
        document.getElementById('next-week').addEventListener('click', () => this.nextWeek());
        
        // Кнопки управления маршрутами
        document.getElementById('btn-new-route')?.addEventListener('click', () => this.showNewRouteModal());
        document.getElementById('btn-save-route')?.addEventListener('click', () => this.saveCurrentRoute());
        document.getElementById('btn-clear-route')?.addEventListener('click', () => this.clearCurrentRoute());
        document.getElementById('btn-add-point')?.addEventListener('click', () => this.addRoutePoint());
        
        // Обработчик для ввода адреса
        document.getElementById('new-point-address')?.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.addRoutePoint();
        });
    }

    loadSavedRoutes() {
        const saved = localStorage.getItem('tms_saved_routes');
        if (saved) {
            this.savedRoutes = JSON.parse(saved);
            this.renderSavedRoutes();
        }
    }

    saveRoutesToStorage() {
        localStorage.setItem('tms_saved_routes', JSON.stringify(this.savedRoutes));
    }

    // Показать модальное окно создания маршрута
    showNewRouteModal() {
        this.routePoints = [];
        this.updateRoutePointsList();
        
        const modal = document.getElementById('route-modal');
        if (modal) {
            modal.classList.add('active');
            document.getElementById('new-point-address').value = '';
            document.getElementById('new-point-address').focus();
        }
    }

    // Закрыть модальное окно маршрута
    closeRouteModal() {
        document.getElementById('route-modal')?.classList.remove('active');
    }

    // Добавить точку маршрута
    async addRoutePoint() {
        const addressInput = document.getElementById('new-point-address');
        const address = addressInput.value.trim();
        
        if (!address) {
            this.showNotification('Введите адрес точки!', 'error');
            return;
        }
        
        // Геокодинг адреса
        try {
            const results = await api.searchAddresses(address);
            
            if (results.length === 0) {
                this.showNotification('Адрес не найден!', 'error');
                return;
            }
            
            const point = {
                id: Date.now(),
                address: results[0].display_name,
                lat: results[0].lat,
                lng: results[0].lon
            };
            
            this.routePoints.push(point);
            addressInput.value = '';
            addressInput.focus();
            
            this.updateRoutePointsList();
            this.drawCurrentRoute();
            
            this.showNotification(`✅ Точка добавлена: ${this.routePoints.length}`);
        } catch (error) {
            console.error('Ошибка геокодинга:', error);
            this.showNotification('Ошибка поиска адреса', 'error');
        }
    }

    // Обновить список точек маршрута
    updateRoutePointsList() {
        const container = document.getElementById('route-points-list');
        if (!container) return;
        
        if (this.routePoints.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: #64748b; padding: 20px;">Добавьте точки маршрута</p>';
            return;
        }
        
        container.innerHTML = this.routePoints.map((point, index) => `
            <div class="route-point-item">
                <div class="route-point-number">${index + 1}</div>
                <div class="route-point-info">
                    <div class="route-point-address">${point.address}</div>
                    <div class="route-point-coords">${point.lat.toFixed(4)}, ${point.lng.toFixed(4)}</div>
                </div>
                <button class="route-point-delete" onclick="logistic.removeRoutePoint(${index})">&times;</button>
            </div>
        `).join('');
        
        // Обновить итоговую информацию
        this.updateRouteSummary();
    }

    // Удалить точку маршрута
    removeRoutePoint(index) {
        this.routePoints.splice(index, 1);
        this.updateRoutePointsList();
        this.drawCurrentRoute();
    }

    // Обновить итоги маршрута
    updateRouteSummary() {
        const summaryEl = document.getElementById('route-summary');
        if (!summaryEl || this.routePoints.length < 2) {
            if (summaryEl) summaryEl.innerHTML = '';
            return;
        }
        
        let totalDistance = 0;
        for (let i = 0; i < this.routePoints.length - 1; i++) {
            totalDistance += this.calculateDistance(
                this.routePoints[i].lat, this.routePoints[i].lng,
                this.routePoints[i+1].lat, this.routePoints[i+1].lng
            );
        }
        
        const autoTime = Math.round(totalDistance / 60);
        const flyTime = Math.round(totalDistance / 800);
        
        summaryEl.innerHTML = `
            <div class="route-summary-info">
                <div>📍 Точек: <strong>${this.routePoints.length}</strong></div>
                <div>📏 Расстояние: <strong>${totalDistance} км</strong></div>
                <div>🚛 Авто: <strong>~${Math.floor(autoTime / 60)}ч ${autoTime % 60}мин</strong></div>
                <div>✈️ Авиа: <strong>~${flyTime} мин</strong></div>
            </div>
        `;
    }

    // Нарисовать текущий маршрут на карте
    drawCurrentRoute() {
        if (!this.map || this.routePoints.length < 2) return;
        
        // Удалить старый маршрут
        if (this.routeLayer) {
            this.map.removeLayer(this.routeLayer);
        }
        
        // Удалить старые маркеры точек
        this.markers.forEach(m => this.map.removeLayer(m));
        this.markers = [];
        
        // Получить тип транспорта
        const transportType = document.getElementById('route-transport-type')?.value || 'auto';
        
        // Нарисовать линию маршрута
        const coords = this.routePoints.map(p => [p.lat, p.lng]);
        
        if (transportType === 'fly') {
            // Авиа - пунктирная линия
            this.routeLayer = L.polyline(coords, {
                color: '#e74c3c',
                weight: 3,
                dashArray: '10, 10',
                opacity: 0.8
            }).addTo(this.map);
        } else {
            // Авто - обычная линия
            this.routeLayer = L.polyline(coords, {
                color: '#3498db',
                weight: 4,
                opacity: 0.8
            }).addTo(this.map);
        }
        
        // Добавить маркеры точек
        this.routePoints.forEach((point, index) => {
            const icon = L.divIcon({
                className: 'route-point-marker',
                html: `<div style="
                    background: ${index === 0 ? '#f39c12' : index === this.routePoints.length - 1 ? '#10b981' : '#3498db'};
                    width: 28px; height: 28px; border-radius: 50%; 
                    border: 3px solid white; 
                    display: flex; align-items: center; justify-content: center;
                    font-weight: bold; color: white; font-size: 12px;
                    box-shadow: 0 2px 5px rgba(0,0,0,0.3);
                ">${index + 1}</div>`
            });
            
            const marker = L.marker([point.lat, point.lng], { icon })
                .bindPopup(`<b>Точка ${index + 1}</b><br>${point.address}`)
                .addTo(this.map);
            
            this.markers.push(marker);
        });
        
        // Центрировать карту по маршруту
        const bounds = L.latLngBounds(coords);
        this.map.fitBounds(bounds.pad(0.1));
    }

    // Сохранить текущий маршрут
    saveCurrentRoute() {
        if (this.routePoints.length < 2) {
            this.showNotification('Нужно минимум 2 точки!', 'error');
            return;
        }
        
        const name = prompt('Название маршрута:', `Маршрут ${this.savedRoutes.length + 1}`);
        if (!name) return;
        
        const transportType = document.getElementById('route-transport-type')?.value || 'auto';
        
        const route = {
            id: Date.now(),
            name: name,
            points: [...this.routePoints],
            transportType: transportType,
            createdAt: new Date().toISOString()
        };
        
        this.savedRoutes.push(route);
        this.saveRoutesToStorage();
        this.renderSavedRoutes();
        
        this.showNotification(`✅ Маршрут "${name}" сохранен!`);
        this.closeRouteModal();
    }

    // Очистить текущий маршрут
    clearCurrentRoute() {
        this.routePoints = [];
        
        if (this.routeLayer) {
            this.map.removeLayer(this.routeLayer);
            this.routeLayer = null;
        }
        
        this.markers.forEach(m => this.map.removeLayer(m));
        this.markers = [];
        
        this.updateRoutePointsList();
        this.showNotification('Маршрут очищен');
    }

    // Загрузить сохраненный маршрут
    loadRoute(routeId) {
        const route = this.savedRoutes.find(r => r.id === routeId);
        if (!route) return;
        
        this.routePoints = [...route.points];
        
        // Установить тип транспорта
        const select = document.getElementById('route-transport-type');
        if (select) select.value = route.transportType;
        
        this.updateRoutePointsList();
        this.drawCurrentRoute();
        
        this.closeRouteModal();
        this.showNotification(`📂 Загружен маршрут: ${route.name}`);
    }

    // Удалить сохраненный маршрут
    deleteRoute(routeId) {
        if (!confirm('Удалить этот маршрут?')) return;
        
        this.savedRoutes = this.savedRoutes.filter(r => r.id !== routeId);
        this.saveRoutesToStorage();
        this.renderSavedRoutes();
        
        this.showNotification('Маршрут удален');
    }

    // Отобразить список сохраненных маршрутов
    renderSavedRoutes() {
        const container = document.getElementById('saved-routes-list');
        if (!container) return;
        
        if (this.savedRoutes.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: #64748b; padding: 10px;">Нет сохраненных маршрутов</p>';
            return;
        }
        
        container.innerHTML = this.savedRoutes.map(route => {
            const isFly = route.transportType === 'fly';
            const icon = isFly ? '✈️' : '🚛';
            const totalDistance = this.calculateRouteDistance(route.points);
            
            return `
            <div class="saved-route-item">
                <div class="saved-route-info">
                    <div class="saved-route-name">${icon} ${route.name}</div>
                    <div class="saved-route-stats">${route.points.length} точек, ${totalDistance} км</div>
                </div>
                <div class="saved-route-actions">
                    <button class="btn-small" onclick="logistic.loadRoute(${route.id})">Загрузить</button>
                    <button class="btn-small btn-danger" onclick="logistic.deleteRoute(${route.id})">&times;</button>
                </div>
            </div>
            `;
        }).join('');
    }

    // Рассчитать общую длину маршрута
    calculateRouteDistance(points) {
        if (points.length < 2) return 0;
        
        let total = 0;
        for (let i = 0; i < points.length - 1; i++) {
            total += this.calculateDistance(
                points[i].lat, points[i].lng,
                points[i+1].lat, points[i+1].lng
            );
        }
        return total;
    }

    async loadData() {
        try {
            const [orders, vehicles] = await Promise.all([
                api.getOrders(),
                api.getVehicles()
            ]);
            
            this.orders = orders;
            this.vehicles = vehicles;
            
            this.renderUnassignedOrders();
            this.renderAvailableVehicles();
            this.updateCalendar();
            this.updateMap();
        } catch (error) {
            console.error('Ошибка загрузки данных:', error);
        }
    }

    getWeekStart(date) {
        const d = new Date(date);
        const day = d.getDay();
        const diff = d.getDate() - day + (day === 0 ? -6 : 1);
        return new Date(d.setDate(diff));
    }

    setupCalendar() {
        this.updateWeekDisplay();
    }

    updateWeekDisplay() {
        const end = new Date(this.currentWeekStart);
        end.setDate(end.getDate() + 6);
        
        const options = { day: '2-digit', month: '2-digit' };
        document.getElementById('current-week').textContent = 
            `${this.currentWeekStart.toLocaleDateString('ru-RU', options)} - ${end.toLocaleDateString('ru-RU', options)}`;
    }

    prevWeek() {
        this.currentWeekStart.setDate(this.currentWeekStart.getDate() - 7);
        this.updateWeekDisplay();
        this.updateCalendar();
    }

    nextWeek() {
        this.currentWeekStart.setDate(this.currentWeekStart.getDate() + 7);
        this.updateWeekDisplay();
        this.updateCalendar();
    }

    updateCalendar() {
        const calendar = document.getElementById('planning-calendar');
        const weekStart = new Date(this.currentWeekStart);
        
        const days = [];
        for (let i = 0; i < 7; i++) {
            const date = new Date(weekStart);
            date.setDate(date.getDate() + i);
            days.push(date);
        }

        calendar.innerHTML = days.map(date => {
            const dateStr = date.toDateString();
            const dayOrders = this.orders.filter(o => {
                const orderDate = new Date(o.orderDate);
                return orderDate.toDateString() === dateStr && o.status === 'planned';
            });

            return `
                <div class="calendar-day" data-date="${dateStr}">
                    <div class="calendar-day-header">
                        ${date.toLocaleDateString('ru-RU', { weekday: 'short' })}
                    </div>
                    <div class="calendar-day-number">
                        ${date.getDate()}
                    </div>
                    <div class="calendar-events">
                        ${dayOrders.map(order => `
                            <div class="calendar-event" draggable="true" data-order-id="${order.id}">
                                #${order.id} - ${this.escapeHtml(order.client)}
                            </div>
                        `).join('')}
                    </div>
                </div>
            `;
        }).join('');

        // Настройка drag events для событий календаря
        calendar.querySelectorAll('.calendar-event').forEach(event => {
            event.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('orderId', event.dataset.orderId);
                event.classList.add('dragging');
            });

            event.addEventListener('dragend', () => {
                event.classList.remove('dragging');
            });
        });

        // Drop на дни календаря
        calendar.querySelectorAll('.calendar-day').forEach(day => {
            day.addEventListener('dragover', (e) => {
                e.preventDefault();
                day.classList.add('drag-over');
            });

            day.addEventListener('dragleave', () => {
                day.classList.remove('drag-over');
            });

            day.addEventListener('drop', async (e) => {
                e.preventDefault();
                day.classList.remove('drag-over');
                
                const orderId = e.dataTransfer.getData('orderId');
                const newDate = day.dataset.date;
                
                await this.rescheduleOrder(orderId, newDate);
            });
        });
    }

    async rescheduleOrder(orderId, newDateStr) {
        try {
            const newDate = new Date(newDateStr);
            const orders = await api.getOrders();
            const order = orders.find(o => o.id == orderId);
            
            if (!order) return;

            // Сохраняем время из оригинальной даты
            const oldDate = new Date(order.orderDate);
            newDate.setHours(oldDate.getHours(), oldDate.getMinutes());

            await api.updateOrder(orderId, { orderDate: newDate.toISOString() });
            this.showNotification('Заявка перенесена');
            this.loadData();
        } catch (error) {
            console.error('Ошибка переноса заявки:', error);
        }
    }

    setupDragAndDrop() {
        const unassignedContainer = document.getElementById('unassigned-orders');
        const vehiclesContainer = document.getElementById('available-vehicles');

        // Drag start для заявок
        unassignedContainer.addEventListener('dragstart', (e) => {
            if (e.target.classList.contains('order-item')) {
                const orderType = e.target.dataset.orderType;
                e.dataTransfer.setData('orderId', e.target.dataset.orderId);
                e.dataTransfer.setData('orderType', orderType || 'full');
                e.target.classList.add('dragging');
                
                // Перерисовываем транспорт с учетом типа заявки
                setTimeout(() => this.renderAvailableVehicles(), 0);
            }
        });

        unassignedContainer.addEventListener('dragend', (e) => {
            if (e.target.classList.contains('order-item')) {
                e.target.classList.remove('dragging');
                // Перерисовываем транспорт (показать весь)
                this.renderAvailableVehicles();
            }
        });

        // Drag over для контейнера транспорта
        vehiclesContainer.addEventListener('dragover', (e) => {
            e.preventDefault();
            vehiclesContainer.classList.add('drag-over');
        });

        vehiclesContainer.addEventListener('dragleave', () => {
            vehiclesContainer.classList.remove('drag-over');
        });

        // Drop на транспортное средство
        vehiclesContainer.addEventListener('drop', async (e) => {
            e.preventDefault();
            vehiclesContainer.classList.remove('drag-over');
            
            if (!e.target.classList.contains('vehicle-item')) return;
            
            const orderId = e.dataTransfer.getData('orderId');
            const orderType = e.dataTransfer.getData('orderType');
            const vehicleId = e.target.dataset.vehicleId;
            const vehicleTransport = e.target.dataset.transport;
            
            // Проверка: экспресс только на авиа
            if (orderType === 'express' && vehicleTransport !== 'fly') {
                this.showNotification('❌ Экспресс-заявки только на авиатехнику!', 'error');
                return;
            }
            
            await this.assignVehicle(orderId, vehicleId);
        });

        // Также drop на контейнер
        unassignedContainer.addEventListener('drop', (e) => {
            e.preventDefault();
        });
    }

renderUnassignedOrders() {
        const container = document.getElementById('unassigned-orders');
        const unassignedOrders = this.orders.filter(o => o.status === 'new');

        if (unassignedOrders.length === 0) {
            container.innerHTML = '<p style="padding: 20px; text-align: center; color: #64748b;">Нет новых заявок</p>';
            return;
        }
        
        container.innerHTML = unassignedOrders.map(order => {
            const isExpress = order.orderType === 'express';
            const expressBadge = isExpress ? '<span class="express-badge">✈️ ЭКСПРЕСС</span>' : '';
            const transportIcon = isExpress ? '✈️' : '🚛';
            const transportType = isExpress ? 'АВИА' : 'АВТО';
            const hasCoords = order.pickupCoords && order.deliveryCoords;
            
            return `
            <div class="order-item" draggable="true" data-order-id="${order.id}" data-order-type="${order.orderType || 'full'}">
                <div class="order-header">
                    <h4>Заявка #${order.id} ${expressBadge}</h4>
                    <span class="transport-type-badge">${transportIcon} ${transportType}</span>
                </div>
                <p><strong>Клиент:</strong> ${this.escapeHtml(order.client)}</p>
                <p><strong>Загрузка:</strong> ${this.escapeHtml(order.pickupAddress)}</p>
                <p><strong>Доставка:</strong> ${this.escapeHtml(order.deliveryAddress)}</p>
                <p><strong>Груз:</strong> ${order.weight || '-'} кг, ${order.volume || '-'} м³</p>
                <p><strong>Дата:</strong> ${this.formatDateTime(order.orderDate)}</p>
                <div class="order-actions">
                    ${hasCoords ? `<button class="btn-small" onclick="logistic.buildRouteFromOrder(${order.id})">🗺️ Построить маршрут</button>` : ''}
                    ${hasCoords ? `<button class="btn-small btn-info" onclick="logistic.addOrderToRoute(${order.id})">➕ К маршруту</button>` : ''}
                </div>
                <span class="status-badge status-new">Новая</span>
            </div>
        `}).join('');

        container.querySelectorAll('.order-item').forEach(item => {
            item.addEventListener('dragend', () => {
                item.classList.remove('dragging');
            });
            item.addEventListener('dragstart', (e) => {
                item.classList.add('dragging');
            });
        });
    }

renderAvailableVehicles() {
        const container = document.getElementById('available-vehicles');
        
        // Получаем текущую перетаскиваемую заявку
        const draggedOrderId = document.querySelector('.order-item.dragging')?.dataset.orderId;
        let draggedOrderType = 'full';
        
        if (draggedOrderId) {
            const order = this.orders.find(o => o.id == draggedOrderId);
            if (order) {
                draggedOrderType = order.orderType || 'full';
            }
        }
        
        // Фильтрация: для экспресс только авиа
        let availableVehicles = this.vehicles.filter(v => v.status === 'available');
        
        if (draggedOrderType === 'express') {
            availableVehicles = availableVehicles.filter(v => v.transport === 'fly');
        }

        if (availableVehicles.length === 0) {
            const message = draggedOrderType === 'express' 
                ? 'Нет доступной авиатехники для экспресс-заявки' 
                : 'Нет доступного транспорта';
            container.innerHTML = `<p style="padding: 20px; text-align: center; color: #64748b;">${message}</p>`;
            return;
        }
        
        container.innerHTML = availableVehicles.map(vehicle => {
            const isAircraft = vehicle.transport === 'fly';
            const icon = isAircraft ? '✈️' : '🚛';
            const transportBadge = isAircraft ? '<span class="aircraft-badge">АВИА</span>' : '';
            
            return `
            <div class="vehicle-item ${isAircraft ? 'aircraft' : ''}" data-vehicle-id="${vehicle.id}" data-transport="${vehicle.transport}">
                <div>
                    <strong>${icon} ${vehicle.plate}</strong> ${transportBadge}
                    <br>
                    <small>${vehicle.type}</small>
                    <br>
                    <small>Водитель: ${vehicle.driver}</small>
                    <br>
                    <small>Грузоподъемность: ${vehicle.capacity} кг</small>
                </div>
                <span class="status-badge status-planned">Свободен</span>
            </div>
        `}).join('');
    }

    async assignVehicle(orderId, vehicleId) {
        try {
            const orders = await api.getOrders();
            const order = orders.find(o => o.id == orderId);
            const vehicle = this.vehicles.find(v => v.id == vehicleId);
            
            if (!order) return;

            // Проверка: экспресс только на авиа
            const isExpress = order.orderType === 'express';
            const isAircraft = vehicle?.transport === 'fly';
            
            if (isExpress && !isAircraft) {
                this.showNotification('❌ Экспресс-заявки можно назначать только на авиатехнику!', 'error');
                return;
            }
            
            // Обновляем статус заявки
            await api.updateOrder(orderId, {
                status: 'planned',
                vehicleId: parseInt(vehicleId),
                transportType: vehicle?.transport || 'auto',
                assignedAt: new Date().toISOString()
            });

            const icon = isAircraft ? '✈️' : '🚛';
            this.showNotification(`${icon} Транспорт назначен на заявку`);
            this.loadData();
        } catch (error) {
            console.error('Ошибка назначения транспорта:', error);
        }
    }
    
    setupMap() {
        // Не инициализируем сразу - сделаем это при активации вкладки
        // Инициализация произойдет при первом показе
    }
    
    // Инициализация карты при активации вкладки
    initMapOnShow() {
        const mapContainer = document.getElementById('logistics-map');
        if (!mapContainer) {
            console.error('Контейнер карты не найден!');
            return;
        }
        
        // Если карта уже инициализирована - просто обновим размер
        if (this.map) {
            setTimeout(() => {
                this.map.invalidateSize();
                this.updateMap();
            }, 100);
            return;
        }
        
        try {
            this.map = L.map('logistics-map', {
                center: [55.7558, 37.6173],
                zoom: 8,
                zoomControl: true,
                attributionControl: true
            });
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            }).addTo(this.map);

            console.log('Карта логиста инициализирована');
            
            setTimeout(() => {
                if (this.map) {
                    this.map.invalidateSize();
                    this.updateMap();
                }
            }, 300);
            
        } catch (error) {
            console.error('Ошибка инициализации карты:', error);
            mapContainer.innerHTML = '<div style="padding: 40px; text-align: center; color: #e74c3c;">Ошибка загрузки карты. Проверьте подключение к интернету.</div>';
        }
    }
    
    updateMap() {
        if (!this.map) {
            console.log('Карта еще не инициализирована');
            return;
        }
        
        // Очистка маркеров
        this.markers.forEach(marker => this.map.removeLayer(marker));
        this.markers = [];

        // Добавление маркеров для planned и новых заявок
        const plannedOrders = this.orders.filter(o => o.status === 'planned' || o.status === 'new');
        console.log('updateMap: найдено заявок:', plannedOrders.length);

        plannedOrders.forEach(order => {
            console.log('Заявка #', order.id, 'coords:', order.pickupCoords, order.deliveryCoords);
            
            if (order.pickupCoords && typeof order.pickupCoords.lat === 'number' && typeof order.pickupCoords.lng === 'number') {
                const marker = L.marker([order.pickupCoords.lat, order.pickupCoords.lng])
                    .addTo(this.map)
                    .bindPopup(`
                        <strong>Заявка #${order.id}</strong><br>
                        Клиент: ${this.escapeHtml(order.client)}<br>
                        Загрузка: ${this.escapeHtml(order.pickupAddress)}<br>
                        Доставка: ${this.escapeHtml(order.deliveryAddress)}
                    `);
                
                this.markers.push(marker);
                console.log('Добавлен маркер загрузки:', [order.pickupCoords.lat, order.pickupCoords.lng]);
            }

            if (order.deliveryCoords && typeof order.deliveryCoords.lat === 'number' && typeof order.deliveryCoords.lng === 'number') {
                const marker = L.marker([order.deliveryCoords.lat, order.deliveryCoords.lng], {
                    icon: L.divIcon({
                        className: 'delivery-marker',
                        html: '<div style="background: #10b981; width: 20px; height: 20px; border-radius: 50%; border: 2px solid white;"></div>'
                    })
                }).addTo(this.map)
                .bindPopup(`
                    <strong>Доставка заявки #${order.id}</strong><br>
                    ${this.escapeHtml(order.deliveryAddress)}
                `);
                
                this.markers.push(marker);
                console.log('Добавлен маркер доставки:', [order.deliveryCoords.lat, order.deliveryCoords.lng]);
            }
        });

        console.log('Всего маркеров:', this.markers.length);

        // Показать все маркеры на карте
        if (this.markers.length > 0) {
            const group = L.featureGroup(this.markers);
            this.map.fitBounds(group.getBounds().pad(0.1));
            console.log('Карта центрирована по маркерам');
        }
    }

    escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    formatDateTime(dateString) {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleString('ru-RU', {
            day: '2-digit',
            month: '2-digit',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    showNotification(message, type = 'success') {
        const notification = document.createElement('div');
        notification.className = 'notification' + (type === 'error' ? ' error' : '');
        notification.textContent = message;
        document.body.appendChild(notification);
        
        setTimeout(() => notification.classList.add('active'), 10);
        setTimeout(() => {
            notification.classList.remove('active');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
    
    // Показать маршрут заявки на карте
    async showRoute(orderId) {
        const order = this.orders.find(o => o.id == orderId);
        if (!order) return;
        
        if (!order.pickupCoords || !order.deliveryCoords) {
            this.showNotification('У заявки нет координат для отображения маршрута', 'error');
            return;
        }
        
        // Центрируем карту на маршруте
        if (this.map) {
            const bounds = L.latLngBounds([
                [order.pickupCoords.lat, order.pickupCoords.lng],
                [order.deliveryCoords.lat, order.deliveryCoords.lng]
            ]);
            this.map.fitBounds(bounds.pad(0.2));
            
            // Рисуем маршрут
            this.drawRoute(order);
            
            this.showNotification('🗺️ Маршрут отображен на карте');
        }
    }
    
    // Нарисовать маршрут на карте
    drawRoute(order) {
        // Удаляем старый маршрут
        if (this.routeLayer) {
            this.map.removeLayer(this.routeLayer);
        }
        
        const isExpress = order.orderType === 'express';
        
        // Создаем маршрут
        const routeCoords = [
            [order.pickupCoords.lat, order.pickupCoords.lng],
            [order.deliveryCoords.lat, order.deliveryCoords.lng]
        ];
        
        // Для экспресс - прямая линия (авиа), для обычных - дорога
        if (isExpress) {
            // Авиа - пунктирная прямая
            this.routeLayer = L.polyline(routeCoords, {
                color: '#e74c3c',
                weight: 3,
                dashArray: '10, 10',
                opacity: 0.8
            }).addTo(this.map);
        } else {
            // Авто - обычная линия
            this.routeLayer = L.polyline(routeCoords, {
                color: '#3498db',
                weight: 4,
                opacity: 0.8
            }).addTo(this.map);
        }
        
        // Добавляем маркеры
        L.marker(routeCoords[0], {
            icon: L.divIcon({
                className: 'pickup-marker',
                html: '<div style="background: #f39c12; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; display: flex; align-items: center; justify-content: center;">📦</div>'
            })
        }).bindPopup(`<b>Загрузка</b><br>${order.pickupAddress}`).addTo(this.map);
        
        L.marker(routeCoords[1], {
            icon: L.divIcon({
                className: 'delivery-marker',
                html: '<div style="background: #10b981; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; display: flex; align-items: center; justify-content: center;">🏁</div>'
            })
        }).bindPopup(`<b>Доставка</b><br>${order.deliveryAddress}`).addTo(this.map);
        
        // Рассчитываем примерное время
        const distance = this.calculateDistance(
            order.pickupCoords.lat, order.pickupCoords.lng,
            order.deliveryCoords.lat, order.deliveryCoords.lng
        );
        
        let timeEstimate;
        if (isExpress) {
            timeEstimate = Math.round(distance / 800 * 60); // ~800 км/ч для авиа
            this.showNotification(`✈️ Авиа доставка: ~${timeEstimate} мин, ${distance} км`);
        } else {
            timeEstimate = Math.round(distance / 60); // ~60 км/ч для авто
            const hours = Math.floor(timeEstimate / 60);
            const mins = timeEstimate % 60;
            this.showNotification(`🚛 Авто доставка: ~${hours}ч ${mins}мин, ${distance} км`);
        }
    }
    
    // Рассчитать расстояние между точками (км)
    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371; // радиус Земли
        const dLat = (lat2 - lat1) * Math.PI / 180;
        const dLon = (lon2 - lon1) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                  Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return Math.round(R * c);
    }
    
    // Показать модальное окно подтверждения назначения
    async showAssignConfirm(orderId, vehicleId) {
        const order = this.orders.find(o => o.id == orderId);
        const vehicle = this.vehicles.find(v => v.id == vehicleId);
        
        if (!order || !vehicle) return;
        
        const isExpress = order.orderType === 'express';
        const isAircraft = vehicle.transport === 'fly';
        
        if (isExpress && !isAircraft) {
            alert('❌ Ошибка! Экспресс-заявки можно назначать только на авиатехнику!');
            return false;
        }
        
        if (!isExpress && isAircraft) {
            if (!confirm('⚠️ Обычная заявка на авиатехнику? Стоимость будет выше. Продолжить?')) {
                return false;
            }
        }
        
        return true;
    }
    
    // Построить маршрут по заявке (от загрузки до доставки)
    buildRouteFromOrder(orderId) {
        const order = this.orders.find(o => o.id == orderId);
        if (!order) return;
        
        if (!order.pickupCoords || !order.deliveryCoords) {
            this.showNotification('У заявки нет координат!', 'error');
            return;
        }
        
        // Открываем модальное окно маршрута
        this.showNewRouteModal();
        
        // Добавляем точки из заявки
        this.routePoints = [
            {
                id: Date.now(),
                address: order.pickupAddress,
                lat: order.pickupCoords.lat,
                lng: order.pickupCoords.lng
            },
            {
                id: Date.now() + 1,
                address: order.deliveryAddress,
                lat: order.deliveryCoords.lat,
                lng: order.deliveryCoords.lng
            }
        ];
        
        // Устанавливаем тип транспорта
        const select = document.getElementById('route-transport-type');
        if (select) {
            select.value = order.orderType === 'express' ? 'fly' : 'auto';
        }
        
        this.updateRoutePointsList();
        this.drawCurrentRoute();
        
        this.showNotification('🗺️ Маршрут построен по заявке');
    }
    
    // Добавить заявку к текущему маршруту
    addOrderToRoute(orderId) {
        const order = this.orders.find(o => o.id == orderId);
        if (!order) return;
        
        if (!order.pickupCoords || !order.deliveryCoords) {
            this.showNotification('У заявки нет координат!', 'error');
            return;
        }
        
        // Проверяем, есть ли уже точки
        if (this.routePoints.length === 0) {
            // Если нет - сначала строим маршрут
            this.buildRouteFromOrder(orderId);
            return;
        }
        
        // Добавляем точки заявки к текущему маршруту
        this.routePoints.push({
            id: Date.now(),
            address: order.pickupAddress,
            lat: order.pickupCoords.lat,
            lng: order.pickupCoords.lng
        });
        
        this.routePoints.push({
            id: Date.now() + 1,
            address: order.deliveryAddress,
            lat: order.deliveryCoords.lat,
            lng: order.deliveryCoords.lng
        });
        
        this.updateRoutePointsList();
        this.drawCurrentRoute();
        
        this.showNotification(`✅ Добавлена заявка #${orderId} к маршруту`);
    }
}

// Инициализация
let logistic;
document.addEventListener('DOMContentLoaded', () => {
    logistic = new LogisticModule();
    window.logistic = logistic;
    window.showRoute = function(orderId) {
        logistic.showRoute(orderId);
    };
});
