// Simple Express.js Backend для TMS
// Установка: npm install express pg cors body-parser

const express = require('express');
const { Pool } = require('pg');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const port = 3001;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public')); // Раздача статических файлов

// PostgreSQL Connection Pool
const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'tms_db',
  password: 'your_password',
  port: 5432,
});

// ============================================
// ORDERS API
// ============================================

// GET /api/orders - Получить все заявки
app.get('/api/orders', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM orders ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// GET /api/orders/:id - Получить заявку по ID
app.get('/api/orders/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM orders WHERE id = $1', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Order not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error fetching order:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// POST /api/orders - Создать новую заявку
app.post('/api/orders', async (req, res) => {
  try {
    const {
      client_id,
      client_name,
      order_type,
      cargo_type,
      weight_kg,
      volume_m3,
      notes,
      pickup_address,
      pickup_lat,
      pickup_lon,
      pickup_contact,
      pickup_phone,
      pickup_instructions,
      delivery_address,
      delivery_lat,
      delivery_lon,
      delivery_contact,
      delivery_phone,
      delivery_instructions,
      pickup_datetime,
      delivery_deadline,
      priority,
      price,
      metadata
    } = req.body;

    const result = await pool.query(`
      INSERT INTO orders (
        client_id, client_name, order_type, cargo_type, weight_kg, volume_m3, notes,
        pickup_address, pickup_lat, pickup_lon, pickup_contact, pickup_phone, pickup_instructions,
        delivery_address, delivery_lat, delivery_lon, delivery_contact, delivery_phone, delivery_instructions,
        pickup_datetime, delivery_deadline, priority, price, metadata
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24)
      RETURNING *
    `, [
      client_id, client_name, order_type, cargo_type, weight_kg, volume_m3, notes,
      pickup_address, pickup_lat, pickup_lon, pickup_contact, pickup_phone, pickup_instructions,
      delivery_address, delivery_lat, delivery_lon, delivery_contact, delivery_phone, delivery_instructions,
      pickup_datetime, delivery_deadline, priority, price, metadata
    ]);

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// PUT /api/orders/:id - Обновить заявку
app.put('/api/orders/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;
    
    // Build dynamic update query
    const fields = Object.keys(updateData);
    const values = Object.values(updateData);
    const setClause = fields.map((field, index) => `${field} = $${index + 1}`).join(', ');
    
    const query = `
      UPDATE orders 
      SET ${setClause}, updated_at = NOW()
      WHERE id = $${fields.length + 1}
      RETURNING *
    `;
    
    const result = await pool.query(query, [...values, id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Order not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating order:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// DELETE /api/orders/:id - Удалить заявку
app.delete('/api/orders/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('DELETE FROM orders WHERE id = $1 RETURNING *', [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Order not found' });
    }
    
    res.json({ message: 'Order deleted successfully' });
  } catch (error) {
    console.error('Error deleting order:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// ============================================
// CLIENTS API
// ============================================

// GET /api/clients - Получить всех клиентов
app.get('/api/clients', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM clients ORDER BY name');
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching clients:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// GET /api/clients/search?q=query - Поиск клиентов
app.get('/api/clients/search', async (req, res) => {
  try {
    const { q } = req.query;
    const result = await pool.query(
      'SELECT * FROM clients WHERE name ILIKE $1 OR company_name ILIKE $1 OR email ILIKE $1',
      [`%${q}%`]
    );
    res.json(result.rows);
  } catch (error) {
    console.error('Error searching clients:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// POST /api/clients - Создать клиента
app.post('/api/clients', async (req, res) => {
  try {
    const { name, company_name, inn, phone, email, address, contact_person, notes } = req.body;
    
    const result = await pool.query(`
      INSERT INTO clients (name, company_name, inn, phone, email, address, contact_person, notes)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *
    `, [name, company_name, inn, phone, email, address, contact_person, notes]);

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error('Error creating client:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// ============================================
// VEHICLES API
// ============================================

// GET /api/vehicles - Получить все транспортные средства
app.get('/api/vehicles', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM vehicles ORDER BY plate_number');
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching vehicles:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// GET /api/vehicles/available - Получить доступные транспортные средства
app.get('/api/vehicles/available', async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM vehicles WHERE status = 'available'");
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching available vehicles:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// PUT /api/vehicles/:id - Обновить транспортное средство
app.put('/api/vehicles/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updateData = req.body;
    
    const fields = Object.keys(updateData);
    const values = Object.values(updateData);
    const setClause = fields.map((field, index) => `${field} = $${index + 1}`).join(', ');
    
    const query = `
      UPDATE vehicles 
      SET ${setClause}, updated_at = NOW()
      WHERE id = $${fields.length + 1}
      RETURNING *
    `;
    
    const result = await pool.query(query, [...values, id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Vehicle not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    console.error('Error updating vehicle:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// ============================================
// REPORTS API
// ============================================

// GET /api/reports?start=YYYY-MM-DD&end=YYYY-MM-DD - Получить отчет
app.get('/api/reports', async (req, res) => {
  try {
    const { start, end } = req.query;
    
    if (!start || !end) {
      return res.status(400).json({ error: 'Start and end dates are required' });
    }

    // Получаем заявки за период
    const ordersResult = await pool.query(`
      SELECT * FROM orders 
      WHERE DATE(created_at) BETWEEN $1 AND $2
      ORDER BY created_at DESC
    `, [start, end]);

    // Получаем статистику
    const statsResult = await pool.query(`
      SELECT 
        COUNT(*) AS total,
        COUNT(*) FILTER (WHERE status = 'new') AS new_orders,
        COUNT(*) FILTER (WHERE status = 'planned') AS planned_orders,
        COUNT(*) FILTER (WHERE status = 'in_transit') AS in_transit,
        COUNT(*) FILTER (WHERE status = 'delivered') AS delivered,
        COUNT(*) FILTER (WHERE priority = 'urgent') AS urgent
      FROM orders
      WHERE DATE(created_at) BETWEEN $1 AND $2
    `, [start, end]);

    res.json({
      orders: ordersResult.rows,
      stats: statsResult.rows[0]
    });
  } catch (error) {
    console.error('Error generating report:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// GET /api/reports/daily - Получить дневную статистику
app.get('/api/reports/daily', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT * FROM v_daily_statistics 
      LIMIT 30
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching daily statistics:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// GET /api/reports/vehicle-utilization - Получить статистику по транспорту
app.get('/api/reports/vehicle-utilization', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT * FROM v_vehicle_utilization
    `);
    res.json(result.rows);
  } catch (error) {
    console.error('Error fetching vehicle utilization:', error);
    res.status(500).json({ error: 'Database error' });
  }
});

// ============================================
// ERROR HANDLING
// ============================================

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ error: 'Internal server error' });
});

// Start server
app.listen(port, () => {
  console.log(`TMS Backend running at http://localhost:${port}`);
  console.log('Database connected successfully');
});

// Graceful shutdown
process.on('SIGINT', async () => {
  console.log('Shutting down gracefully...');
  await pool.end();
  process.exit(0);
});
